# obs-day3: Splunk, Dynatrace and Datadog query languages (lab pack)

Lab files for Day 3 of the observability course. The Splunk labs use a new easyTravel outage spread over four
indexes. The Dynatrace and Datadog labs run on the easyTravel VMs from Day 2, with timed problem patterns.
All data is invented: example.com addresses and documentation IP ranges only.

## The outage in the Splunk data

What you know at the start: on 19 November 2026, from about 10:05 UTC, easyTravel users report failed searches
and bookings. By 10:45 UTC it is over. Your job in Labs 3.1 and 3.2 is to find out what happened, where and why.
(Trainers: the full story is in the Lab Guide, Appendix A.)

| Index | Source type | Hosts | What it holds |
| --- | --- | --- | --- |
| `et_web` | `access_combined` | web-01, web-02 | Frontend access log, with `rt=`, `upstream=`, `session=`, `trace=` at the end |
| `et_web` | `easytravel:frontend` | web-01, web-02 | Frontend application log (plain text, log4j style) |
| `et_app` | `easytravel:app` | app-01, app-02 | Business Backend log (JSON lines) |
| `et_os` | `os:metrics` | all five | CPU, memory, load and disk, one line per minute (key=value) |
| `et_os` | `easytravel:jvm` | app-01, app-02 | JDBC pool and JVM figures, one line per minute (key=value) |
| `et_change` | `change:event` | change-mgmt | Change records (JSON lines) |

Lookups: `lookups/et_hosts.csv` (tier, team, on-call channel per host) and `lookups/http_status.csv`.

## Load the data into Splunk

- **Splunk Enterprise (trial or free, Linux or macOS):** install `splunk/obs_day3_app.tgz` with Apps, Manage Apps,
  Install app from file, and restart when asked. The app creates the four indexes, the source types and the
  lookups, and indexes its own copy of the data. Nothing else to do.
- **Splunk Cloud trial (or any Splunk without the app):** create the four indexes, create an HTTP Event
  Collector token allowed to write to them, then run `bin/to_splunk_hec.py` (see its help). Upload the two lookup
  files in Settings, Lookups, Lookup table files.

Always search with `index=et_*` or a specific index: these indexes are not searched by default.

## Contents

| Path | What it is |
| --- | --- |
| `data/` | The Splunk data, one folder per index and host |
| `lookups/` | `et_hosts.csv`, `http_status.csv` |
| `make_data.py` | Rebuilds `data/` and `lookups/` (fixed seed, same output every time) |
| `splunk/obs_day3/`, `splunk/build_app.py` | The Splunk app source, and the script that packages `obs_day3_app.tgz` |
| `bin/to_splunk_hec.py` | Sends the data to Splunk's HTTP Event Collector |
| `bin/expected.py` | Expected results of every Splunk exercise, computed from `data/` (also the offline variant) |
| `bin/kpi.py` | ITSI-style KPIs, severities and a simplified health score, every 5 minutes |
| `bin/scenario.py` | Timed easyTravel problem patterns: `lab33` (Dynatrace VM), `lab34` (Datadog VM) |
| `bin/pattern.py`, `bin/check.py`, `bin/etlib.py` | easyTravel helpers, as on Day 2 |

## Secrets

Lab-only secrets, never committed. The HEC token goes in your shell only (`read -rs SPLUNK_HEC_TOKEN`), never in a
file in this folder, a chat or a screenshot. `.gitignore` excludes `*.env`.

## Clean up

- Splunk Enterprise: remove the app (Apps, Manage Apps) and delete the four indexes in Settings, Indexes.
- Splunk Cloud: delete the indexes and the HEC token.
- Dynatrace and Datadog: delete the notebooks, monitors and the log-based metric you created.
