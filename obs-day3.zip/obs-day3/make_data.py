#!/usr/bin/env python3
"""Build the Day 3 Splunk data: one easyTravel outage spread over four indexes (fixed seed, same output every run).

    python3 make_data.py          # writes data/ and lookups/

The incident (19 November 2026, 09:00 to 11:00 UTC; all data invented, example.com and documentation IP ranges only)
is described in the Lab Guide, Appendix A. Trainees: investigate it in Splunk before you read this code.

Files (data/<index>/<host>/<file>; the host is the folder name):
  et_web     access.log    sourcetype access_combined         web-01, web-02
  et_web     frontend.log  sourcetype easytravel:frontend     web-01, web-02 (plain text, log4j style)
  et_app     app.log       sourcetype easytravel:app          app-01, app-02 (JSON lines)
  et_os      os.log        sourcetype os:metrics              all five hosts (key=value, one line per minute)
  et_os      jvm.log       sourcetype easytravel:jvm          app-01, app-02 (key=value, one line per minute)
  et_change  changes.log   sourcetype change:event            host change-mgmt (JSON lines)
Lookups: lookups/et_hosts.csv, lookups/http_status.csv
"""
import json, math, os, random
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OUT, LK = os.path.join(HERE, "data"), os.path.join(HERE, "lookups")
R = random.Random(20261119)
T0 = datetime(2026, 11, 19, 9, 0, tzinfo=timezone.utc)
MIN = 120
BAD0, BAD1 = 64 * 60 + 40, 101 * 60 + 20          # 10:04:40 to 10:41:20: app-02 pool exhausted
BACKUP0, BACKUP1 = 30 * 60, 41 * 60                 # 09:30 to 09:41: backup on web-02
WEB, APP = ["web-01", "web-02"], ["app-01", "app-02"]
DESTS = ["Paris", "New York", "Tokyo", "Sydney", "Rome", "Vienna", "Lisbon", "Cape Town", "Toronto", "Singapore"]
AGENTS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0 Safari/537.36",
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 Version/18.1 Safari/605.1.15",
          "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0",
          "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1"]
CLIENT_NETS = ["198.51.100.", "203.0.113.", "192.0.2."]
OP = {"search": ("JourneyService", "findJourneys"), "details": ("JourneyService", "getJourneyById"),
      "login": ("AuthenticationService", "authenticate"), "booking": ("BookingService", "storeBooking")}
BASE = {"search": 0.055, "details": 0.040, "login": 0.065, "booking": 0.135}       # median seconds, healthy
FAILP = {"search": 0.24, "details": 0.20, "login": 0.16, "booking": 0.42}         # app-02 failure chance while bad

hexid = lambda n: "".join(R.choice("0123456789abcdef") for _ in range(n))
ts_iso = lambda s: (T0 + timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
ts_clf = lambda s: (T0 + timedelta(seconds=s)).strftime("%d/%b/%Y:%H:%M:%S +0000")
ts_l4j = lambda s: (T0 + timedelta(seconds=s)).strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
bad = lambda s: BAD0 <= s < BAD1
load = lambda s: 0.85 + 0.30 * s / (MIN * 60) + 0.05 * math.sin(s / 600)

files = {}            # (index, host, file) -> list of (sec, line)


def out(index, host, name, sec, line):
    files.setdefault((index, host, name), []).append((sec, line))


def applog(sec, host, level, service, msg, **kw):
    d = {"time": ts_iso(sec), "level": level, "service": service, "thread": f"http-nio-8091-exec-{R.randint(1, 40)}", "message": msg}
    d.update(kw)
    out("et_app", host, "app.log", sec, json.dumps(d))


def felog(sec, host, level, logger, msg):
    out("et_web", host, "frontend.log", sec, f"{ts_l4j(sec)} {level:<5} [http-nio-8079-exec-{R.randint(1, 60)}] com.example.easytravel.web.{logger} - {msg}")


stats = {"requests": 0, "errors": 0}
next_booking = [7240000]


def request(kind, sec, session, client, agent, web):
    """One page request: frontend on web-0x calls the Business Backend on app-01 or app-02. Returns True if it failed."""
    app = R.choice(APP)
    svc, op = OP[kind]
    trace = hexid(32)
    failed, wait = False, 0.0
    rt = R.lognormvariate(math.log(BASE[kind]), 0.35)
    if app == "app-02" and bad(sec):
        if R.random() < FAILP[kind] * (0.8 + 0.4 * load(sec)):
            failed = True
            rt = 2.0 + R.uniform(0.012, 0.09)
        else:
            wait = min(1.95, R.lognormvariate(math.log(0.38), 0.6))
            rt += wait
    status = 500 if failed else 200
    if kind == "search":
        method, path = "GET", "/orange.jsf?destination=" + R.choice(DESTS).replace(" ", "%20")
    elif kind == "details":
        method, path = "GET", f"/orange-trip-details.jsf?journeyId={R.randint(1000, 9999)}"
    elif kind == "login":
        method, path = "POST", "/orange.jsf"
    else:
        method, path = "POST", "/orange-booking-payment.jsf"
    size = R.randint(4200, 18000) if status == 200 else 1532
    out("et_web", web, "access.log", sec, '%s - - [%s] "%s %s HTTP/1.1" %d %d "https://travel.example.com/orange.jsf" "%s" rt=%.3f upstream=%s session=%s trace=%s' % (
        client, ts_clf(sec), method, path, status, size, agent, rt, app, session, trace))
    stats["requests"] += 1
    stats["errors"] += failed
    # backend logs
    end = sec + rt
    exc = "java.sql.SQLTransientConnectionException: HikariPool-1 - Connection is not available, request timed out after 2000ms."
    if kind == "booking":
        next_booking[0] += R.randint(1, 3)
        bid = next_booking[0]
        applog(sec + 0.004, app, "INFO", svc, f"storeBooking start bookingId={bid}", bookingId=bid, session=session, trace_id=trace)
        if failed:
            applog(end - 0.006, app, "ERROR", svc, f"storeBooking failed bookingId={bid}: {exc}", bookingId=bid, session=session,
                   trace_id=trace, duration_ms=int((rt - 0.01) * 1000), exception="java.sql.SQLTransientConnectionException")
            felog(end, web, "ERROR", "BookingController", f"Booking failed for session={session}: HTTP 500 from {app} ({svc}.{op}) after {int(rt * 1000)} ms")
        else:
            applog(end - 0.006, app, "INFO", svc, f"Booking stored bookingId={bid}", bookingId=bid, session=session, trace_id=trace,
                   duration_ms=int((rt - 0.01) * 1000))
            felog(end, web, "INFO", "BookingController", f"Booking completed for session={session} bookingId={bid} in {int(rt * 1000)} ms")
    elif failed:
        applog(end - 0.006, app, "ERROR", svc, f"{op} failed: {exc}", session=session, trace_id=trace,
               duration_ms=int((rt - 0.01) * 1000), exception="java.sql.SQLTransientConnectionException")
        ctl = {"search": "JourneyController", "details": "JourneyController", "login": "LoginController"}[kind]
        felog(end, web, "ERROR", ctl, f"{op} failed for session={session}: HTTP 500 from {app} ({svc}.{op}) after {int(rt * 1000)} ms")
    if wait > 1.0:
        applog(sec + wait, app, "WARN", svc, f"Slow connection acquire: {int(wait * 1000)} ms (pool active=4/4)", session=session, trace_id=trace)
        felog(end, web, "WARN", "BackendClient", f"Slow backend call to {app} ({svc}.{op}) took {int(rt * 1000)} ms")
    if kind == "login" and not failed:
        applog(end - 0.004, app, "INFO", svc, "User authenticated", session=session, trace_id=trace, duration_ms=int(rt * 1000))
    return failed, rt


# ------------------------------------------------------------------ user sessions
for m in range(MIN):
    for _ in range(int(57 * load(m * 60)) + (1 if R.random() < 0.5 else 0)):
        t = m * 60 + R.random() * 60
        session, client, agent, web = hexid(8), R.choice(CLIENT_NETS) + str(R.randint(2, 254)), R.choice(AGENTS), R.choice(WEB)
        steps = (["login"] if R.random() < 0.35 else []) + ["search"] * R.choice([1, 1, 2, 2, 3])
        nd = R.choice([0, 1, 1, 1, 2])
        steps += ["details"] * nd + (["booking"] if nd and R.random() < 0.45 else [])
        for kind in steps:
            if t >= MIN * 60:
                break
            failed, rt = request(kind, t, session, client, agent, web)
            t += rt
            if failed:
                if R.random() < 0.5:                       # the user retries once, then gives up
                    t += R.uniform(2, 8)
                    if t < MIN * 60:
                        failed, rt = request(kind, t, session, client, agent, web)
                        t += rt
                if failed:
                    break
            t += R.uniform(4, 30)
    if R.random() < 0.3:                                  # a little background noise: crawlers and missing files
        t = m * 60 + R.random() * 60
        web = R.choice(WEB)
        out("et_web", web, "access.log", t, '%s - - [%s] "GET /favicon.ico HTTP/1.1" 404 196 "-" "Mozilla/5.0 (compatible; ExampleBot/2.1; +https://bot.example.com)" rt=0.002 upstream=- session=- trace=-' % (
            R.choice(CLIENT_NETS) + str(R.randint(2, 254)), ts_clf(t)))

# ------------------------------------------------------------------ periodic logs and metrics
for m in range(MIN):
    s = m * 60
    for h in WEB:
        felog(s + 0.2, h, "INFO", "SessionMonitor", f"Active sessions: {int(R.gauss(240, 15) * load(s))}")
    for h in APP:
        if m % 5 == 0:
            applog(s + 1.5, h, "INFO", "JourneyService", "Journey cache refreshed", entries=R.randint(3800, 4200))
    for h in ["web-01", "web-02", "app-01", "app-02", "db-01"]:
        cpu = {"web": 24, "app": 33, "db-": 21}[h[:3]] * load(s) + R.gauss(0, 2.5)
        mem = {"web": 58, "app": 66, "db-": 71}[h[:3]] + R.gauss(0, 1.2)
        if h == "web-02" and BACKUP0 <= s < BACKUP1:
            cpu = 85 + R.gauss(0, 3)
        if h == "app-02" and bad(s):
            cpu = 14 + R.gauss(0, 2)                       # threads wait for connections: CPU drops, it does not rise
        if h == "db-01" and bad(s):
            cpu *= 0.9
        out("et_os", h, "os.log", s, f"{ts_iso(s)[:19]}Z cpu_pct={max(1, cpu):.1f} mem_pct={mem:.1f} load1={max(0.05, cpu / 100 * 2 * R.uniform(0.8, 1.2)):.2f} disk_used_pct={62 if h != 'db-01' else 78}")
    for h in APP:
        if h == "app-02" and bad(s):
            mx, act, wt = 4, 4, int(max(1, R.gauss(14, 4) * load(s)))
        else:
            mx, act, wt = 20, max(1, int(R.gauss(4, 1.5))), 0
        if h == "app-02" and 64 * 60 <= s < 65 * 60:
            mx, act, wt = 20, 0, 0                         # restart minute
        out("et_os", h, "jvm.log", s, f"{ts_iso(s)[:19]}Z pool_name=HikariPool-1 pool_max={mx} pool_active={act} pool_waiting={wt} heap_used_pct={R.uniform(48, 63):.1f} threads_busy={act + wt + R.randint(2, 6)}")

# ------------------------------------------------------------------ changes and deployments
CH = [(20 * 60, {"change_id": "CHG-4115", "type": "deployment", "hosts": "web-01,web-02", "service": "easyTravel Customer Frontend",
                 "summary": "Deploy frontend 2.0.0-b51 (UI text fixes)", "team": "web-team", "status": "implemented", "risk": "low"}),
      (29 * 60 + 58, {"change_id": "CHG-4119", "type": "standard", "hosts": "web-02", "service": "backup",
                      "summary": "Weekly file-system backup moved to 09:30 UTC", "team": "platform-ops", "status": "implemented", "risk": "low"}),
      (64 * 60, {"change_id": "CHG-4127", "type": "standard", "hosts": "app-02", "service": "Business Backend",
                 "summary": "Raise BookingService JDBC pool maxPoolSize from 20 to 40", "team": "platform-ops", "status": "implemented", "risk": "low",
                 "config": "maxPoolSize=4"}),
      (64 * 60 + 25, {"change_id": "CHG-4127", "type": "restart", "hosts": "app-02", "service": "Business Backend",
                      "summary": "Business Backend restarted to apply CHG-4127", "team": "platform-ops", "status": "completed", "risk": "low"}),
      (101 * 60, {"change_id": "CHG-4131", "type": "emergency", "hosts": "app-02", "service": "Business Backend",
                  "summary": "Revert CHG-4127: maxPoolSize back to 20 (value 4 was a typo)", "team": "platform-ops", "status": "implemented", "risk": "medium",
                  "config": "maxPoolSize=20", "incident": "INC-20519"}),
      (101 * 60 + 20, {"change_id": "CHG-4131", "type": "restart", "hosts": "app-02", "service": "Business Backend",
                       "summary": "Business Backend restarted to apply CHG-4131", "team": "platform-ops", "status": "completed", "risk": "medium"})]
for s, d in CH:
    out("et_change", "change-mgmt", "changes.log", s, json.dumps(dict({"time": ts_iso(s)}, **d)))
applog(64 * 60 + 38, "app-02", "INFO", "BookingService", "Business Backend started: HikariPool-1 maxPoolSize=4 minIdle=2")
applog(101 * 60 + 18, "app-02", "INFO", "BookingService", "Business Backend started: HikariPool-1 maxPoolSize=20 minIdle=2")
applog(64 * 60 + 41, "app-02", "WARN", "BookingService", "HikariPool-1 - Pool stats (total=4, active=4, idle=0, waiting=3)")

# ------------------------------------------------------------------ write
for (index, host, name), rows in files.items():
    d = os.path.join(OUT, index, host)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, name), "w") as f:
        for _, line in sorted(rows, key=lambda r: r[0]):
            f.write(line + "\n")
os.makedirs(LK, exist_ok=True)
with open(os.path.join(LK, "et_hosts.csv"), "w") as f:
    f.write("host,tier,role,team,datacenter,oncall_channel\n"
            "web-01,web,easyTravel Customer Frontend,web-team,dc-east,#web-oncall\n"
            "web-02,web,easyTravel Customer Frontend,web-team,dc-west,#web-oncall\n"
            "app-01,app,Business Backend,platform-ops,dc-east,#platform-oncall\n"
            "app-02,app,Business Backend,platform-ops,dc-west,#platform-oncall\n"
            "db-01,db,easyTravelBusiness database,dba-team,dc-east,#dba-oncall\n")
with open(os.path.join(LK, "http_status.csv"), "w") as f:
    f.write("status,status_text,status_class\n" + "".join(f"{c},{t},{k}\n" for c, t, k in [
        (200, "OK", "success"), (201, "Created", "success"), (302, "Found", "redirect"), (304, "Not Modified", "redirect"),
        (400, "Bad Request", "client error"), (401, "Unauthorized", "client error"), (403, "Forbidden", "client error"),
        (404, "Not Found", "client error"), (500, "Internal Server Error", "server error"), (502, "Bad Gateway", "server error"),
        (503, "Service Unavailable", "server error"), (504, "Gateway Timeout", "server error")]))
n = sum(len(v) for v in files.values())
print(f"wrote {len(files)} files, {n:,} events; {stats['requests']:,} page requests, {stats['errors']:,} failed")
