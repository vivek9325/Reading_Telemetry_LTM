#!/usr/bin/env python3
"""Package the Day 3 data as a Splunk app: splunk/obs_day3_app.tgz

    python3 splunk/build_app.py

Install it in Splunk Enterprise: Apps, Manage Apps, Install app from file, then restart Splunk when asked.
The app creates the indexes et_web, et_app, et_os and et_change, defines the source types, monitors its own copy
of data/ (the host is taken from the folder name) and ships the lookups et_hosts.csv and http_status.csv.
"""
import io, os, tarfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, "obs_day3_app.tgz")


def add(tar, src, arc):
    for base, dirs, files in os.walk(src):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(base, f)
            info = tar.gettarinfo(p, arcname=os.path.join(arc, os.path.relpath(p, src)))
            info.uid = info.gid = 0
            info.uname = info.gname = "splunk"
            info.mtime = 1794992400                  # fixed time: the same archive on every build
            with open(p, "rb") as fh:
                tar.addfile(info, fh)


with tarfile.open(OUT, "w:gz") as tar:
    add(tar, os.path.join(HERE, "obs_day3"), "obs_day3")
    add(tar, os.path.join(ROOT, "data"), "obs_day3/data")
    add(tar, os.path.join(ROOT, "lookups"), "obs_day3/lookups")
with tarfile.open(OUT) as tar:
    names = tar.getnames()
print(f"wrote {os.path.relpath(OUT, ROOT)}: {len(names)} files, {os.path.getsize(OUT) / 1e6:.1f} MB")
