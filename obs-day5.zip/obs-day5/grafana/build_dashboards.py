#!/usr/bin/env python3
"""Write the Lab 5.3 dashboards (Grafana 12, for the Day 4 lab stack; data sources uid prometheus and loki).

grafana/ops-easytravel-v1.json            the "existing operational dashboard" you improve in Lab 5.3, Part B
grafana/solutions/golden-signals.json     one possible answer to Part A
grafana/solutions/ops-easytravel-v2.json  one possible answer to Part B
Import a file with Dashboards, New, Import, Upload dashboard JSON file.
"""
import copy, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
PROM = {"type": "prometheus", "uid": "prometheus"}
LOKI = {"type": "loki", "uid": "loki"}
TIME = {"from": "2026-11-12T09:00:00.000Z", "to": "2026-11-12T11:00:00.000Z"}
REQ = 'http_server_requests_seconds'
_id = [0]


def nid():
    _id[0] += 1
    return _id[0]


def thresholds(*steps):
    return {"mode": "absolute", "steps": [{"color": c, "value": v} for c, v in steps]}


def target(expr, legend="", ref="A", instant=False, ds=PROM, **kw):
    t = {"refId": ref, "datasource": ds, "expr": expr, "legendFormat": legend}
    if ds is PROM:
        t.update({"range": not instant, "instant": instant})
    t.update(kw)
    return t


def ts(title, grid, targets, unit, desc="", ds=PROM, thr=None, overrides=None, **custom):
    fc = {"defaults": {"unit": unit, "custom": dict({"lineWidth": 2, "fillOpacity": 8}, **custom)}, "overrides": overrides or []}
    if thr:
        fc["defaults"]["thresholds"] = thr
        fc["defaults"]["custom"]["thresholdsStyle"] = {"mode": "line+area" if custom.pop("area", False) else "dashed"}
    return {"id": nid(), "type": "timeseries", "title": title, "description": desc, "datasource": ds, "gridPos": grid,
            "targets": targets, "fieldConfig": fc,
            "options": {"legend": {"displayMode": "list", "placement": "bottom"}, "tooltip": {"mode": "multi", "sort": "desc"}}}


def stat(title, grid, expr, unit, thr, desc="", decimals=None, ds=PROM):
    d = {"unit": unit, "thresholds": thr, "color": {"mode": "thresholds"}}
    if decimals is not None:
        d["decimals"] = decimals
    return {"id": nid(), "type": "stat", "title": title, "description": desc, "datasource": ds, "gridPos": grid,
            "targets": [target(expr, instant=True)], "fieldConfig": {"defaults": d, "overrides": []},
            "options": {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                        "colorMode": "background", "graphMode": "none", "textMode": "value", "justifyMode": "center"}}


def row(title, y, collapsed=False, panels=None):
    return {"id": nid(), "type": "row", "title": title, "collapsed": collapsed, "gridPos": {"x": 0, "y": y, "w": 24, "h": 1},
            "panels": panels or []}


def var(name, query, label, multi=False, include_all=False, current=None):
    v = {"type": "query", "name": name, "label": label, "datasource": PROM, "query": query, "definition": query,
         "refresh": 1, "sort": 1, "multi": multi, "includeAll": include_all, "hide": 0}
    if current:
        v["current"] = {"text": current, "value": current, "selected": True}
    if include_all:
        v["allValue"] = ".*"
    return v


def dash(uid, title, panels, tags, templating=(), links=(), desc=""):
    return {"uid": uid, "title": title, "description": desc, "tags": tags, "timezone": "utc", "schemaVersion": 39,
            "version": 1, "editable": True, "graphTooltip": 1, "refresh": "", "time": TIME,
            "templating": {"list": list(templating)}, "annotations": {"list": []}, "links": list(links), "panels": panels}


S, I = 'service="$service"', 'instance=~"$instance"'
SEL = f'{{{S}, {I}}}'
SEL5 = f'{{{S}, {I}, status=~"5.."}}'
P = {
    "rps": f'sum(rate({REQ}_count{SEL}[$__rate_interval]))',
    "rps_uri": f'sum by (uri) (rate({REQ}_count{SEL}[$__rate_interval]))',
    "err": f'sum(rate({REQ}_count{SEL5}[$__rate_interval])) / sum(rate({REQ}_count{SEL}[$__rate_interval]))',
    "err_status": f'sum by (status) (rate({REQ}_count{SEL5}[$__rate_interval]))',
    "q": lambda q: f'histogram_quantile({q}, sum by (le) (rate({REQ}_bucket{SEL}[$__rate_interval])))',
    "threads": f'max_over_time(tomcat_threads_busy_threads{SEL}[$__rate_interval]) / tomcat_threads_config_max_threads{SEL}',
    "cpu": f'avg_over_time(process_cpu_usage{SEL}[$__rate_interval])',
}
LINK_GS = {"title": "Golden signals", "type": "link", "url": "/d/easytravel-golden-signals?${__url_time_range}&var-service=easytravel-backend",
           "icon": "dashboard", "targetBlank": False}

# ---------------------------------------------------------------------------------------- Part A: golden signals
_id[0] = 0
TV = [var("service", f'label_values({REQ}_count{{job="easytravel"}}, service)', "Service", current="easytravel-backend"),
      var("instance", f'label_values({REQ}_count{{service="$service"}}, instance)', "Instance", multi=True, include_all=True,
          current="All")]
gs = [
    stat("Availability (time range)", {"x": 0, "y": 0, "w": 6, "h": 4},
         f'1 - (sum(increase({REQ}_count{SEL5}[$__range])) or vector(0)) / sum(increase({REQ}_count{SEL}[$__range]))',
         "percentunit", thresholds(("red", None), ("orange", 0.99), ("green", 0.999)),
         "Share of requests without a 5xx status over the whole time range: the number an SLO is about", decimals=2),
    stat("Traffic now", {"x": 6, "y": 0, "w": 6, "h": 4}, f'sum(rate({REQ}_count{SEL}[5m]))', "reqps",
         thresholds(("blue", None)), "Requests per second over the last 5 minutes of the range", decimals=2),
    stat("Error rate now", {"x": 12, "y": 0, "w": 6, "h": 4},
         f'(sum(rate({REQ}_count{SEL5}[5m])) or vector(0)) / sum(rate({REQ}_count{SEL}[5m]))', "percentunit",
         thresholds(("green", None), ("orange", 0.01), ("red", 0.05)), "5xx share over the last 5 minutes", decimals=2),
    stat("p95 latency now", {"x": 18, "y": 0, "w": 6, "h": 4},
         f'histogram_quantile(0.95, sum by (le) (rate({REQ}_bucket{SEL}[5m])))', "s",
         thresholds(("green", None), ("orange", 0.5), ("red", 1)), "95th percentile over the last 5 minutes", decimals=2),
    ts("Latency", {"x": 0, "y": 4, "w": 12, "h": 8},
       [target(P["q"](0.5), "p50"), target(P["q"](0.95), "p95", "B"), target(P["q"](0.99), "p99", "C")], "s",
       "Percentiles from the request duration histogram", thr=thresholds(("green", None), ("red", 1)),
       overrides=[{"matcher": {"id": "byName", "options": "p99"},
                   "properties": [{"id": "custom.lineStyle", "value": {"fill": "dash", "dash": [10, 10]}}]}]),
    ts("Traffic", {"x": 12, "y": 4, "w": 12, "h": 8}, [target(P["rps_uri"], "{{uri}}")], "reqps",
       "Requests per second by URI", stacking={"mode": "normal", "group": "A"}),
    ts("Errors", {"x": 0, "y": 12, "w": 12, "h": 8}, [target(P["err"], "5xx share")], "percentunit",
       "Share of requests with a 5xx status", thr=thresholds(("green", None), ("orange", 0.01), ("red", 0.05))),
    ts("Saturation", {"x": 12, "y": 12, "w": 12, "h": 8},
       [target(P["threads"], "threads {{instance}}"), target(P["cpu"], "CPU {{instance}}", "B")], "percentunit",
       "Worker threads busy (peak in the window) and CPU, as a share of the maximum", min=0, max=1,
       thr=thresholds(("green", None), ("red", 1)),
       overrides=[{"matcher": {"id": "byRegexp", "options": "CPU.*"},
                   "properties": [{"id": "custom.lineStyle", "value": {"fill": "dash", "dash": [10, 10]}}]}]),
]
for p in gs:
    if p["type"] == "timeseries":
        p["fieldConfig"]["defaults"]["custom"].pop("min", None)
for p in gs[7:8]:
    p["fieldConfig"]["defaults"].update({"min": 0, "max": 1})
golden = dash("easytravel-golden-signals", "easyTravel golden signals", gs, ["obs-day5", "easytravel", "golden-signals"],
              TV, desc="Latency, traffic, errors and saturation of one service (Lab 5.3, one possible answer)")

# ---------------------------------------------------------------------------------------- Part B: the dashboard to fix
_id[0] = 0
v1 = [
    {"id": nid(), "type": "logs", "title": "All logs", "datasource": LOKI, "gridPos": {"x": 0, "y": 0, "w": 24, "h": 10},
     "targets": [target('{job="easytravel"}', ds=LOKI, queryType="range")], "options": {"showTime": True, "wrapLogMessage": True}},
    {"id": nid(), "type": "gauge", "title": "Uptime", "datasource": PROM, "gridPos": {"x": 0, "y": 10, "w": 6, "h": 6},
     "targets": [target("up")], "fieldConfig": {"defaults": {"unit": "short"}, "overrides": []}, "options": {}},
    ts("Total requests", {"x": 6, "y": 10, "w": 18, "h": 6}, [target(f'{REQ}_count')], "short"),
    {"id": nid(), "type": "piechart", "title": "Requests by status", "datasource": PROM, "gridPos": {"x": 0, "y": 16, "w": 8, "h": 8},
     "targets": [target(f'sum by (status) ({REQ}_count)', "{{status}}")], "fieldConfig": {"defaults": {}, "overrides": []},
     "options": {"reduceOptions": {"calcs": ["lastNotNull"]}, "pieType": "pie"}},
    ts("CPU", {"x": 8, "y": 16, "w": 8, "h": 8}, [target("process_cpu_usage", "{{instance}}")], "percent"),
    ts("Threads", {"x": 16, "y": 16, "w": 8, "h": 8}, [target("tomcat_threads_busy_threads")], "short"),
    ts("Avg response time", {"x": 0, "y": 24, "w": 8, "h": 8},
       [target(f'sum(rate({REQ}_sum[5m])) / sum(rate({REQ}_count[5m]))')], "short"),
    ts("Errors", {"x": 8, "y": 24, "w": 8, "h": 8}, [target(f'sum(rate({REQ}_count{{status="500"}}[10s]))')], "short"),
    ts("Load", {"x": 16, "y": 24, "w": 8, "h": 8}, [target("system_load_average_1m", "{{instance}}")], "short"),
    ts("Requests per second", {"x": 0, "y": 32, "w": 24, "h": 6}, [target(f'sum(rate({REQ}_count[1m]))')], "reqps"),
]
ops1 = dash("easytravel-ops", "easyTravel operations", v1, ["obs-day5", "easytravel"],
            desc="The operations dashboard as the team built it over time (Lab 5.3, Part B: improve it)")

# ---------------------------------------------------------------------------------------- Part B: one possible answer
_id[0] = 0
SALL, SALL5 = '{job="easytravel"}', '{job="easytravel", status=~"5.."}'
v2 = [
    row("Golden signals, both services", 0),
    ts("Traffic", {"x": 0, "y": 1, "w": 6, "h": 7}, [target(f'sum by (service) (rate({REQ}_count{SALL}[$__rate_interval]))', "{{service}}")],
       "reqps", "Requests per second"),
    ts("Errors", {"x": 6, "y": 1, "w": 6, "h": 7},
       [target(f'sum by (service) (rate({REQ}_count{SALL5}[$__rate_interval])) / sum by (service) (rate({REQ}_count{SALL}[$__rate_interval]))',
               "{{service}}")], "percentunit", "Share of requests with a 5xx status (500 and 503)",
       thr=thresholds(("green", None), ("orange", 0.01), ("red", 0.05))),
    ts("Latency p95", {"x": 12, "y": 1, "w": 6, "h": 7},
       [target(f'histogram_quantile(0.95, sum by (le, service) (rate({REQ}_bucket{SALL}[$__rate_interval])))', "{{service}}")],
       "s", "95th percentile, not the average", thr=thresholds(("green", None), ("red", 1))),
    ts("Saturation: backend threads busy", {"x": 18, "y": 1, "w": 6, "h": 7},
       [target('max_over_time(tomcat_threads_busy_threads{service="easytravel-backend"}[$__rate_interval]) / tomcat_threads_config_max_threads{service="easytravel-backend"}',
               "{{instance}}")], "percentunit", "Peak busy worker threads as a share of the maximum",
       thr=thresholds(("green", None), ("orange", 0.8), ("red", 1))),
    row("Details", 8, collapsed=True, panels=[
        ts("CPU by instance", {"x": 0, "y": 9, "w": 8, "h": 7}, [target("avg_over_time(process_cpu_usage[$__rate_interval])", "{{instance}}")],
           "percentunit", "Process CPU, 0 to 100 %"),
        ts("Load per core", {"x": 8, "y": 9, "w": 8, "h": 7},
           [target("system_load_average_1m / on (instance) system_cpu_count", "{{instance}}")], "short",
           "1-minute load average divided by the number of cores; above 1 means work is queueing",
           thr=thresholds(("green", None), ("red", 1))),
        ts("5xx by status", {"x": 16, "y": 9, "w": 8, "h": 7},
           [target(f'sum by (service, status) (rate({REQ}_count{SALL5}[$__rate_interval]))', "{{service}} {{status}}")], "reqps"),
        {"id": nid(), "type": "logs", "title": "Warnings and errors", "datasource": LOKI, "gridPos": {"x": 0, "y": 16, "w": 24, "h": 8},
         "targets": [target('{service="backend"} | json | level=~"WARN|ERROR"', ds=LOKI, queryType="range")],
         "options": {"showTime": True, "wrapLogMessage": True, "sortOrder": "Descending"}},
    ]),
]
ops2 = dash("easytravel-ops", "easyTravel operations", v2, ["obs-day5", "easytravel"], links=[LINK_GS],
            desc="Golden signals first, details folded away (Lab 5.3, one possible answer)")

os.makedirs(os.path.join(HERE, "solutions"), exist_ok=True)
for path, d in [("ops-easytravel-v1.json", ops1), ("solutions/golden-signals.json", golden), ("solutions/ops-easytravel-v2.json", ops2)]:
    with open(os.path.join(HERE, path), "w") as f:
        json.dump(d, f, indent=2)
    n = sum(1 + len(p.get("panels", [])) for p in d["panels"])
    print(f"wrote grafana/{path} ({n} panels)")
