# Partner search: DynamoDB throttling (AWS)

| | |
| --- | --- |
| **Severity** | critical when the Errors metric of easytravel-partner-search is above 1 % for 5 minutes |
| **Owner** | integrations team |
| **Alarm** | CloudWatch alarm on EasyTravel/Lambda Errors and Invocations (metric math) |

## What it means
Partner searches fail: DynamoDB rejects requests to the table et-journeys (ProvisionedThroughputExceededException)
or the function times out after 6 seconds.

## Check first (5 minutes)
1. Logs Insights on /aws/lambda/easytravel-partner-search: `filter level = "ERROR" | stats count(*) by exception_name, version`
2. Which version? A new version that scans instead of queries reads the whole table.
3. X-Ray: traces with `fault`, then one trace: how many DynamoDB calls, and which operation (Scan or Query)?

## Mitigate
Point the alias back to the previous version (Lambda console, Aliases, live, Edit). Raising the table's capacity buys
time but costs money and does not fix a Scan.

## Escalate
Partner-facing: tell the partner managers if errors last more than 15 minutes.
