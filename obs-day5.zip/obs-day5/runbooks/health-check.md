# HealthCheckFailed

| | |
| --- | --- |
| **Severity** | critical only when two or more probe locations fail; one location alone: warning |
| **Owner** | web team |

## What it means
The synthetic health check of www.easytravel.example.com failed from the probe locations listed in the alert.

## Check first (5 minutes)
1. How many locations? One location (often ap-south) alone is usually that location's network, not our site.
2. Is the golden signals dashboard of the frontend healthy? Real users are the better signal.

## Mitigate
Site down from several locations: follow error-ratio.md. One location: open a ticket with the monitoring provider.
