# EasyTravelErrorRatioHigh

| | |
| --- | --- |
| **Severity** | critical (pages the on-call engineer) |
| **Owner** | app team |
| **Alert rule** | alerts/rules-proposed.yml, EasyTravelErrorRatioHigh |
| **Dashboard** | easyTravel golden signals (`/d/easytravel-golden-signals`) |

## What it means
More than 2 % of the requests of one service have failed with a 5xx status for at least 3 minutes (5-minute window).
Users see error pages; bookings may be lost.

## Check first (5 minutes)
1. Golden signals dashboard, the alerting service: is the error rate still rising? Latency and saturation too?
2. Which pages? In Explore (Prometheus): `sum by (uri, status) (rate(http_server_requests_seconds_count{service="<service>", status=~"5.."}[5m]))`
3. What do the logs say? In Explore (Loki): `{service="backend"} | json | level="ERROR"`, then `sum by (operation) (count_over_time({service="backend"} | json | level="ERROR" [5m]))`
4. What changed? Deployment annotations on the dashboard (`{service="backend"} |= "JourneyService 3."`), the change calendar.
5. Is the backend saturated? If the worker threads are at 100 %, also follow thread-pool.md.

## Mitigate
1. A deployment in the last hour: roll it back (deployment pipeline, "Roll back to previous version").
2. A failing dependency: follow its runbook (payment gateway: payment-gateway.md).
3. Overload: add backend instances; as a last resort, turn off the expensive feature with its feature flag.

## Escalate
After 15 minutes without improvement, or at once if bookings fail: the app team lead, then the incident manager.

## Afterwards
Open a post-incident review if users were affected for more than 5 minutes.
