# <AlertName>

| | |
| --- | --- |
| **Severity** | critical / warning |
| **Owner** | team |
| **Alert rule** | file and rule name |
| **Dashboard** | link |

## What it means
One or two sentences: what the expression measures and what the threshold says about users.

## Check first (5 minutes)
1. Is it real? Open the dashboard; compare with the last hour and the same time yesterday.
2. How big? Which service, instances, regions, customers?
3. What changed? Deployments, configuration, feature flags, the dependency's status page.

## Mitigate
The safe, reversible actions, in order, with the exact commands or console steps.

## Escalate
Who, when (for example "after 15 minutes without improvement"), and how.

## Afterwards
Ticket, post-incident review, and: was this alert useful? If not, change the rule.
