# Payment gateway failing (Azure, Application Insights)

| | |
| --- | --- |
| **Severity** | critical |
| **Owner** | app team, with the payment provider |
| **Alert** | Azure Monitor log search alert on the dependencies table (Lab 5.1) |

## What it means
Calls from easytravel-backend to payments.example.com fail (503 or 504). Bookings fail with 500; card declines (402)
are normal business results and are not part of this alert.

## Check first (5 minutes)
1. Failure rate and codes (Logs, KQL):
   `dependencies | where target == "payments.example.com" | summarize calls = count(), failures = countif(resultCode in ("503", "504")) by bin(timestamp, 5m)`
2. Health probe: `traces | where message startswith "Payment gateway health probe"` (failed or OK, every 30 s per instance).
3. The provider's status page and support channel.

## Mitigate
Show the "payment temporarily unavailable, try again" page instead of an error (feature flag `payments.degraded-mode`);
switch to the secondary provider if the contract has one. Do not retry harder: it adds load to a failing gateway.

## Escalate
Open a priority ticket with the provider at once; inform customer support (failed bookings).
