# BackendThreadPoolSaturated

| | |
| --- | --- |
| **Severity** | warning |
| **Owner** | app team |
| **Alert rule** | alerts/rules-proposed.yml, BackendThreadPoolSaturated |
| **Dashboard** | easyTravel golden signals, service easytravel-backend, panel Saturation |

## What it means
All worker threads of a backend instance have been busy for 2 minutes. New requests are rejected with 503
("all worker threads busy"); the frontend turns them into 500 pages. It is a cause: expect error and latency alerts next.

## Check first (5 minutes)
1. Which instances? `max_over_time(tomcat_threads_busy_threads{service="easytravel-backend"}[2m]) / tomcat_threads_config_max_threads{service="easytravel-backend"}`
2. Why are threads held longer? Backend p95 per operation; the slowest one is usually the reason.
3. More traffic, or slower work? Compare requests per second with an hour ago.

## Mitigate
1. Slower work after a deployment: roll back.
2. More traffic: add backend instances.
3. Do not raise the thread limit as a first step: it hides the problem and moves it to the CPU or the database.

## Escalate
If error alerts follow, the error-ratio runbook takes over.
