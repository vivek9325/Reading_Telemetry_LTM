# EasyTravelLatencySLO and EasyTravelLatencyAnomaly

| | |
| --- | --- |
| **Severity** | SLO: critical; anomaly: warning |
| **Owner** | app team |
| **Alert rules** | alerts/rules-proposed.yml, EasyTravelLatencySLO and EasyTravelLatencyAnomaly |
| **Dashboard** | easyTravel golden signals (`/d/easytravel-golden-signals`) |

## What it means
SLO: the 95th percentile response time has been above 1 second for 5 minutes: one user in twenty waits longer than our
objective. Anomaly: p95 is more than three standard deviations above its last 30 minutes (and above 0.25 s), an early
warning that often comes before the SLO alert.

## Check first (5 minutes)
1. Golden signals dashboard: which service, and is it every page or one? `histogram_quantile(0.95, sum by (le, uri) (rate(http_server_requests_seconds_bucket{service="<service>"}[5m])))`
2. Backend first: if the backend's p95 rose, the frontend follows. Per backend operation: `... by (le, uri)` with `service="easytravel-backend"`.
3. Saturation: worker threads busy, CPU, load per core. A full thread pool turns slowness into errors (thread-pool.md).
4. What changed in the last hour?

## Mitigate
Roll back a recent deployment; scale out the backend; for a slow dependency, follow its runbook.

## Escalate
SLO alert for more than 15 minutes: app team lead. Anomaly alone: no escalation, watch the SLO alert.

## Afterwards
If the anomaly alert fired without user impact, record it in the alert review (threshold or window too sensitive?).
