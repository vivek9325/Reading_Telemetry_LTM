#!/usr/bin/env python3
"""Build the Day 5 data (fixed seed, same output every run).

    python3 make_data.py

All data is invented (example.com names, documentation IP ranges, made-up partner names). The stories are in the
Lab Guide, Appendix: investigate first.

data/azure/*.csv      Application Insights tables of easyTravel on Azure (requests, dependencies, exceptions, traces),
                      24 November 2026, 09:00 to 11:00 UTC, for an Azure Data Explorer database (Lab 5.1)
data/aws/logs.jsonl   CloudWatch Logs events of two Lambda functions over two hours (Lab 5.2)
data/aws/segments.jsonl  X-Ray segment documents of the same invocations
data/aws/metrics.jsonl   per-minute custom metrics of the same invocations
                      The AWS times are offsets from T0: bin/load_aws.py moves T0 to about two hours before you load,
                      because CloudWatch Logs only accepts events from the last 14 days.
alerts/alert_history.csv  14 days of alert notifications for easyTravel (Lab 5.4)
"""
import csv, hashlib, json, math, os, random
from collections import defaultdict
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
R = random.Random(20261124)
UTC = timezone.utc
hexid = lambda n: "".join(R.choice("0123456789abcdef") for _ in range(n))
lognorm = lambda median, spread: median * math.exp(R.gauss(0, spread))

# ----------------------------------------------------------------------------------------------- Azure
A0 = datetime(2026, 11, 24, 9, 0, tzinfo=UTC)
DUR = 7200
PAY_DOWN, PAY_UP = 50 * 60 + 20, 80 * 60 + 40          # payments.example.com outage: 09:50:20 to 10:20:40
WEB, APP = ["web-01", "web-02"], ["app-01", "app-02"]
DESTS = ["Lisbon", "Vienna", "Tokyo", "Paris", "Rome", "Sydney", "Toronto", "Singapore"]
BUCKETS = [(250, "<250ms"), (500, "250ms-500ms"), (1000, "500ms-1sec"), (3000, "1sec-3sec"), (7000, "3sec-7sec"),
           (15000, "7sec-15sec"), (30000, "15sec-30sec"), (60000, "30sec-1min")]


def bucket(ms):
    return next((b for lim, b in BUCKETS if ms < lim), "1min-2min")


def iso(sec):
    return (A0 + timedelta(seconds=sec)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


REQ_COLS = ["timestamp", "id", "name", "url", "success", "resultCode", "duration", "performanceBucket", "itemCount",
            "operation_Name", "operation_Id", "operation_ParentId", "cloud_RoleName", "cloud_RoleInstance"]
DEP_COLS = ["timestamp", "id", "target", "type", "name", "data", "success", "resultCode", "duration",
            "performanceBucket", "itemCount", "operation_Name", "operation_Id", "operation_ParentId",
            "cloud_RoleName", "cloud_RoleInstance"]
EXC_COLS = ["timestamp", "problemId", "type", "outerType", "outerMessage", "innermostType", "innermostMessage",
            "severityLevel", "itemCount", "operation_Name", "operation_Id", "operation_ParentId", "cloud_RoleName",
            "cloud_RoleInstance"]
TRC_COLS = ["timestamp", "message", "severityLevel", "itemCount", "operation_Name", "operation_Id",
            "operation_ParentId", "cloud_RoleName", "cloud_RoleInstance", "customDimensions"]
requests, deps, excs, traces = [], [], [], []
booking_no = 0


def pay_outcome(t):
    """Result of the payment gateway call: (resultCode, duration ms)."""
    if PAY_DOWN <= t < PAY_UP:
        ramp = min(1.0, (t - PAY_DOWN) / 120, (PAY_UP - t) / 150)       # two minutes to fail fully, recovers slowly
        r = R.random()
        if r < 0.62 * ramp:
            return "503", lognorm(38, 0.3)
        if r < 0.86 * ramp:
            return "504", R.uniform(10000, 10060)
    if R.random() < 0.03:
        return "402", lognorm(160, 0.25)                                 # card declined: normal business result
    return "200", lognorm(180, 0.3)


def add_dep(lst, t, role, inst, op, opid, parent, target, typ, name, data, code, dur):
    did = hexid(16)
    ok = code in ("200", "201", "0") if typ != "HTTP" else int(code) < 400
    lst.append(dict(timestamp=iso(t), id=did, target=target, type=typ, name=name, data=data, success=ok,
                    resultCode=code, duration=round(dur, 3), performanceBucket=bucket(dur), itemCount=1,
                    operation_Name=op, operation_Id=opid, operation_ParentId=parent, cloud_RoleName=role,
                    cloud_RoleInstance=inst))
    return did


def add_exc(t, role, inst, op, opid, parent, typ, msg, sev, inner=None, inner_msg=None, method=""):
    short = typ.rsplit(".", 1)[-1]
    excs.append(dict(timestamp=iso(t), problemId=f"{typ} at {method}", type=typ, outerType=typ, outerMessage=msg,
                     innermostType=inner or typ, innermostMessage=inner_msg or msg, severityLevel=sev, itemCount=1,
                     operation_Name=op, operation_Id=opid, operation_ParentId=parent, cloud_RoleName=role,
                     cloud_RoleInstance=inst))


def add_trace(t, role, inst, msg, sev, op="", opid="", parent="", **dims):
    traces.append(dict(timestamp=iso(t), message=msg, severityLevel=sev, itemCount=1, operation_Name=op,
                       operation_Id=opid, operation_ParentId=parent, cloud_RoleName=role, cloud_RoleInstance=inst,
                       customDimensions=json.dumps(dict({"LoggerName": dims.pop("logger", "com.example.easytravel"),
                                                         "SourceType": "Logger"}, **dims))))


def backend(t, page, inst, opid, parent):
    """One Business Backend request; returns (resultCode, duration ms)."""
    global booking_no
    name = {"search": "GET /services/JourneyService/findJourneys", "details": "GET /services/JourneyService/getJourneyById",
            "booking": "POST /services/BookingService/storeBooking"}[page]
    rid, cur, code = hexid(16), t + R.uniform(0.002, 0.006), "200"
    role = "easytravel-backend"
    db = "et-sql.example.com"
    if page == "search":
        rc_fail = R.random() < 0.004
        d = R.uniform(1000, 1004) if rc_fail else lognorm(1.8, 0.35)
        add_dep(deps, cur, role, inst, name, opid, rid, "et-cache.example.com", "Redis", "GET journeys:destination",
                "GET journeys:destination:" + R.choice(DESTS), "" if rc_fail else "0", d)
        if rc_fail:
            add_exc(cur + d / 1000, role, inst, name, opid, rid, "redis.clients.jedis.exceptions.JedisConnectionException",
                    "java.net.SocketTimeoutException: Read timed out", 2, "java.net.SocketTimeoutException",
                    "Read timed out", "com.example.easytravel.cache.JourneyCache.get")
            add_trace(cur + d / 1000, role, inst, "Journey cache lookup failed, falling back to the database", 2,
                      name, opid, rid, logger="com.example.easytravel.cache.JourneyCache")
        cur += d / 1000
        if rc_fail or R.random() < 0.08:
            d = lognorm(26, 0.4)
            add_dep(deps, cur, role, inst, name, opid, rid, db, "SQL", "SELECT journeys",
                    "SELECT * FROM journeys WHERE destination = @p0", "0", d)
            cur += d / 1000
    elif page == "details":
        d = lognorm(8, 0.4)
        add_dep(deps, cur, role, inst, name, opid, rid, db, "SQL", "SELECT journey", "SELECT * FROM journeys WHERE id = @p0", "0", d)
        cur += d / 1000
    else:
        code_pay, d_pay = pay_outcome(cur)
        d_pay_call = cur
        add_dep(deps, cur, role, inst, name, opid, rid, "payments.example.com", "HTTP", "POST /v2/authorize",
                "https://payments.example.com/v2/authorize", code_pay, d_pay)
        cur += d_pay / 1000
        if code_pay in ("503", "504"):
            reason = "503 Service Unavailable" if code_pay == "503" else "504 Gateway Timeout"
            add_exc(cur, role, inst, name, opid, rid, "com.example.easytravel.payment.CreditCardAuthorizationException",
                    f"Payment gateway returned {reason}", 3, method="com.example.easytravel.payment.PaymentClient.authorize")
            add_trace(cur, role, inst, f"Payment authorization failed: gateway returned {code_pay}", 3, name, opid, rid,
                      logger="com.example.easytravel.payment.PaymentClient")
            code = "500"
        elif code_pay == "402":
            add_trace(cur, role, inst, "Payment declined by card issuer", 1, name, opid, rid,
                      logger="com.example.easytravel.payment.PaymentClient")
            code = "402"
        else:
            for attempt in range(2):
                d = lognorm(12, 0.35)
                dead = attempt == 0 and R.random() < 0.004
                add_dep(deps, cur, role, inst, name, opid, rid, db, "SQL", "INSERT bookings",
                        "INSERT INTO bookings (journey_id, customer_id, amount) VALUES (@p0, @p1, @p2)", "1205" if dead else "0", d)
                cur += d / 1000
                if not dead:
                    break
                add_exc(cur, role, inst, name, opid, rid, "com.microsoft.sqlserver.jdbc.SQLServerException",
                        "Transaction (Process ID 61) was deadlocked on lock resources with another process and has been chosen as the deadlock victim. Rerun the transaction.",
                        2, method="com.example.easytravel.booking.BookingRepository.insert")
            booking_no += 1
            add_trace(cur, role, inst, f"Booking stored id=BK-2611-{booking_no:05d}", 1, name, opid, rid,
                      logger="com.example.easytravel.booking.BookingService", bookingId=f"BK-2611-{booking_no:05d}")
    dur = (cur - t) * 1000 + R.uniform(1.5, 6)
    requests.append(dict(timestamp=iso(t), id=rid, name=name, url=f"http://easytravel-backend:8091{name.split(' ')[1]}",
                         success=int(code) < 400, resultCode=code, duration=round(dur, 3), performanceBucket=bucket(dur),
                         itemCount=1, operation_Name=name, operation_Id=opid, operation_ParentId=parent,
                         cloud_RoleName=role, cloud_RoleInstance=inst))
    return code, dur, name, rid


t = 0.0
while True:
    t += R.expovariate(1.0)
    if t >= DUR:
        break
    page = R.choices(["search", "details", "booking"], [0.6, 0.25, 0.15])[0]
    web, app = R.choice(WEB), R.choice(APP)
    opid, fid, did = hexid(32), hexid(16), None
    fe_name = {"search": "GET /orange.jsf", "details": "GET /orange-trip-details.jsf", "booking": "POST /orange-booking-payment.jsf"}[page]
    url = {"search": f"https://www.easytravel.example.com/orange.jsf?destination={R.choice(DESTS)}",
           "details": f"https://www.easytravel.example.com/orange-trip-details.jsf?journeyId={R.randint(1000, 9999)}",
           "booking": "https://www.easytravel.example.com/orange-booking-payment.jsf"}[page]
    did_t = t + R.uniform(0.001, 0.004)
    # the frontend's call to the backend: write the dependency after the backend request (we need its result)
    did = hexid(16)
    code_be, dur_be, be_name, be_id = backend(did_t + 0.001, page, app, opid, did)
    dep_dur = dur_be + R.uniform(0.8, 2.5)
    deps.append(dict(timestamp=iso(did_t), id=did, target="easytravel-backend:8091", type="HTTP", name=be_name,
                     data=f"http://easytravel-backend:8091{be_name.split(' ')[1]}", success=int(code_be) < 400,
                     resultCode=code_be, duration=round(dep_dur, 3), performanceBucket=bucket(dep_dur), itemCount=1,
                     operation_Name=fe_name, operation_Id=opid, operation_ParentId=fid,
                     cloud_RoleName="easytravel-frontend", cloud_RoleInstance=web))
    fe_code = "500" if code_be == "500" else "200"
    fe_dur = (did_t - t) * 1000 + dep_dur + R.uniform(4, 18)
    if fe_code == "500":
        add_exc(t + fe_dur / 1000, "easytravel-frontend", web, fe_name, opid, fid, "com.example.easytravel.web.BookingFailedException",
                "Booking failed: easytravel-backend returned 500", 3, method="com.example.easytravel.web.BookingBean.pay")
    requests.append(dict(timestamp=iso(t), id=fid, name=fe_name, url=url, success=fe_code == "200", resultCode=fe_code,
                         duration=round(fe_dur, 3), performanceBucket=bucket(fe_dur), itemCount=1, operation_Name=fe_name,
                         operation_Id=opid, operation_ParentId=opid, cloud_RoleName="easytravel-frontend",
                         cloud_RoleInstance=web))

# background traces: a payment gateway health probe every 30 s on each backend instance, a cache report every 5 min
for app in APP:
    off = 7 if app == "app-01" else 21
    for s in range(off, DUR, 30):
        down = PAY_DOWN + 40 <= s < PAY_UP - 30
        add_trace(s + R.uniform(0, 0.3), "easytravel-backend", app,
                  "Payment gateway health probe failed: payments.example.com returned 503" if down else "Payment gateway health probe OK",
                  2 if down else 0, logger="com.example.easytravel.payment.GatewayProbe")
    for s in range(off + 120, DUR, 300):
        add_trace(s, "easytravel-backend", app, f"Journey cache hit ratio {R.uniform(0.9, 0.94):.2f} over the last 5 minutes", 1,
                  logger="com.example.easytravel.cache.JourneyCache")

os.makedirs(os.path.join(HERE, "data", "azure"), exist_ok=True)
for name, rows, cols in [("requests", requests, REQ_COLS), ("dependencies", deps, DEP_COLS), ("exceptions", excs, EXC_COLS),
                         ("traces", traces, TRC_COLS)]:
    rows.sort(key=lambda r: r["timestamp"])
    with open(os.path.join(HERE, "data", "azure", f"{name}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow({k: (str(v).lower() if isinstance(v, bool) else v) for k, v in r.items()})
print(f"azure: {len(requests):,} requests, {len(deps):,} dependencies, {len(excs):,} exceptions, {len(traces):,} traces")

# ----------------------------------------------------------------------------------------------- AWS
# Offsets in seconds from T0. The loader replaces the time tokens in the text:
#   {{iso:<ms>}}  2026-11-24T13:00:00.000Z     {{pt:<ms>}}  2026-11-24 13:00:00,000+0000 (Powertools)
#   {{xe:<s>}}    8 hex digits of the epoch second (inside X-Ray trace IDs)      {{day:<s>}}  2026/11/24
DEPLOY, ROLLBACK = 40 * 60, 85 * 60                    # partner-search version 14 (Scan) and back to 13 (Query)
REGION, ACCOUNT = "eu-west-1", "111122223333"
PARTNERS = [("skyline-travel", 0.45), ("globetrek", 0.35), ("sunway-holidays", 0.20)]
CITIES = ["VIE", "LIS", "BCN", "AMS", "PRG", "CDG", "FCO", "BER"]
logs, segs = [], []
metrics = defaultdict(lambda: defaultdict(lambda: {"Invocations": 0, "Errors": 0, "ThrottledRequests": 0, "dur": []}))
stats = defaultdict(int)


def uuid4():
    h = hexid(32)
    return f"{h[:8]}-{h[8:12]}-4{h[13:16]}-{R.choice('89ab')}{h[17:20]}-{h[20:32]}"


class Pool:
    """Lambda execution environments of one function: reuse a free warm one, else cold start."""
    def __init__(self):
        self.envs = []                                  # [free_at, last_used, version, stream_hex, created]

    def get(self, t, version):
        self.envs = [e for e in self.envs if e[2] == version and t - e[1] < 600 and t - e[4] < 7200]
        free = [e for e in self.envs if e[0] <= t]
        if free:
            return min(free, key=lambda e: e[1]), False
        e = [t, t, version, hexid(32), t]
        self.envs.append(e)
        return e, True


def pt(off):
    return "{{pt:%d}}" % round(off * 1000)


def log(fn, env, off, msg):
    logs.append({"group": f"/aws/lambda/{fn}", "stream": "{{day:%d}}/[%s]%s" % (int(env[4]), env[2], env[3]),
                 "t": round(off * 1000), "message": msg})


def powertools(fn, svc, off, level, message, rid, tid, cold, version, mem, **extra):
    d = {"level": level, "location": "handler:" + str(extra.pop("line", 41)), "message": message, "timestamp": pt(off),
         "service": svc, "cold_start": cold, "function_name": fn, "function_memory_size": str(mem),
         "function_arn": f"arn:aws:lambda:{REGION}:{ACCOUNT}:function:{fn}", "function_request_id": rid,
         "xray_trace_id": tid, "version": version}
    d.update(extra)
    return json.dumps(d)


def invocation(fn, svc, pool, t, version, mem, body):
    """Writes the logs, the X-Ray segment and the metrics of one invocation. body(...) returns the outcome."""
    env, cold = pool.get(t, version)
    rid, sid = uuid4(), hexid(16)
    tid = "1-{{xe:%d}}-%s" % (int(t), hexid(24))
    init = R.uniform(380, 720) if cold else 0.0
    start = t + init / 1000
    log(fn, env, t, f"START RequestId: {rid} Version: {version}")
    out = body(start, rid, tid, cold, env)
    dur = out["dur"]
    end = start + dur / 1000
    timeout = out.get("timeout")
    if timeout:
        log(fn, env, start + 6.0, "{{iso:%d}} %s Task timed out after 6.00 seconds" % (round((start + 6.0) * 1000), rid))
    elif out.get("unhandled"):
        log(fn, env, end - 0.001, out["unhandled"])
    log(fn, env, end, f"END RequestId: {rid}")
    billed = math.ceil(dur + init)
    rep = (f"REPORT RequestId: {rid}\tDuration: {dur:.2f} ms\tBilled Duration: {billed} ms\tMemory Size: {mem} MB\t"
           f"Max Memory Used: {out['mem']} MB\t" + (f"Init Duration: {init:.2f} ms\t" if cold else "")
           + ("Status: timeout\t" if timeout else "") + f"\nXRAY TraceId: {tid}\tSegmentId: {sid}\tSampled: true\t")
    log(fn, env, end + 0.0005, rep)
    env[0], env[1] = end + 0.01, end
    failed = bool(timeout or out.get("unhandled"))
    # X-Ray: the function segment with Initialization and Invocation subsegments
    inv = {"id": hexid(16), "name": "Invocation", "start_time": start, "end_time": end, "subsegments": out["subs"]}
    subs = ([{"id": hexid(16), "name": "Initialization", "start_time": t, "end_time": start}] if cold else []) + [inv]
    seg = {"name": fn, "id": sid, "trace_id": tid, "start_time": t, "end_time": end, "origin": "AWS::Lambda::Function",
           "aws": {"account_id": ACCOUNT, "function_arn": f"arn:aws:lambda:{REGION}:{ACCOUNT}:function:{fn}:{version}",
                   "cloudwatch_logs": [{"log_group": f"/aws/lambda/{fn}"}]},
           "annotations": dict(out["ann"], version=version, cold_start=cold), "subsegments": subs}
    if failed:
        seg["fault"] = True
        msg = "Task timed out after 6.00 seconds" if timeout else out["exc"][1]
        typ = "Sandbox.Timedout" if timeout else out["exc"][0]
        seg["cause"] = {"exceptions": [{"id": hexid(16), "type": typ, "message": msg}]}
        inv["fault"] = True
    segs.append(seg)
    m = metrics[fn][int(t // 60)]
    m["Invocations"] += 1
    m["Errors"] += failed
    m["ThrottledRequests"] += out.get("throttled", 0)
    m["dur"].append(dur)
    stats[(fn, "cold")] += cold
    stats[(fn, "failed")] += failed
    stats[(fn, "timeout")] += bool(timeout)


def search_body(t, ver):
    def body(start, rid, tid, cold, env):
        fn, svc = "easytravel-partner-search", "partner-search"
        partner = R.choices([p for p, _ in PARTNERS], [w for _, w in PARTNERS])[0]
        a, b = R.sample(CITIES, 2)
        route = f"{a}-{b}"
        logs_before = powertools(fn, svc, start + 0.0008, "INFO", "partner search", rid, tid, cold, ver, 512,
                                 partner=partner, route=route)
        log(fn, env, start + 0.0008, logs_before)
        cur = start + R.uniform(0.004, 0.009)
        scan = ver == "14"
        subs, throttled, outcome = [], 0, "ok"
        if scan:
            # load on the table rises while version 14 runs; more concurrent scans throttle more
            k = min(1.0, (t - DEPLOY - 120) / 600) if t > DEPLOY + 120 else 0.0
            p_thr = 0.05 + 0.33 * k
        else:
            p_thr = 0.0006
        for attempt in range(3):
            d = (lognorm(1100, 0.45) * (1 + 0.6 * (p_thr > 0.2))) if scan else lognorm(32, 0.35)
            thr = R.random() < p_thr
            sub = {"id": hexid(16), "name": "DynamoDB", "namespace": "aws", "start_time": cur,
                   "aws": {"operation": "Scan" if scan else "Query", "table_name": "et-journeys", "region": REGION,
                           "request_id": hexid(32).upper()[:32], "retries": attempt}}
            if thr:
                d = d * R.uniform(0.15, 0.4)
                sub.update(error=True, http={"response": {"status": 400}},
                           cause={"exceptions": [{"id": hexid(16), "type": "ProvisionedThroughputExceededException",
                                                  "message": "The level of configured provisioned throughput for the table was exceeded. Consider increasing your provisioning level with the UpdateTable API.",
                                                  "remote": True}]})
                throttled += 1
            else:
                sub["http"] = {"response": {"status": 200}}
            sub["end_time"] = cur + d / 1000
            subs.append(sub)
            cur += d / 1000
            if not thr:
                break
            cur += (0.05 * 2 ** attempt) * R.uniform(0.5, 1.0)        # retry back-off
            if cur - start > 6.0:
                break
        else:
            outcome = "throttled"
        items = R.randint(3, 24)
        mem = R.randint(178, 241) if scan else R.randint(86, 97)
        if cur - start > 6.0:
            return {"dur": R.uniform(6000.4, 6003.0), "timeout": True, "subs": subs, "mem": mem, "throttled": throttled,
                    "ann": {"partner": partner, "route": route}}
        if outcome == "throttled":
            err = ("ProvisionedThroughputExceededException",
                   "An error occurred (ProvisionedThroughputExceededException) when calling the Scan operation (reached max retries: 2): The level of configured provisioned throughput for the table was exceeded. Consider increasing your provisioning level with the UpdateTable API.")
            log(fn, env, cur, powertools(fn, svc, cur, "ERROR", "DynamoDB throttled the search", rid, tid, cold, ver, 512,
                                         line=58, partner=partner, route=route, exception_name=err[0],
                                         exception=f"botocore.errorfactory.{err[0]}: {err[1]}"))
            unhandled = (f"[ERROR] {err[0]}: {err[1]}\nTraceback (most recent call last):\n"
                         '  File "/var/task/handler.py", line 58, in handler\n    items = search(partner, route)\n'
                         '  File "/var/task/handler.py", line 33, in search\n    return table.scan(**kwargs)["Items"]')
            dur = (cur - start) * 1000 + R.uniform(1, 3)
            return {"dur": dur, "unhandled": unhandled, "exc": err, "subs": subs, "mem": mem, "throttled": throttled,
                    "ann": {"partner": partner, "route": route}}
        dur = (cur - start) * 1000 + R.uniform(2, 6)
        log(fn, env, start + dur / 1000 - 0.0005,
            powertools(fn, svc, start + dur / 1000 - 0.0005, "INFO", "search complete", rid, tid, cold, ver, 512, line=47,
                       partner=partner, route=route, items=items, dynamodb_attempts=len(subs)))
        return {"dur": dur, "subs": subs, "mem": mem, "throttled": throttled, "ann": {"partner": partner, "route": route}}
    return body


def notify_body():
    def body(start, rid, tid, cold, env):
        fn, svc = "easytravel-booking-notify", "booking-notify"
        bid = f"BK-2611-{R.randint(20000, 29999)}"
        log(fn, env, start + 0.001, powertools(fn, svc, start + 0.001, "INFO", "sending booking confirmation", rid, tid,
                                               cold, "7", 256, line=22, booking_id=bid))
        d = lognorm(85, 0.3)
        sub = {"id": hexid(16), "name": "SES", "namespace": "aws", "start_time": start + 0.003,
               "end_time": start + 0.003 + d / 1000, "aws": {"operation": "SendEmail", "region": REGION,
                                                             "request_id": uuid4()}}
        rejected = R.random() < 0.006
        if rejected:
            sub.update(error=True, http={"response": {"status": 400}},
                       cause={"exceptions": [{"id": hexid(16), "type": "MessageRejected",
                                              "message": "Email address is not verified.", "remote": True}]})
            end = start + 0.004 + d / 1000
            log(fn, env, end, powertools(fn, svc, end, "ERROR", "confirmation e-mail rejected, booking marked for retry",
                                         rid, tid, cold, "7", 256, line=31, booking_id=bid, exception_name="MessageRejected",
                                         exception="botocore.errorfactory.MessageRejected: An error occurred (MessageRejected) when calling the SendEmail operation: Email address is not verified."))
        else:
            sub["http"] = {"response": {"status": 200}}
        dur = d + R.uniform(5, 12)
        if not rejected:
            log(fn, env, start + dur / 1000 - 0.0005, powertools(fn, svc, start + dur / 1000 - 0.0005, "INFO",
                                                                  "confirmation sent", rid, tid, cold, "7", 256, line=29,
                                                                  booking_id=bid))
        return {"dur": dur, "subs": [sub], "mem": R.randint(71, 79), "ann": {"booking_id": bid}}
    return body


pools = {"search": Pool(), "notify": Pool()}
events = []
t = 0.0
while True:
    rate = 0.8 * (1 + 0.15 * math.sin(t / 1300))
    t += R.expovariate(rate)
    if t >= DUR:
        break
    events.append((t, "search"))
t = 0.0
while True:
    t += R.expovariate(0.12)
    if t >= DUR:
        break
    events.append((t, "notify"))
for t, kind in sorted(events):
    if kind == "search":
        ver = "14" if DEPLOY <= t < ROLLBACK else "13"
        invocation("easytravel-partner-search", "partner-search", pools["search"], t, ver, 512, search_body(t, ver))
    else:
        invocation("easytravel-booking-notify", "booking-notify", pools["notify"], t, "7", 256, notify_body())

# deployment markers in the logs of the deploying environment are not written by Lambda; the deploys are visible as
# version changes. Sort and write.
logs.sort(key=lambda e: (e["group"], e["stream"], e["t"]))
os.makedirs(os.path.join(HERE, "data", "aws"), exist_ok=True)
with open(os.path.join(HERE, "data", "aws", "logs.jsonl"), "w") as f:
    for e in logs:
        f.write(json.dumps(e) + "\n")


def rel(o):
    """Segment times become offset tokens resolved by the loader: {"start_time": 12.345} -> "{{s:12.345}}"."""
    if isinstance(o, dict):
        return {k: ("{{s:%.6f}}" % v if k in ("start_time", "end_time") else rel(v)) for k, v in o.items()}
    if isinstance(o, list):
        return [rel(v) for v in o]
    return o


with open(os.path.join(HERE, "data", "aws", "segments.jsonl"), "w") as f:
    for s in sorted(segs, key=lambda s: s["start_time"]):
        f.write(json.dumps(rel(s)) + "\n")
with open(os.path.join(HERE, "data", "aws", "metrics.jsonl"), "w") as f:
    for fn in sorted(metrics):
        for minute in sorted(metrics[fn]):
            m = metrics[fn][minute]
            d = m["dur"]
            f.write(json.dumps({"function": fn, "minute": minute, "Invocations": m["Invocations"], "Errors": m["Errors"],
                                "ThrottledRequests": m["ThrottledRequests"],
                                "Duration": {"SampleCount": len(d), "Sum": round(sum(d), 2), "Minimum": round(min(d), 2),
                                             "Maximum": round(max(d), 2)}}) + "\n")
n_inv = sum(m["Invocations"] for fn in metrics for m in metrics[fn].values())
print(f"aws: {n_inv:,} invocations, {len(logs):,} log events, {len(segs):,} segments; "
      + ", ".join(f"{fn.split('-', 1)[1]} {k} {v}" for (fn, k), v in sorted(stats.items())))

# ----------------------------------------------------------------------------------------------- alert history
H0 = datetime(2026, 11, 10, tzinfo=UTC)
DAYS = 14
alerts = []                        # episodes: (start, end, alertname, severity, team, service, instance, action, labels)


def episode(start, minutes, name, sev, team, service, instance, action="none", **labels):
    alerts.append((start, start + timedelta(minutes=minutes), name, sev, team, service, instance, action, labels))


RUNBOOK = {"BackendLatencyHigh": "https://runbooks.example.com/easytravel/backend-latency",
           "HealthCheckFailed": "https://runbooks.example.com/easytravel/health-check"}
for day in range(DAYS):
    d0 = H0 + timedelta(days=day)
    # nightly batch: CPU crosses 70 % again and again on both backends (flapping, never actioned)
    for inst in ["app-01", "app-02"]:
        s = d0 + timedelta(hours=1, minutes=55 + R.randint(0, 6))
        for k in range(R.randint(6, 10)):
            dur = R.uniform(1, 4)
            episode(s, dur, "HighCPU", "warning", "platform", "easytravel-backend", inst)
            s += timedelta(minutes=dur + R.uniform(1.5, 6))
        for _ in range(R.randint(0, 2)):
            episode(d0 + timedelta(hours=R.uniform(8, 20)), R.uniform(1, 3), "HighCPU", "warning", "platform",
                    "easytravel-backend", inst)
    # any 5xx in one minute: self-resolving single errors
    for _ in range(R.randint(6, 11)):
        episode(d0 + timedelta(hours=R.uniform(0, 24)), R.uniform(1, 3), "HTTP5xxDetected", "critical", "web",
                "easytravel-frontend", R.choice(["web-01", "web-02"]))
    # one probe location is flaky: health check fails from ap-south only
    for _ in range(R.randint(2, 4)):
        episode(d0 + timedelta(hours=R.uniform(0, 24)), R.uniform(2, 6), "HealthCheckFailed", "critical", "web",
                "easytravel-frontend", R.choice(["web-01", "web-02"]), probe="ap-south")
    # certificate reminder every morning
    episode(d0 + timedelta(hours=9), 60 * 24 - 1, "CertificateExpiringSoon", "info", "web", "easytravel-frontend",
            "www.easytravel.example.com", days_left=str(30 - day))
    # log-based Lambda alarm on ERROR lines (the SES sandbox rejections): never actioned
    for _ in range(R.randint(3, 6)):
        episode(d0 + timedelta(hours=R.uniform(0, 24)), 5, "LambdaLogErrors", "warning", "integrations",
                "easytravel-booking-notify", "booking-notify")
# a disk that slowly filled up: one long alert, re-notified every 4 hours until someone cleaned it up
episode(H0 + timedelta(days=2, hours=8, minutes=12), (8 * 24 + 3) * 60, "DiskSpaceLow", "warning", "platform",
        "easytravel-frontend", "web-02", action="ticket")
# real incidents
episode(datetime(2026, 11, 12, 9, 47, tzinfo=UTC), 48, "BackendLatencyHigh", "warning", "app", "easytravel-backend",
        "app-01", action="incident")
episode(datetime(2026, 11, 12, 9, 48, tzinfo=UTC), 46, "BackendLatencyHigh", "warning", "app", "easytravel-backend",
        "app-02", action="incident")
episode(datetime(2026, 11, 16, 14, 3, tzinfo=UTC), 12, "BackendLatencyHigh", "warning", "app", "easytravel-backend",
        "app-02", action="investigated")
storm = datetime(2026, 11, 19, 10, 5, tzinfo=UTC)
episode(storm, 21, "DatabaseConnectionsFailing", "critical", "app", "easytravel-backend", "et-sql", action="incident")
for inst in ["app-01", "app-02"]:
    episode(storm + timedelta(minutes=1), 20, "BackendErrorRate", "critical", "app", "easytravel-backend", inst, action="ack")
    episode(storm + timedelta(minutes=3), 19, "BackendLatencyHigh", "warning", "app", "easytravel-backend", inst, action="ack")
for inst in ["web-01", "web-02"]:
    episode(storm + timedelta(minutes=1, seconds=20), 20, "HTTP5xxDetected", "critical", "web", "easytravel-frontend", inst, action="ack")
    for probe in ["eu-west", "us-east", "ap-south"]:
        episode(storm + timedelta(minutes=2, seconds=R.randint(0, 50)), 19, "HealthCheckFailed", "critical", "web",
                "easytravel-frontend", inst, action="ack", probe=probe)
episode(storm + timedelta(minutes=4), 25, "QueueBacklogGrowing", "warning", "integrations", "easytravel-booking-notify",
        "booking-events", action="ack")
episode(storm + timedelta(minutes=2), 20, "SyntheticBookingFailed", "critical", "web", "easytravel-frontend",
        "synthetic-eu", action="ack")

REPEAT = {"critical": 1, "warning": 4, "info": 24}    # hours between repeat notifications of a firing alert
rows = []
for start, end, name, sev, team, service, inst, action, labels in alerts:
    if start >= H0 + timedelta(days=DAYS):
        continue
    end = min(end, H0 + timedelta(days=DAYS))
    fp = hashlib.sha1("|".join([name, service, inst, labels.get("probe", "")]).encode()).hexdigest()[:12]
    send = [(start, "firing")]
    k = 1
    while start + timedelta(hours=REPEAT[sev] * k) < end:
        send.append((start + timedelta(hours=REPEAT[sev] * k), "repeat"))
        k += 1
    if name != "CertificateExpiringSoon":
        send.append((end, "resolved"))
    for when, kind in send:
        rows.append({"sent_at": when.strftime("%Y-%m-%dT%H:%M:%SZ"), "alertname": name, "severity": sev, "team": team,
                     "service": service, "instance": inst, "probe": labels.get("probe", ""), "fingerprint": fp,
                     "episode_start": start.strftime("%Y-%m-%dT%H:%M:%SZ"), "notification": kind,
                     "action": action if kind == "firing" else "",
                     "runbook_url": RUNBOOK.get(name, "")})
rows.sort(key=lambda r: (r["sent_at"], r["alertname"], r["instance"]))
os.makedirs(os.path.join(HERE, "alerts"), exist_ok=True)
with open(os.path.join(HERE, "alerts", "alert_history.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
print(f"alerts: {len(alerts):,} alert episodes, {len(rows):,} notifications over {DAYS} days")
