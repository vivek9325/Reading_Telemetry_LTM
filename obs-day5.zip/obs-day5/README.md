# obs-day5: Azure, AWS, dashboards and alerting (lab pack)

Lab files for Day 5 of the observability course. All data is invented: example.com names, documentation IP ranges and
made-up partner names.

| Lab | Where it runs | What you need from this pack |
| --- | --- | --- |
| 5.1 KQL | Azure Data Explorer free cluster (a Microsoft account, no subscription) | `setup/create-tables.kql`, `data/azure/*.csv`, `kql/lab51.kql` |
| 5.2 AWS | Your AWS account, in AWS CloudShell | `bin/load_aws.py`, `data/aws/`, `aws/lab52.txt` |
| 5.3 Dashboards | Grafana on the Day 4 lab stack | `grafana/ops-easytravel-v1.json`, `grafana/solutions/` |
| 5.4 Alerts | The Day 4 lab stack (Prometheus with the Day 4 data) and Docker | `alerts/`, `runbooks/`, `bin/alert_review.py`, `bin/alert_sim.py` |

## The data

- **Azure** (`data/azure/`): Application Insights tables of easyTravel, 24 November 2026, 09:00 to 11:00 UTC:
  14,464 requests, 15,606 dependencies, 439 exceptions, 1,571 traces.
- **AWS** (`data/aws/`): two Lambda functions over two hours: 33,464 log events, 6,676 X-Ray segment documents, per-minute
  custom metrics. The times are offsets from T0; `bin/load_aws.py` sets T0 to about two hours before you load.
- **Alerts** (`alerts/alert_history.csv`): 1,074 alert notifications from 10 to 23 November 2026.
- `make_data.py` rebuilds all of it (fixed seed, same output every time).

## Load and check

```bash
# Lab 5.1: in the free cluster, run the four commands of setup/create-tables.kql, then Get data > Local file for each CSV

# Lab 5.2: in AWS CloudShell, after uploading and unzipping this pack
python3 bin/load_aws.py            # prints your T0
python3 bin/check.py aws

# Labs 5.3 and 5.4: on the Day 4 lab stack
python3 bin/check.py stack
```

## Expected results and the offline variant

`bin/expected.py azure`, `bin/expected.py aws [--t0 <your T0>]` and `bin/expected.py xray` print the expected result of
every Lab 5.1 and 5.2 query, computed from the data files. Without cloud accounts, they are the offline variant of the labs.

## Contents

| Path | What it is |
| --- | --- |
| `setup/create-tables.kql` | Creates the four Application Insights tables in Azure Data Explorer |
| `kql/lab51.kql` | The Lab 5.1 queries |
| `aws/lab52.txt` | The Lab 5.2 Logs Insights queries |
| `bin/load_aws.py`, `bin/awsdata.py` | Loads logs, traces and metrics into AWS; `--delete` removes the log groups |
| `bin/expected.py` | Expected results of the KQL, Logs Insights and X-Ray exercises |
| `grafana/ops-easytravel-v1.json` | The operations dashboard to improve in Lab 5.3 |
| `grafana/solutions/` | Possible answers: a golden signals dashboard and the improved operations dashboard |
| `grafana/build_dashboards.py` | Writes the three dashboard files |
| `alerts/alert_history.csv` | 14 days of alert notifications |
| `alerts/rules-current.yml`, `alerts/rules-proposed.yml`, `alerts/rules-tests.yml` | Prometheus alert rules before and after, and their unit tests |
| `alerts/alertmanager.yml` | Alertmanager routing with grouping and inhibition |
| `bin/alert_review.py` | Noise report on the alert history; `storm` and `probes` views |
| `bin/alert_sim.py` | Replays alert rules over the Day 4 data and counts firings |
| `runbooks/` | A runbook template and six easyTravel runbooks |
| `bin/check.py` | Checks the lab stack or the AWS load |

## Secrets

Lab-only secrets, never committed. CloudShell signs your requests with your console session: no access keys are needed or
stored. If you run `load_aws.py` elsewhere, enter keys in the shell only (`read -rs AWS_SECRET_ACCESS_KEY`), never in a
file in this folder, a chat or a screenshot. `.gitignore` excludes `*.env` and `.t0`.

## Clean up

- AWS: `python3 bin/load_aws.py --delete` removes the two log groups. X-Ray traces expire after 30 days; the custom
  metrics stop costing anything once no new data arrives.
- Azure: drop the four tables (`.drop table requests` and so on) or delete the database in the free cluster.
- Grafana: delete the dashboards you imported.
