# obs-day4: New Relic, Grafana, Loki and Prometheus (lab pack)

Lab files for Day 4 of the observability course.

- **Lab 4.1 (NRQL)** runs live on a New Relic VM: easyTravel with the New Relic Java agent and timed problem patterns.
- **Labs 4.2 to 4.4 (Grafana, LogQL, PromQL)** run on a small Docker stack. Prometheus and Loki are preloaded with two hours of easyTravel
  metrics and logs, and Grafana has both data sources and a starting dashboard. Everyone sees the same incident, so the Lab Guide can
  give exact expected results.

All data is invented: example.com addresses and documentation IP ranges only.

## The incident in the lab data

12 November 2026, 09:00 to 11:00 UTC. Two frontend hosts (web-01, web-02) call two backend hosts (app-01, app-02) at about 3.8
requests per second. A deployment at 09:40 slows the journey search, the backend's worker threads fill up, and from about 09:50
requests are rejected. A rollback at 10:35 ends it. (Trainers: the timeline is in the Lab Guide, Appendix.)

| Data | Where | What it holds |
| --- | --- | --- |
| Metrics | Prometheus, from `data/metrics.om` | `http_server_requests_seconds` histogram (by service, instance, uri, method, status), `tomcat_threads_busy_threads`, `tomcat_threads_config_max_threads`, `process_cpu_usage`, `system_load_average_1m`, `system_cpu_count` |
| Logs | Loki, from `data/logs.jsonl` | 37,511 lines in four streams `{job="easytravel", env="lab", service, host, source}`: frontend access logs and backend JSON logs |

## Start the lab stack

Needs Docker with Compose v2, 2 vCPU, 4 GB of memory and free ports 3000, 9090 and 3100.

```bash
docker compose up -d
docker compose logs loki-loader     # ends with: pushed 37,511 log lines to http://loki:3100
python3 bin/check.py stack          # all checks passed
```

Open Grafana at `http://localhost:3000` (admin / admin, then choose a new password). The dashboard is under Dashboards, obs-day4.

Without Docker: load the metrics with `promtool tsdb create-blocks-from openmetrics data/metrics.om <dir>`, start Prometheus 3.5
with `prometheus/prometheus.yml`, `--storage.tsdb.path=<dir>` and `--storage.tsdb.retention.time=3650d`, start Loki 3.5 with
`loki/loki-config.yaml` (change `/loki` to a folder of your own), then run `python3 bin/load_loki.py`.

## Contents

| Path | What it is |
| --- | --- |
| `docker-compose.yml` | The lab stack: Prometheus 3.5.0, Loki 3.5.3, Grafana 12.1.1, and two one-off loaders |
| `data/` | `metrics.om` (OpenMetrics) and `logs.jsonl` |
| `make_data.py` | Rebuilds `data/` (fixed seed, same output every time) |
| `prometheus/`, `loki/` | Their configurations (Prometheus scrapes nothing; Loki accepts the old timestamps of the lab logs) |
| `grafana/provisioning/` | The Prometheus and Loki data sources, and the dashboard provider |
| `grafana/dashboards/`, `grafana/build_dashboard.py` | The starting dashboard of Lab 4.2, and the script that writes it |
| `bin/promq.py`, `bin/logq.py` | Run a PromQL or LogQL query at an exact time and print a table |
| `bin/load_loki.py` | Pushes `data/logs.jsonl` into Loki |
| `bin/check.py` | `vm` checks the New Relic VM, `stack` checks the lab stack |
| `bin/nr_javaopts.py` | Adds the New Relic Java agent to easyTravel's frontend and backend options |
| `bin/scenario.py` | Timed easyTravel problem patterns: `lab41` |
| `bin/pattern.py`, `bin/etlib.py` | easyTravel helpers, as on Days 2 and 3 |

## Secrets

Lab-only secrets, never committed. The New Relic license key goes in your shell only
(`read -rs NEW_RELIC_LICENSE_KEY && export NEW_RELIC_LICENSE_KEY`), never in `newrelic.yml`, a file in this folder, a chat or a
screenshot. `.gitignore` excludes `*.env`.

## Clean up

- Lab stack: `docker compose down -v` (removes the loaded data and your Grafana changes; export your dashboard first).
- New Relic VM: remove the New Relic lines from easyTravel's `easyTravelLocal.properties` and delete `~/newrelic`.
- New Relic account: delete the lab dashboard and the license key you created for the lab.
