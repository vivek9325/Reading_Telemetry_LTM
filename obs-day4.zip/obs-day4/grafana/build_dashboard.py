#!/usr/bin/env python3
"""Write grafana/dashboards/easytravel-day4.json, the starting dashboard of Lab 4.2 (provisioned by the stack).

It is deliberately incomplete: in the lab you add series, a variable, thresholds and a transformation.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
PROM = {"type": "prometheus", "uid": "prometheus"}
LOKI = {"type": "loki", "uid": "loki"}


def ts(pid, title, grid, targets, unit, desc="", ds=PROM, **opts):
    return {"id": pid, "type": "timeseries", "title": title, "description": desc, "datasource": ds, "gridPos": grid,
            "targets": [dict(t, datasource=ds) for t in targets],
            "fieldConfig": {"defaults": {"unit": unit, "custom": {"lineWidth": 2, "fillOpacity": 8}}, "overrides": []},
            "options": {"legend": {"displayMode": "list", "placement": "bottom"}, "tooltip": {"mode": "multi", "sort": "desc"}}, **opts}


panels = [
    ts(1, "Requests per second by service", {"x": 0, "y": 0, "w": 12, "h": 8},
       [{"refId": "A", "expr": 'sum by (service) (rate(http_server_requests_seconds_count{job="easytravel"}[$__rate_interval]))', "legendFormat": "{{service}}"}],
       "reqps", "PromQL rate() of the request counter"),
    ts(2, "Error rate (%)", {"x": 12, "y": 0, "w": 12, "h": 8},
       [{"refId": "A", "expr": '100 * sum(rate(http_server_requests_seconds_count{job="easytravel", status=~"5.."}[$__rate_interval])) / sum(rate(http_server_requests_seconds_count{job="easytravel"}[$__rate_interval]))',
         "legendFormat": "all services"}],
       "percent", "Share of requests with a 5xx status"),
    ts(3, "Frontend latency p95 (s)", {"x": 0, "y": 8, "w": 12, "h": 8},
       [{"refId": "A", "expr": 'histogram_quantile(0.95, sum by (le) (rate(http_server_requests_seconds_bucket{job="easytravel", service="easytravel-frontend"}[$__rate_interval])))',
         "legendFormat": "p95"}],
       "s", "From the request duration histogram"),
    ts(4, "Backend worker threads busy (share of max)", {"x": 12, "y": 8, "w": 12, "h": 8},
       [{"refId": "A", "expr": 'max_over_time(tomcat_threads_busy_threads{service="easytravel-backend"}[$__rate_interval]) / tomcat_threads_config_max_threads{service="easytravel-backend"}',
         "legendFormat": "{{instance}}"}],
       "percentunit", "Saturation: 1 means every worker thread was busy"),
    ts(5, "Backend log lines by level", {"x": 0, "y": 16, "w": 12, "h": 8},
       [{"refId": "A", "expr": 'sum by (level) (count_over_time({service="backend"} | json [$__auto]))', "legendFormat": "{{level}}", "queryType": "range"}],
       "short", "LogQL count_over_time() on the backend's JSON logs", ds=LOKI,
       ),
    {"id": 6, "type": "logs", "title": "Backend warnings and errors", "datasource": LOKI, "gridPos": {"x": 12, "y": 16, "w": 12, "h": 8},
     "targets": [{"refId": "A", "datasource": LOKI, "expr": '{service="backend"} | json | level=~"WARN|ERROR"', "queryType": "range"}],
     "options": {"showTime": True, "wrapLogMessage": True, "sortOrder": "Descending", "enableLogDetails": True}},
]
panels[4]["fieldConfig"]["defaults"]["custom"].update({"drawStyle": "bars", "stacking": {"mode": "normal", "group": "A"}, "fillOpacity": 80})

dash = {
    "title": "easyTravel Day 4 (lab)", "uid": "easytravel-day4", "tags": ["obs-day4", "easytravel"], "timezone": "utc",
    "schemaVersion": 39, "version": 1, "editable": True, "graphTooltip": 1, "refresh": "",
    "time": {"from": "2026-11-12T09:00:00.000Z", "to": "2026-11-12T11:00:00.000Z"},
    "templating": {"list": []}, "annotations": {"list": []}, "panels": panels,
}
out = os.path.join(HERE, "dashboards", "easytravel-day4.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
json.dump(dash, open(out, "w"), indent=2)
print(f"wrote grafana/dashboards/easytravel-day4.json with {len(panels)} panels")
