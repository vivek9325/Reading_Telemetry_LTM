#!/usr/bin/env python3
"""Build the Day 4 data for Prometheus and Loki (fixed seed, same output every run).

    python3 make_data.py      # writes data/metrics.om and data/logs.jsonl

Two hours of easyTravel telemetry, 12 November 2026, 09:00 to 11:00 UTC; all data invented (example.com and
documentation IP ranges only). Four hosts: web-01 and web-02 run the frontend, app-01 and app-02 the Business
Backend (a Tomcat with 8 worker threads). The story is in the Lab Guide, Appendix A: investigate first.

data/metrics.om   OpenMetrics text, one sample every 15 s, loaded into Prometheus with
                  promtool tsdb create-blocks-from openmetrics (the stack does this for you)
data/logs.jsonl   one JSON object per log line: {"stream": {labels}, "ts": "<unix ns>", "line": "<log line>"}
"""
import bisect, json, math, os, random
from collections import defaultdict
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "data")
R = random.Random(20261112)
T0 = datetime(2026, 11, 12, 9, 0, tzinfo=timezone.utc)
E0 = int(T0.timestamp())
DUR = 7200
STEP = 15
DEPLOY, ROLLBACK = 40 * 60, 95 * 60                 # 09:40 JourneyService 3.5.0, 10:35 back to 3.4.2
WEB, APP = ["web-01", "web-02"], ["app-01", "app-02"]
MAX_THREADS = 8
BUCKETS = [0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10]
PAGES = {"search": ("GET", "/orange.jsf", "/services/JourneyService/findJourneys", 150),
         "details": ("GET", "/orange-trip-details.jsf", "/services/JourneyService/getJourneyById", 65),
         "booking": ("POST", "/orange-booking-payment.jsf", "/services/BookingService/storeBooking", 25)}
BASE = {"search": 0.045, "details": 0.012, "booking": 0.11}
DESTS = ["Paris", "Tokyo", "Rome", "Sydney", "Lisbon", "Vienna", "Toronto", "Singapore"]
hexid = lambda n: "".join(R.choice("0123456789abcdef") for _ in range(n))
load = lambda t: 0.9 + 0.2 * t / DUR


def slow(t):
    """How much slower the backend is: 1 when healthy; the 3.5.0 search without cache is much heavier."""
    if not DEPLOY <= t < ROLLBACK:
        return 1.0
    warm = min(1.0, (t - DEPLOY) / 600)               # gets worse over 10 minutes as the old cache entries expire
    return 1 + warm * (4 + math.sin((t - DEPLOY) / 700))


def search_cost(t):
    """Extra work of one search without the cache."""
    if not DEPLOY <= t < ROLLBACK:
        return 1.0
    warm = min(1.0, (t - DEPLOY) / 600)
    return 1 + warm * (55 + 15 * math.sin((t - DEPLOY) / 700))


# ------------------------------------------------------------------ requests
reqs = []                                             # (start, web, app, kind, backend_latency, backend_status, front_latency, front_status)
for kind, (method, page, op, rpm) in PAGES.items():
    t = 0.0
    while True:
        t += R.expovariate(rpm / 60 * load(t))
        if t >= DUR:
            break
        f = slow(t)
        lat = R.lognormvariate(math.log(BASE[kind]), 0.4)
        if kind == "search":
            lat *= search_cost(t)                     # the search itself is the heavy part
        else:
            lat *= 1 + (f - 1) * 0.6                  # everything else shares the busy CPU
        reqs.append([t, R.choice(WEB), R.choice(APP), kind, lat])
reqs.sort()

# Tomcat on each backend host has MAX_THREADS workers: a request that arrives when all are busy is rejected (503)
busy_ends = {h: [] for h in APP}
for r in reqs:
    t, web, app, kind, lat = r
    ends = busy_ends[app]
    while ends and ends[0] <= t:
        ends.pop(0)
    if len(ends) >= MAX_THREADS:
        r[4:] = [0.002, 503, 0.004 + R.uniform(0.001, 0.004), 500]
    else:
        bisect.insort(ends, t + lat)
        r[4:] = [lat, 200, lat + R.lognormvariate(math.log(0.012), 0.3), 200]

# ------------------------------------------------------------------ metrics, sampled every 15 s
hist = {}                                             # (labels) -> [per-step cumulative bucket counts..., count, sum]


def observe(labels, step, value):
    h = hist.setdefault(labels, {"first": step, "b": [0] * len(BUCKETS), "c": 0, "s": 0.0, "pts": {}})
    for i, le in enumerate(BUCKETS):
        if value <= le:
            h["b"][i] += 1
    h["c"] += 1
    h["s"] += value


inflight = defaultdict(list)                          # app -> (start, end) of accepted requests
steps = DUR // STEP + 1
order = sorted(range(len(reqs)), key=lambda i: reqs[i][0])
k = 0
gauges = defaultdict(dict)                            # (name, labels) -> {step: value}
for s in range(steps):
    tnow = s * STEP
    while k < len(reqs) and reqs[order[k]][0] < tnow:
        t, web, app, kind, lat, bstat, flat, fstat = reqs[order[k]]
        method, page, op, _ = PAGES[kind]
        observe((("service", "easytravel-frontend"), ("instance", web + ":8079"), ("method", method), ("uri", page), ("status", str(fstat))), s, flat)
        observe((("service", "easytravel-backend"), ("instance", app + ":8091"), ("method", "GET"), ("uri", op), ("status", str(bstat))), s, lat)
        if bstat == 200:
            inflight[app].append((t, t + lat))
        k += 1
    for h in hist.values():
        h["pts"][s] = (list(h["b"]), h["c"], h["s"])
    for app in APP:
        live = [x for x in inflight[app] if x[1] > tnow]
        inflight[app] = live
        busy = min(MAX_THREADS, len(live))
        f = slow(tnow)
        cpu = min(0.99, (0.22 + 0.12 * (f - 1)) * load(tnow) + R.gauss(0, 0.015))
        lbl = (("service", "easytravel-backend"), ("instance", app + ":8091"))
        gauges[("tomcat_threads_busy_threads", lbl)][s] = busy
        gauges[("tomcat_threads_config_max_threads", lbl)][s] = MAX_THREADS
        gauges[("process_cpu_usage", lbl)][s] = round(max(0.01, cpu), 4)
        gauges[("system_load_average_1m", lbl)][s] = round(max(0.05, cpu * 2 * (1.6 if f > 3 else 1) + R.gauss(0, 0.05)), 3)
        gauges[("system_cpu_count", lbl)][s] = 2
    for web in WEB:
        lbl = (("service", "easytravel-frontend"), ("instance", web + ":8079"))
        cpu = 0.18 * load(tnow) + R.gauss(0, 0.012)
        gauges[("tomcat_threads_busy_threads", lbl)][s] = max(1, int(R.gauss(4, 1.2)))
        gauges[("tomcat_threads_config_max_threads", lbl)][s] = 200
        gauges[("process_cpu_usage", lbl)][s] = round(max(0.01, cpu), 4)
        gauges[("system_load_average_1m", lbl)][s] = round(max(0.05, cpu * 2 + R.gauss(0, 0.04)), 3)
        gauges[("system_cpu_count", lbl)][s] = 2

os.makedirs(OUT, exist_ok=True)
lab = lambda labels: ",".join(f'{k}="{v}"' for k, v in (("job", "easytravel"),) + labels)
HELP = {"tomcat_threads_busy_threads": "Tomcat worker threads busy", "tomcat_threads_config_max_threads": "Tomcat worker threads configured",
        "process_cpu_usage": "CPU used by the JVM process, 0 to 1", "system_load_average_1m": "1-minute load average",
        "system_cpu_count": "Number of CPU cores"}
with open(os.path.join(OUT, "metrics.om"), "w") as f:
    f.write("# HELP http_server_requests_seconds HTTP server request duration\n# TYPE http_server_requests_seconds histogram\n")
    for labels in sorted(hist):
        h = hist[labels]
        for s in range(h["first"], steps):
            b, c, sm = h["pts"][s]
            ts = E0 + s * STEP
            for i, le in enumerate(BUCKETS):
                f.write(f'http_server_requests_seconds_bucket{{{lab(labels)},le="{le}"}} {b[i]} {ts}\n')
            f.write(f'http_server_requests_seconds_bucket{{{lab(labels)},le="+Inf"}} {c} {ts}\n')
            f.write(f'http_server_requests_seconds_count{{{lab(labels)}}} {c} {ts}\n')
            f.write(f'http_server_requests_seconds_sum{{{lab(labels)}}} {sm:.6f} {ts}\n')
    for name in HELP:
        f.write(f"# HELP {name} {HELP[name]}\n# TYPE {name} gauge\n")
        for (n, labels), pts in sorted(gauges.items()):
            if n != name:
                continue
            for s in sorted(pts):
                f.write(f"{name}{{{lab(labels)}}} {pts[s]} {E0 + s * STEP}\n")
    f.write("# EOF\n")

# ------------------------------------------------------------------ logs for Loki
lines = []                                            # (sec, stream labels, line)
ts_clf = lambda s: (T0 + timedelta(seconds=s)).strftime("%d/%b/%Y:%H:%M:%S +0000")
ts_iso = lambda s: (T0 + timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
NETS = ["198.51.100.", "203.0.113.", "192.0.2."]
SVC = {"search": ("JourneyService", "findJourneys"), "details": ("JourneyService", "getJourneyById"), "booking": ("BookingService", "storeBooking")}
for t, web, app, kind, lat, bstat, flat, fstat in reqs:
    method, page, op, _ = PAGES[kind]
    trace = hexid(32)
    path = page + (f"?destination={R.choice(DESTS)}" if kind == "search" else f"?journeyId={R.randint(1000, 9999)}" if kind == "details" else "")
    size = R.randint(4000, 17000) if fstat == 200 else 1532
    lines.append((t, {"job": "easytravel", "env": "lab", "service": "frontend", "host": web, "source": "access"},
                  f'{R.choice(NETS)}{R.randint(2, 254)} - - [{ts_clf(t)}] "{method} {path} HTTP/1.1" {fstat} {size} rt={flat:.3f} upstream={app} trace={trace}'))
    svc, fn = SVC[kind]
    app_lbl = {"job": "easytravel", "env": "lab", "service": "backend", "host": app, "source": "app"}
    base = {"service": svc, "operation": fn, "trace_id": trace}
    if bstat == 503:
        lines.append((t + 0.001, app_lbl, json.dumps({"ts": ts_iso(t + 0.001), "level": "ERROR", **base, "status": 503, "duration_ms": 2,
                                                     "message": f"Request rejected: all {MAX_THREADS} worker threads busy"})))
    elif lat > 2.0:
        lines.append((t + lat, app_lbl, json.dumps({"ts": ts_iso(t + lat), "level": "WARN", **base, "status": 200, "duration_ms": int(lat * 1000),
                                                   "message": f"Slow request: {fn} took {int(lat * 1000)} ms"})))
    elif kind == "booking":
        lines.append((t + lat, app_lbl, json.dumps({"ts": ts_iso(t + lat), "level": "INFO", **base, "status": 200, "duration_ms": int(lat * 1000),
                                                   "message": f"Booking stored bookingId={R.randint(7100000, 7999999)}"})))
for app in APP:
    lbl = {"job": "easytravel", "env": "lab", "service": "backend", "host": app, "source": "app"}
    for m in range(0, 120, 5):
        lines.append((m * 60 + 2.5, lbl, json.dumps({"ts": ts_iso(m * 60 + 2.5), "level": "INFO", "service": "JourneyService", "operation": "cache",
                                                     "status": 200, "duration_ms": 0, "message": "Journey cache " + ("disabled (3.5.0 default)" if DEPLOY <= m * 60 < ROLLBACK else "refreshed")})))
    for t, msg in ((DEPLOY + (5 if app == "app-01" else 47), "JourneyService 3.5.0 started (journey.cache.enabled=false)"),
                   (ROLLBACK + (6 if app == "app-01" else 39), "JourneyService 3.4.2 started (journey.cache.enabled=true)")):
        lines.append((t, lbl, json.dumps({"ts": ts_iso(t), "level": "INFO", "service": "JourneyService", "operation": "startup", "status": 200,
                                          "duration_ms": 0, "message": msg})))
lines.sort(key=lambda x: x[0])
with open(os.path.join(OUT, "logs.jsonl"), "w") as f:
    for t, lbl, line in lines:
        f.write(json.dumps({"stream": lbl, "ts": str((E0 * 10**9) + int(round(t * 10**9))), "line": line}) + "\n")

n503 = sum(1 for r in reqs if r[5] == 503)
print(f"{len(reqs):,} requests ({n503:,} rejected with 503), {len(hist)} histogram series, {len(gauges)} gauge series, {len(lines):,} log lines")
