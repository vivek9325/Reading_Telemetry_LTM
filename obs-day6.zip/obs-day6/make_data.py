#!/usr/bin/env python3
"""Build the Day 6 data: one recorded easyTravel production incident, in the format of every tool of the course
(fixed seed, same output every run).

    python3 make_data.py

17 November 2026, 13:00 to 15:00 UTC. All data is invented: example.com names and documentation IP ranges only. The
story is in the Lab Guide, Appendix: investigate first.

data/prometheus/metrics.om     OpenMetrics: request histograms, connection pools, database and host gauges (15 s), the SLO
                               event counters of 28 days (1 min) and a high-cardinality counter (Lab 6.3)
data/loki/logs.jsonl           log lines for Loki: frontend access logs, backend JSON logs, database logs, change events
data/tempo/spans.jsonl         the sampled traces (all failed or slow requests, 10 % of the rest), one span per line
data/splunk/<index>/<host>/    the same logs as files for the Splunk app
data/azure/*.csv               Application Insights tables for Azure Data Explorer
"""
import csv, hashlib, heapq, json, math, os, random
from collections import defaultdict
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data")
R = random.Random(20261117)
UTC = timezone.utc
T0 = datetime(2026, 11, 17, 13, 0, tzinfo=UTC)
E0 = int(T0.timestamp())
DUR, STEP = 7200, 15
hexid = lambda n: "".join(R.choice("0123456789abcdef") for _ in range(n))
lognorm = lambda med, sp: med * math.exp(R.gauss(0, sp))
iso = lambda s: (T0 + timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
clf = lambda s: (T0 + timedelta(seconds=s)).strftime("%d/%b/%Y:%H:%M:%S +0000")

# ------------------------------------------------------------------------------------------------ the story (seconds from 13:00)
DEPLOY = {"app-01": 42 * 60 + 10, "app-02": 43 * 60 + 5}       # JourneyService 3.6.0, rolling (CHG-4815)
MIGRATION = 42 * 60 + 31                                        # Flyway V36 on app-01: drops the old index, the new one fails
FIX_START, FIX_DONE = 80 * 60 + 5, 83 * 60 + 31                 # 14:20:05 DBA re-creates the index online (CHG-4816)
WEB, APP = ["web-01", "web-02"], ["app-01", "app-02"]
POOL, CONN_TIMEOUT = 10, 3.0                                    # HikariCP maximumPoolSize and connectionTimeout per backend
DESTS = ["Lisbon", "Vienna", "Tokyo", "Paris", "Rome", "Sydney", "Toronto", "Singapore"]
PAGES = {"search": ("GET", "/orange.jsf", "GET /services/JourneyService/findJourneys"),
         "details": ("GET", "/orange-trip-details.jsf", "GET /services/JourneyService/getJourneyById"),
         "booking": ("POST", "/orange-booking-payment.jsf", "POST /services/BookingService/storeBooking")}
SQL = {"search": ("SELECT easytravel.journeys", "SELECT id, destination, departure, price FROM journeys WHERE destination = ? AND departure >= ?"),
       "details": ("SELECT easytravel.journeys", "SELECT * FROM journeys WHERE id = ?"),
       "booking": ("INSERT easytravel.bookings", "INSERT INTO bookings (journey_id, customer_id, amount) VALUES (?, ?, ?)")}
index_ok = lambda t: t < MIGRATION or t >= FIX_DONE


def load(t):
    return 1.0 + 0.12 * math.sin(t / 1900)


# ------------------------------------------------------------------------------------------------ requests
reqs = []
t = 0.0
while True:
    t += R.expovariate(4.0 * load(t))
    if t >= DUR:
        break
    kind = R.choices(["search", "details", "booking"], [0.55, 0.30, 0.15])[0]
    reqs.append({"t": t, "kind": kind, "web": R.choice(WEB), "app": R.choice(APP), "trace": hexid(32)})

# database: concurrent table scans slow every query down (CPU of db-01)
scans = []                                                       # (start, end) of every table scan
active_scans = []                                                # scans that may still be running
pools = {a: [0.0] * POOL for a in APP}                           # connection free-at times
waiting = {a: [] for a in APP}                                   # (start, end) of waits, for the pending gauge
held = {a: [] for a in APP}                                      # (start, end) of connections in use
timeouts = defaultdict(list)


def db_cpu(t, pool=None):
    n = sum(1 for s, e in (scans if pool is None else pool) if s <= t < e)
    return min(0.99, 0.16 + 0.14 * n), n


for q in reqs:
    t, kind, app = q["t"], q["kind"], q["app"]
    q["pre"] = R.uniform(0.002, 0.006)                           # backend work before it needs a connection
    need = t + q["pre"]
    pool = pools[app]
    i = min(range(POOL), key=lambda k: pool[k])
    wait = max(0.0, pool[i] - need)
    active_scans[:] = [x for x in active_scans if x[1] > need - 30]
    if wait > CONN_TIMEOUT:
        q.update(wait=CONN_TIMEOUT, timeout=True, sql=0.0)
        waiting[app].append((need, need + CONN_TIMEOUT))
        timeouts[app].append(need + CONN_TIMEOUT)
    else:
        start = need + wait
        cpu, nscan = db_cpu(start, active_scans)
        slow = 1 + 4 * max(0.0, cpu - 0.6)                      # everything slows down when the database CPU is busy
        if kind == "search":
            sql = lognorm(0.024, 0.3) * slow if index_ok(start) else lognorm(2.0, 0.22) * (1 + 0.2 * nscan)
            if not index_ok(start):
                scans.append((start, start + sql))
                active_scans.append((start, start + sql))
        elif kind == "details":
            sql = lognorm(0.008, 0.35) * slow
        else:
            sql = lognorm(0.012, 0.3) * slow
        if FIX_START <= start < FIX_DONE:
            sql *= 1.3                                           # the online index build adds load
        pool[i] = start + sql + 0.001
        q.update(wait=wait, timeout=False, sql=sql)
        if wait > 0:
            waiting[app].append((need, start))
        held[app].append((start, start + sql + 0.001))
    # the rest of the request
    if q["timeout"]:
        q["be_status"], q["be_dur"] = 503, q["pre"] + CONN_TIMEOUT + R.uniform(0.001, 0.003)
        q["pay"] = None
    else:
        pay = None
        if kind == "booking":
            pay = ("402", lognorm(0.16, 0.25)) if R.random() < 0.03 else ("200", lognorm(0.18, 0.3))
        q["pay"] = pay
        q["be_status"] = 402 if pay and pay[0] == "402" else 200
        q["be_dur"] = q["pre"] + q["wait"] + q["sql"] + (pay[1] if pay else 0) + R.uniform(0.001, 0.004)
    q["fe_status"] = 500 if q["be_status"] == 503 else 200
    q["fe_dur"] = q["be_dur"] + R.uniform(0.004, 0.02)
    q["path"] = PAGES[kind][1] + (f"?destination={R.choice(DESTS)}" if kind == "search" else f"?journeyId={R.randint(1000, 1599)}" if kind == "details" else "")
    q["sids"] = [hexid(16) for _ in range(7)]
    q["ip"] = R.choice(["198.51.100.", "203.0.113.", "192.0.2."]) + str(R.randint(2, 254))
    q["user"] = f"u{R.randint(10000, 11500)}"

n_fail = sum(q["fe_status"] == 500 for q in reqs)
print(f"{len(reqs):,} requests, {n_fail} failed (connection pool timeouts), {len(scans)} table scans")

# ------------------------------------------------------------------------------------------------ Prometheus
BUCKETS = [0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 15, 30]
os.makedirs(os.path.join(D, "prometheus"), exist_ok=True)
out = open(os.path.join(D, "prometheus", "metrics.om"), "w")
lab = lambda labels: ",".join(f'{k}="{v}"' for k, v in labels)
steps = DUR // STEP + 1
hist = {}
for q in sorted(reqs, key=lambda q: q["t"]):
    kind = q["kind"]
    m, page, op = PAGES[kind]
    end_fe, end_be = q["t"] + q["fe_dur"], q["t"] + q["be_dur"]
    for labels, end, val in [((("job", "easytravel"), ("service", "easytravel-frontend"), ("instance", q["web"] + ":8079"), ("method", m), ("uri", page), ("status", str(q["fe_status"]))), end_fe, q["fe_dur"]),
                             ((("job", "easytravel"), ("service", "easytravel-backend"), ("instance", q["app"] + ":8091"), ("method", op.split()[0]), ("uri", op.split()[1]), ("status", str(q["be_status"]))), end_be, q["be_dur"])]:
        hist.setdefault(labels, []).append((end, val))
out.write("# HELP http_server_requests_seconds HTTP server request duration\n# TYPE http_server_requests_seconds histogram\n")
for labels in sorted(hist):
    obs = sorted(hist[labels])
    k, b, c, sm = 0, [0] * len(BUCKETS), 0, 0.0
    first = int(obs[0][0] // STEP) + 1
    for s in range(first, steps):
        while k < len(obs) and obs[k][0] <= s * STEP:
            v = obs[k][1]
            for i, le in enumerate(BUCKETS):
                b[i] += v <= le
            c, sm, k = c + 1, sm + v, k + 1
        ts = E0 + s * STEP
        for i, le in enumerate(BUCKETS):
            out.write(f'http_server_requests_seconds_bucket{{{lab(labels)},le="{le}"}} {b[i]} {ts}\n')
        out.write(f'http_server_requests_seconds_bucket{{{lab(labels)},le="+Inf"}} {c} {ts}\n')
        out.write(f'http_server_requests_seconds_count{{{lab(labels)}}} {c} {ts}\n')
        out.write(f'http_server_requests_seconds_sum{{{lab(labels)}}} {sm:.6f} {ts}\n')

gauges = defaultdict(dict)
counters = defaultdict(dict)
for s in range(steps):
    now = s * STEP
    for app in APP:
        L = (("job", "easytravel"), ("service", "easytravel-backend"), ("instance", app + ":8091"), ("pool", "HikariPool-1"))
        gauges[("hikaricp_connections_active", L)][s] = sum(1 for a, e in held[app] if a <= now < e)
        gauges[("hikaricp_connections_pending", L)][s] = sum(1 for a, e in waiting[app] if a <= now < e)
        gauges[("hikaricp_connections_max", L)][s] = POOL
        counters[("hikaricp_connections_timeout_total", L)][s] = sum(1 for x in timeouts[app] if x <= now)
        Lh = (("job", "easytravel"), ("service", "easytravel-backend"), ("instance", app + ":8091"))
        gauges[("process_cpu_usage", Lh)][s] = round(min(0.95, 0.2 * load(now) + R.gauss(0, 0.015) + 0.05 * (gauges[("hikaricp_connections_pending", L)][s] > 0)), 4)
    for web in WEB:
        Lh = (("job", "easytravel"), ("service", "easytravel-frontend"), ("instance", web + ":8079"))
        gauges[("process_cpu_usage", Lh)][s] = round(max(0.02, 0.17 * load(now) + R.gauss(0, 0.012)), 4)
    cpu, n = db_cpu(now)
    Ld = (("job", "easytravel"), ("service", "et-sql"), ("instance", "db-01:9399"))
    gauges[("db_cpu_utilization", Ld)][s] = round(min(0.99, cpu + R.gauss(0, 0.01)), 4)
    gauges[("db_active_sessions", Ld)][s] = sum(1 for app in APP for a, e in held[app] if a <= now < e)
HELP = {"hikaricp_connections_active": ("gauge", "Connections in use"), "hikaricp_connections_pending": ("gauge", "Threads waiting for a connection"),
        "hikaricp_connections_max": ("gauge", "Maximum pool size"), "process_cpu_usage": ("gauge", "CPU of the JVM, 0 to 1"),
        "db_cpu_utilization": ("gauge", "CPU of the database server, 0 to 1"), "db_active_sessions": ("gauge", "Sessions running a query")}
for name, (typ, help_) in HELP.items():
    out.write(f"# HELP {name} {help_}\n# TYPE {name} {typ}\n")
    for (n, labels), pts in sorted(gauges.items()):
        if n == name:
            for s in sorted(pts):
                out.write(f"{name}{{{lab(labels)}}} {pts[s]} {E0 + s * STEP}\n")
out.write("# HELP hikaricp_connections_timeout Connection requests that timed out\n# TYPE hikaricp_connections_timeout counter\n")
for (n, labels), pts in sorted(counters.items()):
    for s in sorted(pts):
        out.write(f"hikaricp_connections_timeout_total{{{lab(labels)}}} {pts[s]} {E0 + s * STEP}\n")

# high cardinality (Lab 6.3): page views per journey ID, scraped every 60 s
views = defaultdict(lambda: defaultdict(int))
for q in reqs:
    if q["kind"] == "details":
        views[(q["web"], q["path"].split("=")[1])][int(q["t"] // 60) + 1] += 1
out.write("# HELP easytravel_journey_views Journey detail page views\n# TYPE easytravel_journey_views counter\n")
for (web, jid), per in sorted(views.items()):
    c = 0
    first = min(per)
    for mi in range(first, DUR // 60 + 1):
        c += per.get(mi, 0)
        out.write(f'easytravel_journey_views_total{{job="easytravel",service="easytravel-frontend",instance="{web}:8079",journey_id="{jid}"}} {c} {E0 + mi * 60}\n')

# SLO events of 28 days, one sample a minute: good and bad requests of two SLIs
W0 = datetime(2026, 10, 21, tzinfo=UTC)
WMIN = 28 * 24 * 60
slo_req = defaultdict(lambda: [0, 0])                            # minute -> [good, bad] in the incident window, from the requests
for q in reqs:
    mi = int((E0 - W0.timestamp() + q["t"]) // 60)
    slo_req[("availability", mi)][q["fe_status"] >= 500] += 1
    slo_req[("latency", mi)][q["fe_dur"] > 1.0] += 1
INC = [(datetime(2026, 11, 12, 9, 45, tzinfo=UTC), 50, 0.045, 0.55), (datetime(2026, 10, 29, 21, 10, tzinfo=UTC), 18, 0.02, 0.05)]
out.write("# HELP easytravel_slo_events SLI events of the easyTravel frontend by outcome\n# TYPE easytravel_slo_events counter\n")
series = {}
for sli in ("availability", "latency"):
    good = bad = 0
    pts_g, pts_b = [], []
    incident_start = int((E0 - W0.timestamp()) // 60)
    for mi in range(WMIN + 1):
        if incident_start <= mi < incident_start + DUR // 60:
            g, b = slo_req[(sli, mi)]
            g -= 0                                                # counts already split above
            good += g
            bad += b
        else:
            when = W0 + timedelta(minutes=mi)
            hour = when.hour + when.minute / 60
            rate = 240 * (0.55 + 0.45 * math.sin(math.pi * (hour - 6) / 16) if 6 <= hour <= 22 else 0.55) * (0.8 if when.weekday() >= 5 else 1)
            n = max(0, int(R.gauss(rate, math.sqrt(rate))))
            p_bad = 0.0003 if sli == "availability" else 0.003
            for start, length, err, slow in INC:
                if start <= when < start + timedelta(minutes=length):
                    p_bad = err if sli == "availability" else slow
            b = sum(1 for _ in range(n) if R.random() < p_bad) if n < 2000 else int(n * p_bad)
            good += n - b
            bad += b
        ts = int(W0.timestamp()) + mi * 60
        pts_g.append(f'easytravel_slo_events_total{{job="easytravel",service="easytravel-frontend",sli="{sli}",outcome="good"}} {good} {ts}\n')
        pts_b.append(f'easytravel_slo_events_total{{job="easytravel",service="easytravel-frontend",sli="{sli}",outcome="bad"}} {bad} {ts}\n')
    out.writelines(pts_b)
    out.writelines(pts_g)
out.write("# EOF\n")
out.close()

# ------------------------------------------------------------------------------------------------ logs (one list, written per tool)
logs = []                                                        # (sec, service, host, source, line)
UAS = ["Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0",
       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36",
       "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
       "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1"]
SVC = {"search": ("JourneyService", "findJourneys"), "details": ("JourneyService", "getJourneyById"), "booking": ("BookingService", "storeBooking")}
for q in reqs:
    m, page, op = PAGES[q["kind"]]
    size = R.randint(4000, 17000) if q["fe_status"] == 200 else 1532
    uh = hashlib.sha1(q["user"].encode()).hexdigest()
    ua = UAS[int(uh[:2], 16) % len(UAS)]
    logs.append((q["t"] + q["fe_dur"], "frontend", q["web"], "access",
                 f'{q["ip"]} - - [{clf(q["t"])}] "{m} {q["path"]} HTTP/1.1" {q["fe_status"]} {size} "https://www.easytravel.example.com/" "{ua}" '
                 f'rt={q["fe_dur"]:.3f} upstream={q["app"]} session={uh[:8]} trace={q["trace"]}'))
    svc, fn = SVC[q["kind"]]
    base = {"logger": f"com.example.easytravel.{svc}", "operation": fn, "trace_id": q["trace"], "span_id": q["sids"][2]}
    if q["timeout"]:
        t1 = q["t"] + q["pre"] + CONN_TIMEOUT
        logs.append((t1, "backend", q["app"], "app", json.dumps({"time": iso(t1), "level": "ERROR", **base, "status": 503,
                     "duration_ms": int(q["be_dur"] * 1000), "message": "HikariPool-1 - Connection is not available, request timed out after 3000ms.",
                     "exception": "java.sql.SQLTransientConnectionException"})))
    elif q["sql"] > 1.0:
        t1 = q["t"] + q["be_dur"]
        logs.append((t1, "backend", q["app"], "app", json.dumps({"time": iso(t1), "level": "WARN", **base, "status": q["be_status"],
                     "duration_ms": int(q["be_dur"] * 1000), "message": f"Slow request: {fn} took {int(q['be_dur'] * 1000)} ms (database {int(q['sql'] * 1000)} ms)"})))
    elif q["kind"] == "booking" and q["be_status"] == 200:
        t1 = q["t"] + q["be_dur"]
        logs.append((t1, "backend", q["app"], "app", json.dumps({"time": iso(t1), "level": "INFO", **base, "status": 200,
                     "duration_ms": int(q["be_dur"] * 1000), "message": f"Booking stored bookingId={R.randint(7100000, 7999999)}"})))
    if q["kind"] == "search" and not index_ok(q["t"]) and not q["timeout"] and q["sql"] > 1.0:
        t1 = q["t"] + q["pre"] + q["wait"] + q["sql"]
        logs.append((t1, "db", "db-01", "db", f'{iso(t1)} slow_query duration_ms={int(q["sql"] * 1000)} rows_examined={R.randint(410000, 418000)} '
                     f'rows_returned={R.randint(3, 40)} query_hash=0x8F3A2C1D plan=TableScan(journeys) '
                     f'statement="SELECT id, destination, departure, price FROM journeys WHERE destination = @P0 AND departure >= @P1"'))
# background and change events
for app in APP:
    for s in range(30, DUR, 300):
        logs.append((s + (7 if app == "app-02" else 0), "backend", app, "app", json.dumps({"time": iso(s + (7 if app == "app-02" else 0)), "level": "WARN",
                     "logger": "com.example.easytravel.LoginService", "operation": "login", "status": 200, "duration_ms": 0,
                     "message": "Legacy password hash detected for 3 users; rehash on next login"})))
    d = DEPLOY[app]
    for dt, lvl, msg in [(0, "INFO", "Stopping JourneyService 3.5.2 for deployment CHG-4815"), (14, "INFO", "JourneyService 3.6.0 started in 13.8 s")]:
        logs.append((d + dt, "backend", app, "app", json.dumps({"time": iso(d + dt), "level": lvl, "logger": "com.example.easytravel.Bootstrap",
                     "operation": "startup", "status": 200, "duration_ms": 0, "message": msg})))
for dt, lvl, msg in [(0, "INFO", "Flyway: migrating schema \"easytravel\" to version 36 - journey search index"),
                     (1, "INFO", "Flyway: V36: DROP INDEX IX_journeys_destination ON journeys"),
                     (31, "WARN", "Flyway: V36: CREATE INDEX IX_journeys_destination_departure ON journeys (destination, departure) failed: Lock request time out period exceeded. Statement skipped (flyway.ignoreMigrationPatterns=*:failed)"),
                     (32, "INFO", "Flyway: successfully applied 1 migration to schema \"easytravel\", now at version v36 (execution time 00:31.412s)")]:
    logs.append((MIGRATION + dt, "backend", "app-01", "app", json.dumps({"time": iso(MIGRATION + dt), "level": lvl, "logger": "org.flywaydb.core.Flyway",
                 "operation": "migration", "status": 200, "duration_ms": 0, "message": msg})))
for t1, msg in [(MIGRATION + 1.2, "DROP INDEX IX_journeys_destination ON dbo.journeys completed (session 61)"),
                (MIGRATION + 31.1, "Error: 1222, Severity: 16, State: 56. Lock request time out period exceeded. CREATE INDEX IX_journeys_destination_departure (session 61)"),
                (FIX_START, "CREATE INDEX IX_journeys_destination_departure ON dbo.journeys (destination, departure) WITH (ONLINE = ON) started (session 88)"),
                (FIX_DONE, "CREATE INDEX IX_journeys_destination_departure completed in 206.3 s (session 88)")]:
    logs.append((t1, "db", "db-01", "db", f"{iso(t1)} event {msg}"))
for s in range(0, DUR, 60):
    cpu = db_cpu(s)[0]
    if cpu > 0.85:
        logs.append((s + 0.5, "db", "db-01", "db", f"{iso(s + 0.5)} warning cpu_utilization={cpu:.2f} runnable_tasks={int(cpu * 14)} wait_type=SOS_SCHEDULER_YIELD"))
EVENTS = [(DEPLOY["app-01"] - 20, {"type": "deployment", "change": "CHG-4815", "service": "JourneyService", "version": "3.6.0", "from_version": "3.5.2",
                                    "status": "started", "user": "pipeline", "message": "Release 3.6.0: faster journey search (schema V36)"}),
          (DEPLOY["app-02"] + 20, {"type": "deployment", "change": "CHG-4815", "service": "JourneyService", "version": "3.6.0", "status": "succeeded",
                                    "user": "pipeline", "message": "Rolling deployment finished on app-01, app-02"}),
          (47 * 60, {"type": "alert", "change": "", "service": "easytravel-frontend", "status": "firing", "user": "alertmanager",
                     "message": "EasyTravelErrorRatioHigh: easytravel-frontend, 16 % of requests fail with 5xx"}),
          (58 * 60 + 12, {"type": "incident", "change": "INC-2291", "service": "easytravel", "status": "opened", "user": "oncall-app",
                          "message": "Searches slow and failing; error budget burning"}),
          (FIX_START - 40, {"type": "change", "change": "CHG-4816", "service": "et-sql", "status": "approved", "user": "dba-oncall",
                            "message": "Emergency: re-create IX_journeys_destination_departure online"}),
          (FIX_DONE + 2, {"type": "change", "change": "CHG-4816", "service": "et-sql", "status": "completed", "user": "dba-oncall",
                          "message": "Index created; query plan back to index seek"}),
          (94 * 60 + 10, {"type": "incident", "change": "INC-2291", "service": "easytravel", "status": "resolved", "user": "oncall-app",
                          "message": "Error rate and latency normal since 14:25"})]
for t1, ev in EVENTS:
    logs.append((t1, "cicd", "change-mgmt", "events", json.dumps({"time": iso(t1), **ev})))
logs.sort(key=lambda x: x[0])

os.makedirs(os.path.join(D, "loki"), exist_ok=True)
with open(os.path.join(D, "loki", "logs.jsonl"), "w") as f:
    for t1, svc, host, src, line in logs:
        f.write(json.dumps({"stream": {"job": "easytravel", "env": "prod", "service": svc, "host": host, "source": src},
                            "ts": str(E0 * 10**9 + int(round(t1 * 1e9))), "line": line}) + "\n")
# Splunk: the same lines as files, one folder per index and host
IDX = {"access": ("et6_web", "access.log"), "app": ("et6_app", "app.log"), "db": ("et6_db", "db.log"), "events": ("et6_change", "changes.log")}
files = defaultdict(list)
for t1, svc, host, src, line in logs:
    files[IDX[src] + (host,)].append(line)
for (idx, fn, host), lines in files.items():
    p = os.path.join(D, "splunk", idx, host)
    os.makedirs(p, exist_ok=True)
    with open(os.path.join(p, fn), "w") as f:
        f.write("\n".join(lines) + "\n")
# host metrics every minute as key=value lines (Splunk et6_os)
for host in WEB + APP + ["db-01"]:
    lines = []
    for s in range(0, DUR, 60):
        st = s // STEP
        if host == "db-01":
            cpu = gauges[("db_cpu_utilization", (("job", "easytravel"), ("service", "et-sql"), ("instance", "db-01:9399")))][st]
            lines.append(f"{(T0 + timedelta(seconds=s)):%Y-%m-%dT%H:%M:%SZ} host=db-01 cpu_pct={cpu * 100:.1f} active_sessions={gauges[('db_active_sessions', (('job', 'easytravel'), ('service', 'et-sql'), ('instance', 'db-01:9399')))][st]}")
        elif host in APP:
            L = (("job", "easytravel"), ("service", "easytravel-backend"), ("instance", host + ":8091"), ("pool", "HikariPool-1"))
            cpu = gauges[("process_cpu_usage", L[:3])][st]
            lines.append(f"{(T0 + timedelta(seconds=s)):%Y-%m-%dT%H:%M:%SZ} host={host} cpu_pct={cpu * 100:.1f} pool_active={gauges[('hikaricp_connections_active', L)][st]} "
                         f"pool_pending={gauges[('hikaricp_connections_pending', L)][st]} pool_max={POOL} pool_timeouts_total={counters[('hikaricp_connections_timeout_total', L)][st]}")
        else:
            cpu = gauges[("process_cpu_usage", (("job", "easytravel"), ("service", "easytravel-frontend"), ("instance", host + ":8079")))][st]
            lines.append(f"{(T0 + timedelta(seconds=s)):%Y-%m-%dT%H:%M:%SZ} host={host} cpu_pct={cpu * 100:.1f}")
    p = os.path.join(D, "splunk", "et6_os", host)
    os.makedirs(p, exist_ok=True)
    with open(os.path.join(p, "os.log"), "w") as f:
        f.write("\n".join(lines) + "\n")

# ------------------------------------------------------------------------------------------------ traces (tail sampling)
def keep(q):
    if q["fe_status"] >= 500 or q["fe_dur"] > 1.0:
        return True
    return int(hashlib.sha1(q["trace"].encode()).hexdigest()[:4], 16) < 0.10 * 65536


spans = []
for q in reqs:
    if not keep(q):
        continue
    kind = q["kind"]
    m, page, op = PAGES[kind]
    s0 = q["sids"]
    t0, fe_end = q["t"], q["t"] + q["fe_dur"]
    c_start = t0 + 0.001
    be_start = c_start + 0.0008
    be_end = q["t"] + q["be_dur"]
    def sp(sid, parent, svc, name, kindn, a, b, attrs, err=False, events=None):
        d = {"trace_id": q["trace"], "span_id": sid, "parent_span_id": parent, "service": svc, "name": name, "kind": kindn,
             "start": round(a, 6), "end": round(b, 6), "attrs": attrs, "error": err}
        if events:
            d["events"] = events
        spans.append(d)
    sp(s0[0], "", "easytravel-frontend", f"{m} {page}", "server", t0, fe_end,
       {"http.request.method": m, "url.path": page, "url.query": q["path"].split("?")[1] if "?" in q["path"] else "",
        "http.response.status_code": q["fe_status"], "host.name": q["web"], "client.address": q["ip"]}, q["fe_status"] >= 500)
    sp(s0[1], s0[0], "easytravel-frontend", op.split()[0], "client", c_start, be_end + 0.0008,
       {"http.request.method": op.split()[0], "server.address": "easytravel-backend", "server.port": 8091, "url.full": f"http://easytravel-backend:8091{op.split()[1]}",
        "http.response.status_code": q["be_status"]}, q["be_status"] >= 500)
    sp(s0[2], s0[1], "easytravel-backend", op, "server", be_start, be_end,
       {"http.request.method": op.split()[0], "http.route": op.split()[1], "http.response.status_code": q["be_status"], "host.name": q["app"],
        "service.version": "3.6.0" if q["t"] >= DEPLOY[q["app"]] else "3.5.2"}, q["be_status"] >= 500)
    w0 = be_start + q["pre"] - 0.0008
    ev = [{"name": "exception", "time": round(w0 + q["wait"], 6), "attrs": {"exception.type": "java.sql.SQLTransientConnectionException",
           "exception.message": "HikariPool-1 - Connection is not available, request timed out after 3000ms."}}] if q["timeout"] else None
    sp(s0[3], s0[2], "easytravel-backend", "HikariPool-1 getConnection", "internal", w0, w0 + q["wait"] + 0.0002,
       {"db.client.connection.pool.name": "HikariPool-1"}, q["timeout"], ev)
    if not q["timeout"]:
        name, stmt = SQL[kind]
        a = w0 + q["wait"] + 0.0003
        sp(s0[4], s0[2], "easytravel-backend", name, "client", a, a + q["sql"],
           {"db.system": "mssql", "db.namespace": "easytravel", "db.operation.name": name.split()[0], "db.collection.name": name.split(".")[1],
            "db.query.text": stmt, "server.address": "et-sql.example.com"})
        if q["pay"]:
            b0 = a + q["sql"] + 0.0005
            sp(s0[5], s0[2], "easytravel-backend", "POST", "client", b0, b0 + q["pay"][1],
               {"http.request.method": "POST", "server.address": "payments.example.com", "url.full": "https://payments.example.com/v2/authorize",
                "http.response.status_code": int(q["pay"][0])})
os.makedirs(os.path.join(D, "tempo"), exist_ok=True)
with open(os.path.join(D, "tempo", "spans.jsonl"), "w") as f:
    for sp_ in spans:
        f.write(json.dumps(sp_) + "\n")
print(f"traces: {sum(keep(q) for q in reqs):,} of {len(reqs):,} kept (tail sampling), {len(spans):,} spans")

# ------------------------------------------------------------------------------------------------ Azure (Application Insights tables)
BKT = [(250, "<250ms"), (500, "250ms-500ms"), (1000, "500ms-1sec"), (3000, "1sec-3sec"), (7000, "3sec-7sec"), (15000, "7sec-15sec")]
bucket = lambda ms: next((b for lim, b in BKT if ms < lim), "15sec-30sec")
A = {"requests": [], "dependencies": [], "exceptions": [], "traces": []}
for q in reqs:
    m, page, op = PAGES[q["kind"]]
    s0 = q["sids"]
    common = {"operation_Id": q["trace"]}
    A["requests"].append({"timestamp": iso(q["t"]), "id": s0[0], "name": f"{m} {page}", "url": f"https://www.easytravel.example.com{q['path']}",
                          "success": q["fe_status"] < 400, "resultCode": str(q["fe_status"]), "duration": round(q["fe_dur"] * 1000, 3),
                          "performanceBucket": bucket(q["fe_dur"] * 1000), "itemCount": 1, "operation_Name": f"{m} {page}", **common,
                          "operation_ParentId": q["trace"], "cloud_RoleName": "easytravel-frontend", "cloud_RoleInstance": q["web"]})
    A["dependencies"].append({"timestamp": iso(q["t"] + 0.001), "id": s0[1], "target": "easytravel-backend:8091", "type": "HTTP", "name": op,
                              "data": f"http://easytravel-backend:8091{op.split()[1]}", "success": q["be_status"] < 400, "resultCode": str(q["be_status"]),
                              "duration": round((q["be_dur"] + 0.0016) * 1000, 3), "performanceBucket": bucket(q["be_dur"] * 1000), "itemCount": 1,
                              "operation_Name": f"{m} {page}", **common, "operation_ParentId": s0[0], "cloud_RoleName": "easytravel-frontend", "cloud_RoleInstance": q["web"]})
    A["requests"].append({"timestamp": iso(q["t"] + 0.0018), "id": s0[2], "name": op, "url": f"http://easytravel-backend:8091{op.split()[1]}",
                          "success": q["be_status"] < 400, "resultCode": str(q["be_status"]), "duration": round(q["be_dur"] * 1000, 3),
                          "performanceBucket": bucket(q["be_dur"] * 1000), "itemCount": 1, "operation_Name": op, **common, "operation_ParentId": s0[1],
                          "cloud_RoleName": "easytravel-backend", "cloud_RoleInstance": q["app"]})
    if q["timeout"]:
        t1 = q["t"] + q["pre"] + CONN_TIMEOUT
        A["exceptions"].append({"timestamp": iso(t1), "problemId": "java.sql.SQLTransientConnectionException at com.zaxxer.hikari.pool.HikariPool.createTimeoutException",
                                "type": "java.sql.SQLTransientConnectionException", "outerMessage": "HikariPool-1 - Connection is not available, request timed out after 3000ms.",
                                "innermostType": "java.sql.SQLTransientConnectionException", "innermostMessage": "HikariPool-1 - Connection is not available, request timed out after 3000ms.",
                                "severityLevel": 3, "itemCount": 1, "operation_Name": op, **common, "operation_ParentId": s0[2], "cloud_RoleName": "easytravel-backend",
                                "cloud_RoleInstance": q["app"]})
        A["exceptions"].append({"timestamp": iso(q["t"] + q["fe_dur"]), "problemId": "com.example.easytravel.web.BackendCallFailedException at com.example.easytravel.web.JourneyBean.load",
                                "type": "com.example.easytravel.web.BackendCallFailedException", "outerMessage": "easytravel-backend returned 503",
                                "innermostType": "com.example.easytravel.web.BackendCallFailedException", "innermostMessage": "easytravel-backend returned 503",
                                "severityLevel": 3, "itemCount": 1, "operation_Name": f"{m} {page}", **common, "operation_ParentId": s0[0],
                                "cloud_RoleName": "easytravel-frontend", "cloud_RoleInstance": q["web"]})
    else:
        name, stmt = SQL[q["kind"]]
        A["dependencies"].append({"timestamp": iso(q["t"] + 0.0018 + q["pre"] + q["wait"]), "id": s0[4], "target": "et-sql.example.com", "type": "SQL",
                                  "name": name, "data": stmt, "success": True, "resultCode": "0", "duration": round(q["sql"] * 1000, 3),
                                  "performanceBucket": bucket(q["sql"] * 1000), "itemCount": 1, "operation_Name": op, **common, "operation_ParentId": s0[2],
                                  "cloud_RoleName": "easytravel-backend", "cloud_RoleInstance": q["app"]})
        if q["pay"]:
            A["dependencies"].append({"timestamp": iso(q["t"] + q["be_dur"] - q["pay"][1]), "id": s0[5], "target": "payments.example.com", "type": "HTTP",
                                      "name": "POST /v2/authorize", "data": "https://payments.example.com/v2/authorize", "success": q["pay"][0] == "200",
                                      "resultCode": q["pay"][0], "duration": round(q["pay"][1] * 1000, 3), "performanceBucket": bucket(q["pay"][1] * 1000),
                                      "itemCount": 1, "operation_Name": op, **common, "operation_ParentId": s0[2], "cloud_RoleName": "easytravel-backend",
                                      "cloud_RoleInstance": q["app"]})
for t1, svc, host, src, line in logs:
    if src == "app":
        d = json.loads(line)
        sev = {"INFO": 1, "WARN": 2, "ERROR": 3}[d["level"]]
        if d.get("exception"):
            continue                                              # recorded as an exception
        A["traces"].append({"timestamp": iso(t1), "message": d["message"], "severityLevel": sev, "itemCount": 1, "operation_Name": "",
                            "operation_Id": d.get("trace_id", ""), "operation_ParentId": d.get("span_id", ""), "cloud_RoleName": "easytravel-backend",
                            "cloud_RoleInstance": host, "customDimensions": json.dumps({"LoggerName": d["logger"], "SourceType": "Logger"})})
COLS = {"requests": ["timestamp", "id", "name", "url", "success", "resultCode", "duration", "performanceBucket", "itemCount", "operation_Name",
                     "operation_Id", "operation_ParentId", "cloud_RoleName", "cloud_RoleInstance"],
        "dependencies": ["timestamp", "id", "target", "type", "name", "data", "success", "resultCode", "duration", "performanceBucket", "itemCount",
                         "operation_Name", "operation_Id", "operation_ParentId", "cloud_RoleName", "cloud_RoleInstance"],
        "exceptions": ["timestamp", "problemId", "type", "outerType", "outerMessage", "innermostType", "innermostMessage", "severityLevel", "itemCount",
                       "operation_Name", "operation_Id", "operation_ParentId", "cloud_RoleName", "cloud_RoleInstance"],
        "traces": ["timestamp", "message", "severityLevel", "itemCount", "operation_Name", "operation_Id", "operation_ParentId", "cloud_RoleName",
                   "cloud_RoleInstance", "customDimensions"]}
os.makedirs(os.path.join(D, "azure"), exist_ok=True)
for name, rows in A.items():
    rows.sort(key=lambda r: r["timestamp"])
    with open(os.path.join(D, "azure", f"{name}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS[name], lineterminator="\n")
        w.writeheader()
        for r in rows:
            r.setdefault("outerType", r.get("type"))
            w.writerow({k: (str(r.get(k)).lower() if isinstance(r.get(k), bool) else r.get(k, "")) for k in COLS[name]})
print("azure: " + ", ".join(f"{len(v):,} {k}" for k, v in A.items()))
print(f"logs: {len(logs):,} lines; prometheus: {os.path.getsize(os.path.join(D, 'prometheus', 'metrics.om')) / 1e6:.0f} MB")
