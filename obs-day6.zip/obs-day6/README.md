# obs-day6: end-to-end observability operations and incident investigation (lab pack)

Lab files for Day 6 of the observability course. One recorded production incident of easyTravel (17 November 2026,
13:00 to 15:00 UTC) in the format of every tool of the course, and a timed scenario that replays the same kind of
failure on the live easyTravel VMs. All data is invented: example.com names and documentation IP ranges only.

| Lab | Where it runs | What you need from this pack |
| --- | --- | --- |
| 6.1 Correlation and root cause | The Day 6 lab stack: Grafana with Prometheus, Loki and Tempo (Docker) | `docker-compose.yml`, `bin/promq.py`, `bin/logq.py`, `bin/traceq.py` |
| 6.2 SLIs, SLOs, error budgets | The lab stack | `grafana/dashboards/slo.json`, `bin/slo.py` |
| 6.3 Cost and governance | The lab stack, or just Python | `bin/cost.py`, `cost/`, `bin/cardinality.py` |
| 6.4 Best practices | The lab stack | `grafana/`, `alerts/`, `runbooks/`, `bin/alert_sim.py` |
| 6.5 Incident workshop | Splunk (app), the lab stack, Azure Data Explorer free cluster, and one live VM (Dynatrace, Datadog or New Relic) | `splunk/obs_day6_app.tgz`, `setup/`, `data/azure/`, `workshop/`, `bin/scenario.py`, `report/` |

## The data

- **Metrics** (`data/prometheus/metrics.om`, OpenMetrics): request histograms of frontend and backend, connection pools,
  database and host gauges every 15 s; SLO event counters for 28 days (21 October to 18 November) every minute; one
  high-cardinality counter for Lab 6.3.
- **Logs** (`data/loki/logs.jsonl`): 46,310 lines: frontend access logs, backend JSON logs, database logs, change events.
- **Traces** (`data/tempo/spans.jsonl`): 10,841 tail-sampled traces (every failed or slow one, 10 % of the rest), 53,611 spans.
- **Splunk** (`data/splunk/`, packaged in `splunk/obs_day6_app.tgz`): the same logs, indexes `et6_web`, `et6_app`, `et6_db`,
  `et6_os`, `et6_change`.
- **Azure** (`data/azure/*.csv`): Application Insights tables: 60,668 requests, 63,294 dependencies, 3,322 exceptions, 9,240 traces.
- `make_data.py` rebuilds all of it (fixed seed, same output every time). Do not read it before Lab 6.5: it tells the story.

## Start and check

```bash
docker compose up -d                  # first start: about 3 minutes to load metrics, logs and traces
docker compose ps -a                  # the three loaders show "Exited (0)" when they are done
python3 bin/check.py stack            # Prometheus, Loki, Tempo with the Day 6 data, Grafana
# Grafana: http://localhost:3000 (admin / admin, then choose a new password); folder obs-day6
```

Splunk: Apps > Manage Apps > Install app from file > `splunk/obs_day6_app.tgz`, restart, then set your time zone to UTC.
Azure Data Explorer: create the database `obsday6`, run `setup/create-tables.kql`, then Get data > Local file for each CSV.
Live replay (Lab 6.5): on the VM, `python3 bin/check.py vm`, then `python3 bin/scenario.py lab65`.

## Expected results

`bin/expected.py spl` and `bin/expected.py kql` print the expected result of every Splunk and Azure Data Explorer
workshop query, computed from the data files. The Lab Guide shows the expected output of the PromQL, LogQL and TraceQL
queries, run against this stack.

## Contents

| Path | What it is |
| --- | --- |
| `docker-compose.yml`, `prometheus/`, `loki/`, `tempo/` | The lab stack and its configuration |
| `grafana/provisioning/` | Data sources (logs to traces, traces to logs and metrics) and the dashboard folder |
| `grafana/dashboards/` | Service overview, SLOs, golden signals v2 (the one to improve in Lab 6.4) |
| `grafana/solutions/golden-signals-v3.json` | A possible answer for Lab 6.4 |
| `grafana/build_dashboards.py` | Writes the dashboard files |
| `alerts/rules-current.yml`, `alerts/rules-improved.yml`, `alerts/rules-tests.yml` | Alert rules before and after, and their unit tests |
| `bin/alert_sim.py` | Replays alert rules over the incident and shows when each fires |
| `runbooks/` | Runbook index, five runbooks, a template, the escalation evidence checklist |
| `bin/slo.py` | SLIs, error budget, budget used per incident, burn rates |
| `bin/cost.py`, `cost/prices.json` | Monthly telemetry cost and four optimisations (prices are examples) |
| `bin/cardinality.py` | Series per metric and values per label |
| `cost/otel-collector-optimised.yaml`, `cost/prometheus-scrape-guard.yml` | The recommendations as configuration |
| `workshop/` | The Lab 6.5 queries: Splunk SPL, LogQL, PromQL, TraceQL, KQL, Dynatrace DQL, NRQL, Datadog |
| `bin/expected.py` | Expected results of the SPL and KQL workshop queries |
| `bin/promq.py`, `bin/logq.py`, `bin/traceq.py` | Run PromQL, LogQL and TraceQL from the shell |
| `bin/load_loki.py`, `bin/load_tempo.py` | Load the logs and traces (the stack runs them for you) |
| `splunk/` | The Splunk app and `build_app.py`, which packages it |
| `setup/create-tables.kql` | Creates the Application Insights tables in Azure Data Explorer |
| `bin/scenario.py`, `bin/pattern.py`, `bin/etlib.py` | The live replay on an easyTravel VM |
| `bin/dd_javaopts.py`, `bin/nr_javaopts.py` | Agent options for the Datadog and New Relic VMs (from Days 2 and 4) |
| `report/` | Incident report template and an example report (read it after you wrote yours) |
| `bin/check.py` | Checks the lab stack or a live VM |

## Secrets

Lab-only secrets, never committed. The live VMs use the agent keys and tokens of Days 2 to 4: enter them in the shell only
(`read -rs DD_API_KEY && export DD_API_KEY`), never in a file in this folder, a chat or a screenshot. The lab stack has no
secrets; change Grafana's admin password at first login. `.gitignore` excludes `*.env`.

## Clean up

- Lab stack: `docker compose down -v` removes the containers and the loaded data.
- Splunk: Apps > Manage Apps > obs_day6 > Delete (or remove `etc/apps/obs_day6`), and the five `et6_*` indexes.
- Azure Data Explorer: delete the database `obsday6`.
- Live VMs: `python3 bin/pattern.py reset` turns every problem pattern off.
