# DatabaseCPUSaturated (slow queries)

| | |
| --- | --- |
| **Severity** | warning (DBA team chat) |
| **Owner** | DBA team |
| **Alert rule** | alerts/rules-improved.yml, DatabaseCPUSaturated |
| **Dashboard** | easyTravel service overview, panel Database CPU |

## What it means
db-01 has used more than 90 % CPU for 5 minutes. Usually one query pattern is doing far more work than before: a missing
index, a changed plan, or a new query from a release.

## Check first (5 minutes)
1. Which statement? `sum by (query_hash) (count_over_time({service="db"} |= "slow_query" | logfmt [5m]))` and the
   `plan=` field (`TableScan` instead of an index seek).
2. Since when, and what changed just before? `{service="db"} |= "event"` (DDL such as DROP INDEX), deployments.
3. Who calls it? The `db.query.text` of the slow database spans in Tempo, and their service and operation.

## Mitigate
Re-create a missing index online (`CREATE INDEX ... WITH (ONLINE = ON)`), or force the previous plan; tell the app team
whether to roll back their release.

## Escalate
To the app team owning the calling service, with the evidence of ESCALATION.md.
