# Escalation evidence: what to send

When you hand an incident to another team, send evidence they can verify in two minutes, not a feeling.

1. **What users see**: the symptom and its size, with numbers: "16 % of frontend requests fail since 13:42 UTC".
2. **Time range** in UTC, and when it started (first bad data point), not when the alert fired.
3. **The query and its result** for each claim: the query text, where you ran it, and the result (a screenshot or a
   pasted table). A query lets the other team re-run it; a screenshot alone does not.
4. **One or two example IDs**: trace ID, request ID, operation ID; they open the same request in every tool.
5. **What changed** near the start: deployments, configuration, database changes, with change IDs.
6. **What you ruled out**, and how.
7. **What you need** from the team, and how urgent it is.

Template for the chat message or ticket:

    [INC-xxxx] <service>: <symptom with numbers> since <time UTC>
    Evidence: <dashboard link with time range> | <query> -> <result>
    Example trace: <trace ID>
    Changes near the start: <change IDs>
    Ruled out: <...>
    Ask: <what you need, by when>
