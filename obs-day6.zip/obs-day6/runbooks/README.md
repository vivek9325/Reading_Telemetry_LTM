# easyTravel runbook index

Every alert links one runbook (`runbook_url`) and one dashboard (`dashboard`). This index is the reverse view: what exists,
who owns it, and when it was last tested. Review it monthly with the alert review (Day 5, Lab 5.4).

| Alert | Severity | Runbook | Dashboard | Owner | Escalate to | Last tested |
| --- | --- | --- | --- | --- | --- | --- |
| ErrorBudgetBurnFast | critical (page) | [error-budget-burn.md](error-budget-burn.md) | `/d/easytravel-slo` | app on-call | incident manager after 15 min | 2026-11-17 (INC-2291) |
| ErrorBudgetBurnSlow | critical (page) | [error-budget-burn.md](error-budget-burn.md) | `/d/easytravel-slo` | app on-call | app team lead | 2026-11-17 |
| ErrorBudgetBurnTicket | ticket | [error-budget-burn.md](error-budget-burn.md) | `/d/easytravel-slo` | app team | product owner (release freeze) | |
| LatencyBudgetBurnFast | critical (page) | [latency.md](latency.md) | `/d/easytravel-slo` | app on-call | incident manager after 15 min | 2026-11-17 |
| EasyTravelErrorRatioHigh | critical (page) | [error-ratio.md](error-ratio.md) | `/d/easytravel-golden-v2` | app on-call | incident manager after 15 min | 2026-11-17 |
| DatabaseConnectionPoolExhausted | warning (chat) | [connection-pool.md](connection-pool.md) | `/d/easytravel-incident` | app team | DBA on-call if the database is slow | 2026-11-17 |
| DatabaseCPUSaturated | warning (chat) | [db-slow-query.md](db-slow-query.md) | `/d/easytravel-incident` | DBA team | DBA on-call | 2026-11-17 |

Writing a new runbook: start from [TEMPLATE.md](TEMPLATE.md). Collecting evidence for an escalation: [ESCALATION.md](ESCALATION.md).
