# ErrorBudgetBurnFast, ErrorBudgetBurnSlow, ErrorBudgetBurnTicket

| | |
| --- | --- |
| **Severity** | Fast and Slow: critical (page); Ticket: ticket |
| **Owner** | app team |
| **Alert rules** | alerts/rules-improved.yml |
| **Dashboard** | easyTravel SLOs (`/d/easytravel-slo`), then easyTravel golden signals |

## What it means
The frontend fails requests (5xx) faster than its availability objective allows (99.9 % over 28 days). Fast: 14.4 times
the allowed rate for an hour (2 % of the monthly budget). Slow: 6 times for 6 hours (5 %). Ticket: above budget for 3 days.

## Check first (5 minutes)
1. SLO dashboard: burn rate now (1 h) and budget left. Is it still burning?
2. Golden signals dashboard of the frontend, then of the backend: which service, which pages, since when?
3. Dependencies: connection pool, database CPU (service overview dashboard). Changes in the last hour (annotations).

## Mitigate
Follow the runbook of the cause you find (error-ratio.md, connection-pool.md, db-slow-query.md). Roll back a recent change
first if one lines up with the start.

## Escalate
Fast or Slow for more than 15 minutes: incident manager. Ticket: product owner; with less than 25 % of the budget left,
releases stop until it recovers (error budget policy).

## Afterwards
Record the budget used by the incident in the post-incident review (SLO dashboard, or `bin/slo.py`).
