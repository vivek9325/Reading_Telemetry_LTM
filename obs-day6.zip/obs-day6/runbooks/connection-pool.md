# DatabaseConnectionPoolExhausted

| | |
| --- | --- |
| **Severity** | warning (app team chat) |
| **Owner** | app team |
| **Alert rule** | alerts/rules-improved.yml, DatabaseConnectionPoolExhausted |
| **Dashboard** | easyTravel service overview (`/d/easytravel-incident`), panel Connection pool |

## What it means
All 10 connections of HikariPool-1 on a backend instance are in use and threads wait for one. After 3 seconds of waiting a
request fails with `SQLTransientConnectionException` and the frontend answers 500. The pool is a symptom of slow queries
far more often than of too few connections.

## Check first (5 minutes)
1. Are the queries slow? Backend latency by operation; the database span in a trace (`{ span.db.system = "mssql" && duration > 1s }` in Tempo).
2. Is the database busy? Database CPU panel; slow query log: `{service="db"} |= "slow_query" | logfmt`.
3. What changed? Annotations on the dashboard; `{service="cicd"} | json`; database events: `{service="db"} |= "event"`.

## Mitigate
1. A slow query after a change: roll the change back, or let the DBA fix the plan (missing index: re-create it online).
2. Do not raise the pool size first: more connections send more slow queries to a database that is already saturated.

## Escalate
DBA on-call when the database CPU is above 90 % or the slow query log grows. Attach the evidence of ESCALATION.md.
