#!/usr/bin/env python3
"""Write the Day 6 dashboards (Grafana 12, for the Day 6 lab stack; data sources uid prometheus, loki and tempo).

grafana/dashboards/service-overview.json   easyTravel service overview (Lab 6.1), provisioned
grafana/dashboards/slo.json                easyTravel SLOs (Lab 6.2), provisioned
grafana/dashboards/golden-signals.json     easyTravel golden signals v2, the dashboard you update in Lab 6.4, provisioned
grafana/solutions/golden-signals-v3.json   one possible answer for Lab 6.4 (Dashboards, New, Import, Upload dashboard JSON file)
"""
import copy, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
PROM = {"type": "prometheus", "uid": "prometheus"}
LOKI = {"type": "loki", "uid": "loki"}
TIME = {"from": "2026-11-12T09:00:00.000Z", "to": "2026-11-12T11:00:00.000Z"}
REQ = 'http_server_requests_seconds'
_id = [0]


def nid():
    _id[0] += 1
    return _id[0]


def thresholds(*steps):
    return {"mode": "absolute", "steps": [{"color": c, "value": v} for c, v in steps]}


def target(expr, legend="", ref="A", instant=False, ds=PROM, **kw):
    t = {"refId": ref, "datasource": ds, "expr": expr, "legendFormat": legend}
    if ds is PROM:
        t.update({"range": not instant, "instant": instant})
    t.update(kw)
    return t


def ts(title, grid, targets, unit, desc="", ds=PROM, thr=None, overrides=None, **custom):
    fc = {"defaults": {"unit": unit, "custom": dict({"lineWidth": 2, "fillOpacity": 8}, **custom)}, "overrides": overrides or []}
    if thr:
        fc["defaults"]["thresholds"] = thr
        fc["defaults"]["custom"]["thresholdsStyle"] = {"mode": "line+area" if custom.pop("area", False) else "dashed"}
    return {"id": nid(), "type": "timeseries", "title": title, "description": desc, "datasource": ds, "gridPos": grid,
            "targets": targets, "fieldConfig": fc,
            "options": {"legend": {"displayMode": "list", "placement": "bottom"}, "tooltip": {"mode": "multi", "sort": "desc"}}}


def stat(title, grid, expr, unit, thr, desc="", decimals=None, ds=PROM):
    d = {"unit": unit, "thresholds": thr, "color": {"mode": "thresholds"}}
    if decimals is not None:
        d["decimals"] = decimals
    return {"id": nid(), "type": "stat", "title": title, "description": desc, "datasource": ds, "gridPos": grid,
            "targets": [target(expr, instant=True)], "fieldConfig": {"defaults": d, "overrides": []},
            "options": {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                        "colorMode": "background", "graphMode": "none", "textMode": "value", "justifyMode": "center"}}


def row(title, y, collapsed=False, panels=None):
    return {"id": nid(), "type": "row", "title": title, "collapsed": collapsed, "gridPos": {"x": 0, "y": y, "w": 24, "h": 1},
            "panels": panels or []}


def var(name, query, label, multi=False, include_all=False, current=None):
    v = {"type": "query", "name": name, "label": label, "datasource": PROM, "query": query, "definition": query,
         "refresh": 1, "sort": 1, "multi": multi, "includeAll": include_all, "hide": 0}
    if current:
        v["current"] = {"text": current, "value": current, "selected": True}
    if include_all:
        v["allValue"] = ".*"
    return v


def dash(uid, title, panels, tags, templating=(), links=(), desc=""):
    return {"uid": uid, "title": title, "description": desc, "tags": tags, "timezone": "utc", "schemaVersion": 39,
            "version": 1, "editable": True, "graphTooltip": 1, "refresh": "", "time": TIME,
            "templating": {"list": list(templating)}, "annotations": {"list": []}, "links": list(links), "panels": panels}



TEMPO = {"type": "tempo", "uid": "tempo"}
INC = {"from": "2026-11-17T13:00:00.000Z", "to": "2026-11-17T15:00:00.000Z"}
WIN = {"from": "2026-10-21T00:00:00.000Z", "to": "2026-11-18T00:00:00.000Z"}
FE = 'service="easytravel-frontend"'
CHANGES = {"name": "Changes", "datasource": LOKI, "enable": True, "iconColor": "purple",
           "expr": '{service="cicd"} | json', "titleFormat": "{{type}} {{change}}", "textFormat": "{{message}}", "tagKeys": "type,status"}


def logs(title, grid, expr, desc=""):
    return {"id": nid(), "type": "logs", "title": title, "description": desc, "datasource": LOKI, "gridPos": grid,
            "targets": [target(expr, ds=LOKI, queryType="range")],
            "options": {"showTime": True, "wrapLogMessage": True, "sortOrder": "Descending", "enableLogDetails": True}}


def with_time(d, t, annotations=()):
    d["time"] = t
    d["annotations"] = {"list": list(annotations)}
    return d


# ---------------------------------------------------------------------------------------- Lab 6.1: incident overview
_id[0] = 0
ov = [
    row("Symptoms", 0),
    ts("Frontend error rate", {"x": 0, "y": 1, "w": 8, "h": 8},
       [target(f'sum(rate({REQ}_count{{{FE}, status=~"5.."}}[$__rate_interval])) / sum(rate({REQ}_count{{{FE}}}[$__rate_interval]))', "5xx share")],
       "percentunit", "Share of frontend requests answered with 5xx", thr=thresholds(("green", None), ("orange", 0.01), ("red", 0.05))),
    ts("Frontend latency", {"x": 8, "y": 1, "w": 8, "h": 8},
       [target(f'histogram_quantile(0.5, sum by (le) (rate({REQ}_bucket{{{FE}}}[$__rate_interval])))', "p50"),
        target(f'histogram_quantile(0.95, sum by (le) (rate({REQ}_bucket{{{FE}}}[$__rate_interval])))', "p95", "B")], "s"),
    ts("Requests per second", {"x": 16, "y": 1, "w": 8, "h": 8},
       [target(f'sum by (service) (rate({REQ}_count{{job="easytravel"}}[$__rate_interval]))', "{{service}}")], "reqps"),
    row("Backend and database", 9),
    ts("Connection pool (HikariPool-1)", {"x": 0, "y": 10, "w": 8, "h": 8},
       [target('max by (instance) (max_over_time(hikaricp_connections_active[$__rate_interval]))', "active {{instance}}"),
        target('max by (instance) (max_over_time(hikaricp_connections_pending[$__rate_interval]))', "pending {{instance}}", "B"),
        target('max(hikaricp_connections_max)', "max", "C")], "short", "Connections in use and threads waiting for one"),
    ts("Database CPU (db-01)", {"x": 8, "y": 10, "w": 8, "h": 8}, [target('avg_over_time(db_cpu_utilization[$__rate_interval])', "db-01")],
       "percentunit", min=0, max=1),
    ts("Backend latency p95 by operation", {"x": 16, "y": 10, "w": 8, "h": 8},
       [target(f'histogram_quantile(0.95, sum by (le, uri) (rate({REQ}_bucket{{service="easytravel-backend"}}[$__rate_interval])))', "{{uri}}")], "s"),
    row("Logs", 18),
    ts("Backend log lines by level", {"x": 0, "y": 19, "w": 8, "h": 8},
       [target('sum by (level) (count_over_time({service="backend"} | json [$__auto]))', "{{level}}", ds=LOKI, queryType="range")], "short",
       ds=LOKI, drawStyle="bars", fillOpacity=80, stacking={"mode": "normal", "group": "A"}),
    logs("Backend errors and warnings", {"x": 8, "y": 19, "w": 16, "h": 8}, '{service="backend"} | json | level=~"WARN|ERROR"',
         "Open a line: the trace_id field links to the trace in Tempo"),
]
for p in ov:
    if p["type"] == "timeseries":
        c = p["fieldConfig"]["defaults"]["custom"]
        for k in ("min", "max"):
            if k in c:
                p["fieldConfig"]["defaults"][k] = c.pop(k)
overview = with_time(dash("easytravel-incident", "easyTravel service overview", ov, ["obs-day6", "easytravel"],
                          desc="Symptoms, backend and database, logs (Lab 6.1 starts here)"), INC, [CHANGES])

# ---------------------------------------------------------------------------------------- Lab 6.2: SLO dashboard
_id[0] = 0
SLO = [("availability", 0.999, "Availability: requests answered without a 5xx", "99.9 %"),
       ("latency", 0.99, "Latency: requests answered within 1 s", "99 %")]
sp = []
y = 0
for sli, obj, label, objtxt in SLO:
    good = f'easytravel_slo_events_total{{sli="{sli}", outcome="good"}}'
    bad = f'easytravel_slo_events_total{{sli="{sli}", outcome="bad"}}'
    allq = f'easytravel_slo_events_total{{sli="{sli}"}}'
    budget = round(1 - obj, 6)
    sp.append(row(f"{label} (objective {objtxt}, 28 days)", y))
    sp += [
        stat("SLI, last 28 days", {"x": 0, "y": y + 1, "w": 6, "h": 4}, f'sum(increase({good}[28d])) / sum(increase({allq}[28d]))',
             "percentunit", thresholds(("red", None), ("green", obj)), f"Good events divided by all events; objective {objtxt}", decimals=3),
        stat("Error budget remaining", {"x": 6, "y": y + 1, "w": 6, "h": 4},
             f'1 - (sum(increase({bad}[28d])) / sum(increase({allq}[28d]))) / {budget}', "percentunit",
             thresholds(("red", None), ("orange", 0.25), ("green", 0.5)), "Share of the 28-day error budget not used yet", decimals=1),
        stat("Burn rate, last 1 h", {"x": 12, "y": y + 1, "w": 6, "h": 4},
             f'(sum(rate({bad}[1h])) / sum(rate({allq}[1h]))) / {budget}', "short",
             thresholds(("green", None), ("orange", 1), ("red", 14.4)), "1 means the budget lasts exactly 28 days; 14.4 means 2 % of it in an hour", decimals=1),
        stat("Burn rate, last 6 h", {"x": 18, "y": y + 1, "w": 6, "h": 4},
             f'(sum(rate({bad}[6h])) / sum(rate({allq}[6h]))) / {budget}', "short",
             thresholds(("green", None), ("orange", 1), ("red", 6)), "6 means 5 % of the budget in 6 hours", decimals=1),
        ts("Error budget remaining over the window", {"x": 0, "y": y + 5, "w": 12, "h": 8},
           [target(f'1 - (sum({bad}) / sum({allq})) / {budget}', "budget remaining")], "percentunit",
           "From the start of the window: 1 - (bad / all) / allowed share", thr=thresholds(("red", None), ("orange", 0.25), ("green", 0.5))),
        ts("Burn rate (1 h and 6 h)", {"x": 12, "y": y + 5, "w": 12, "h": 8},
           [target(f'(sum(rate({bad}[1h])) / sum(rate({allq}[1h]))) / {budget}', "1 h"),
            target(f'(sum(rate({bad}[6h])) / sum(rate({allq}[6h]))) / {budget}', "6 h", "B")], "short",
           "How fast the budget is being used; 1 = exactly on budget", scaleDistribution={"type": "log", "log": 10}),
    ]
    y += 13
slo = with_time(dash("easytravel-slo", "easyTravel SLOs", sp, ["obs-day6", "easytravel", "slo"],
                     desc="Two SLOs of the easyTravel frontend over a 28-day window (Lab 6.2)"), WIN)

# ---------------------------------------------------------------------------------------- Lab 6.4: golden signals v2 and an answer
S_, I_ = 'service="$service"', 'instance=~"$instance"'
SEL, SEL5 = f'{{{S_}, {I_}}}', f'{{{S_}, {I_}, status=~"5.."}}'
TV = [var("service", f'label_values({REQ}_count{{job="easytravel"}}, service)', "Service", current="easytravel-backend"),
      var("instance", f'label_values({REQ}_count{{service="$service"}}, instance)', "Instance", multi=True, include_all=True, current="All")]


def golden_panels(extra=False):
    _id[0] = 0
    q = lambda x: f'histogram_quantile({x}, sum by (le) (rate({REQ}_bucket{SEL}[$__rate_interval])))'
    p = [
        stat("Availability (time range)", {"x": 0, "y": 0, "w": 6, "h": 4},
             f'1 - (sum(increase({REQ}_count{SEL5}[$__range])) or vector(0)) / sum(increase({REQ}_count{SEL}[$__range]))',
             "percentunit", thresholds(("red", None), ("orange", 0.99), ("green", 0.999)), decimals=2),
        stat("Traffic now", {"x": 6, "y": 0, "w": 6, "h": 4}, f'sum(rate({REQ}_count{SEL}[5m]))', "reqps", thresholds(("blue", None)), decimals=2),
        stat("Error rate now", {"x": 12, "y": 0, "w": 6, "h": 4},
             f'(sum(rate({REQ}_count{SEL5}[5m])) or vector(0)) / sum(rate({REQ}_count{SEL}[5m]))', "percentunit",
             thresholds(("green", None), ("orange", 0.01), ("red", 0.05)), decimals=2),
        stat("p95 latency now", {"x": 18, "y": 0, "w": 6, "h": 4}, q(0.95).replace("$__rate_interval", "5m"), "s",
             thresholds(("green", None), ("orange", 0.5), ("red", 1)), decimals=2),
        ts("Latency", {"x": 0, "y": 4, "w": 12, "h": 8}, [target(q(0.5), "p50"), target(q(0.95), "p95", "B"), target(q(0.99), "p99", "C")], "s",
           thr=thresholds(("green", None), ("red", 1))),
        ts("Traffic", {"x": 12, "y": 4, "w": 12, "h": 8}, [target(f'sum by (uri) (rate({REQ}_count{SEL}[$__rate_interval]))', "{{uri}}")], "reqps"),
        ts("Errors", {"x": 0, "y": 12, "w": 12, "h": 8},
           [target(f'sum(rate({REQ}_count{SEL5}[$__rate_interval])) / sum(rate({REQ}_count{SEL}[$__rate_interval]))', "5xx share")],
           "percentunit", thr=thresholds(("green", None), ("orange", 0.01), ("red", 0.05))),
        ts("Saturation: CPU", {"x": 12, "y": 12, "w": 12, "h": 8},
           [target(f'avg_over_time(process_cpu_usage{SEL}[$__rate_interval])', "CPU {{instance}}")], "percentunit"),
    ]
    if extra:
        p[3]["gridPos"]["w"] = 4
        for k, x in ((0, 0), (1, 5), (2, 10), (3, 15)):
            p[k]["gridPos"].update({"x": x, "w": 5 if k < 3 else 4})
        p.append(stat("Error budget burn (1 h)", {"x": 19, "y": 0, "w": 5, "h": 4},
                      '(sum(rate(easytravel_slo_events_total{sli="availability", outcome="bad"}[1h])) / sum(rate(easytravel_slo_events_total{sli="availability"}[1h]))) / 0.001',
                      "short", thresholds(("green", None), ("orange", 1), ("red", 14.4)),
                      "Availability SLO (99.9 %, 28 days) of the frontend: how fast the error budget burns", decimals=1))
        p[-1]["links"] = [{"title": "SLO dashboard", "url": "/d/easytravel-slo?${__url_time_range}"}]
        p[7]["title"] = "Saturation: CPU and connection pool"
        p[7]["targets"].append(target(f'max by (instance) (max_over_time(hikaricp_connections_active{SEL}[$__rate_interval])) / max by (instance) (hikaricp_connections_max{SEL})',
                                      "pool {{instance}}", "B"))
        p[7]["fieldConfig"]["defaults"].update({"min": 0, "max": 1})
        p[7]["description"] = "CPU of the service, and connections in use as a share of the pool (backend only)"
        p.append(row("Dependencies", 20))
        p.append(ts("Database CPU and pending connections", {"x": 0, "y": 21, "w": 12, "h": 8},
                    [target('avg_over_time(db_cpu_utilization[$__rate_interval])', "db-01 CPU"),
                     target('sum(max_over_time(hikaricp_connections_pending[$__rate_interval])) / 10', "pending connections / 10", "B")], "percentunit",
                    "db-01 CPU, and threads waiting for a database connection (divided by 10 to share the axis)"))
        p.append(logs("Changes and errors", {"x": 12, "y": 21, "w": 12, "h": 8},
                      '{service=~"cicd|db"} |~ "event|deployment|change|incident"', "Deployments, database events and incident records"))
        RB = "https://runbooks.example.com/easytravel/"
        for k, rb in ((2, "error-ratio"), (3, "latency"), (6, "error-ratio"), (4, "latency"), (7, "connection-pool")):
            p[k]["links"] = p[k].get("links", []) + [{"title": "Runbook", "url": RB + rb, "targetBlank": True}]
        p[6]["fieldConfig"]["defaults"]["links"] = [{"title": "Failed traces in Tempo",
                                                      "url": '/explore?left={"datasource":"tempo","queries":[{"refId":"A","queryType":"traceql","query":"{ resource.service.name = \\"${service}\\" && status = error }"}],"range":{"from":"${__from}","to":"${__to}"}}'}]
    for x in p:
        if x["type"] == "timeseries":
            c = x["fieldConfig"]["defaults"]["custom"]
            for k in ("min", "max"):
                if k in c:
                    x["fieldConfig"]["defaults"][k] = c.pop(k)
    return p


gs2 = with_time(dash("easytravel-golden-v2", "easyTravel golden signals v2", golden_panels(), ["obs-day6", "easytravel", "golden-signals"], TV,
                     desc="The golden signals dashboard of Day 5, carried over (Lab 6.4: update it)"), INC)
gs3 = with_time(dash("easytravel-golden-v3", "easyTravel golden signals v3", golden_panels(True), ["obs-day6", "easytravel", "golden-signals"], TV,
                     links=[{"title": "SLOs", "type": "link", "url": "/d/easytravel-slo", "icon": "dashboard"},
                            {"title": "Service overview", "type": "link", "url": "/d/easytravel-incident?${__url_time_range}", "icon": "dashboard"},
                            {"title": "Runbooks", "type": "link", "url": "https://runbooks.example.com/easytravel/", "icon": "doc", "targetBlank": True}],
                     desc="Golden signals with SLO burn, dependencies, changes and runbook links (Lab 6.4, one possible answer)"), INC, [CHANGES])

os.makedirs(os.path.join(HERE, "dashboards"), exist_ok=True)
os.makedirs(os.path.join(HERE, "solutions"), exist_ok=True)
for path, d in [("dashboards/service-overview.json", overview), ("dashboards/slo.json", slo), ("dashboards/golden-signals.json", gs2),
                ("solutions/golden-signals-v3.json", gs3)]:
    with open(os.path.join(HERE, path), "w") as f:
        json.dump(d, f, indent=2)
    n = sum(1 + len(p.get("panels", [])) for p in d["panels"])
    print(f"wrote grafana/{path} ({n} panels)")
