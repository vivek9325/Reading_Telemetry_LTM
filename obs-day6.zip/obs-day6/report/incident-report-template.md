# Incident report: <INC-number> <one-line title>

| | |
| --- | --- |
| **Status** | draft / reviewed / closed |
| **Severity** | SEV1 / SEV2 / SEV3 |
| **Services** | |
| **Impact window (UTC)** | first bad data point to last bad data point |
| **Author, reviewers** | |
| **Report date** | |

## 1. Summary
Three to five sentences a manager can read: what users saw, how big it was, how long it lasted, the cause, the fix.

## 2. Impact
| Measure | Value | Evidence (query, tool) |
| --- | --- | --- |
| Failed requests | | |
| Slow requests (above the latency SLO) | | |
| Users or sessions affected | | |
| Functions affected (search, booking, ...) | | |
| Error budget used: availability | | |
| Error budget used: latency | | |
| Error budget left after the incident | | |

## 3. Timeline (UTC)
One line per fact, each with its source. Include the change, the first bad data point, detection, escalation, mitigation,
recovery and closure.

| Time | What happened | Source |
| --- | --- | --- |
| | | |

Durations: time to detect (first bad data point to first alert), time to engage (alert to incident opened), time to
mitigate (first bad data point to recovery), time to resolve.

## 4. Investigation
The path you followed: which signal you started from, what each query showed, and why you went to the next one.
Metrics to logs to traces, or the other way round. Put the queries and their results in section 7.

## 5. Root cause and contributing factors
**Root cause**: the change or condition without which the incident would not have happened.
**Trigger**: what started it at that moment. **Contributing factors**: what made it worse, longer, or later to detect.
Write what happened in systems and processes, not who is to blame.

## 6. What went well, what did not
| Went well | Did not go well |
| --- | --- |
| | |

## 7. Evidence
For each claim in the report: the query, where it ran, the time range, and the result (a table or a screenshot of the
dashboard panel). Name the example trace or operation IDs.

| # | Claim | Tool | Query | Result |
| --- | --- | --- | --- | --- |
| E1 | | | | |

## 8. Remediation
| # | Action | Type (prevent / detect / mitigate) | Owner | Due | Ticket |
| --- | --- | --- | --- | --- | --- |
| R1 | | | | | |

## 9. Observability follow-ups
Gaps the incident showed in dashboards, alerts, runbooks, telemetry (missing signal, wrong sampling, cost) and who fixes them.
