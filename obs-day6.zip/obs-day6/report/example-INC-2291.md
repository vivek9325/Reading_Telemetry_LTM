# Incident report: INC-2291 Journey search slow and failing after release 3.6.0

Example answer for Lab 6.5. Write your own report first; then compare. All data is invented lab data.

| | |
| --- | --- |
| **Status** | reviewed |
| **Severity** | SEV2 (one in six requests failed for 41 minutes; bookings affected) |
| **Services** | easytravel-frontend, easytravel-backend (JourneyService, BookingService), et-sql (db-01) |
| **Impact window (UTC)** | 2026-11-17 13:42:31 (first slow search) to 14:23:31 (index re-created) |
| **Author, reviewers** | on-call app engineer; DBA on-call, release manager |

## 1. Summary
From 13:42 to 14:23 UTC, 1,661 easyTravel requests (16 % of all requests at the peak) failed with HTTP 500, and searches
took up to 14 seconds (p95). Release 3.6.0 ran database migration V36, which dropped the journey search index and then
failed to create its replacement because of a lock timeout, while the migration tool still reported success. Without
the index, every search scanned the whole journeys table; the database CPU saturated, queries held the backend's
connections, and requests that waited more than 3 seconds for a connection failed. The DBA re-created the index online
at 14:20; the service was normal from 14:23:31. The incident used 24.6 % of the 28-day availability error budget.

## 2. Impact
| Measure | Value | Evidence |
| --- | --- | --- |
| Failed requests | 1,661 of 30,334 (13:00 to 15:00); 6.9 % to 18.8 % per 5 minutes | E1, E6 |
| Failed by function | search 919, trip details 534, booking 208 | E2 |
| Slow requests (> 1 s) | 8,708 in the incident (latency SLI) | E9 |
| Sessions affected | 1,026 sessions had at least one failed request | E6 |
| Error budget used | availability 24.6 %, latency 12.9 % of the 28-day budget | E9 |
| Error budget left | availability 36.0 %, latency 48.4 % (28 days to 18 Nov 00:00) | E9 |

## 3. Timeline (UTC)
| Time | What happened | Source |
| --- | --- | --- |
| 13:41:50 | CHG-4815: rolling deployment of JourneyService 3.6.0 starts | change log (E5) |
| 13:42:31 | Flyway V36 on app-01: migrating to version 36 | backend log app-01 |
| 13:42:32 | DROP INDEX IX_journeys_destination completed | database log, Flyway log |
| 13:42:31.7 | First slow search: 1.7 s, table scan, on app-02 (still 3.5.2) | trace 8a781fdb... (E4) |
| 13:42:41.6 | First failed request: trip details, pool timeout on app-02 (3.5.2) | trace 0d6e812b... (E3) |
| 13:43:02 | CREATE INDEX IX_journeys_destination_departure fails: error 1222, lock request time out | database log, Flyway WARN |
| 13:43:03 | Flyway: "successfully applied 1 migration" | backend log app-01 |
| 13:43:25 | CHG-4815 reported succeeded | change log |
| 13:47:00 | EasyTravelErrorRatioHigh fires (16 % 5xx) and pages on-call | alert event |
| 13:58:12 | INC-2291 opened | change log |
| 14:19:25 | CHG-4816 approved: re-create the index online | change log |
| 14:20:05 | CREATE INDEX ... WITH (ONLINE = ON) starts | database log |
| 14:23:23 | Last failed request (start time) | access log (E6) |
| 14:23:31 | Index created in 206 s; queries back to index seek | database log |
| 14:25 | Error ratio 0 %, database CPU 16 %, p95 0.22 s | dashboards (E1, E7) |
| 14:34:10 | INC-2291 resolved | change log |

Time to detect 4 min 19 s (first failure to page). Time to engage 15 min 31 s (first failure to incident). Time to
mitigate 41 min (first slow search to index created).

## 4. Investigation
1. **Metrics (detect)**: the frontend 5xx ratio rose from 0 to 6 % at 13:45 and 16 % at 13:50 (E1); backend p95 of
   findJourneys was 14.8 s, getJourneyById and storeBooking about 4.5 s (E7). Every operation got slow, not only search:
   a shared dependency, not one endpoint.
2. **Metrics (dependency)**: both backend connection pools at 10 of 10 from 13:45, 784 and 877 connection timeouts;
   database CPU from 16 % to 99 % (E7).
3. **Logs**: all 1,661 backend errors are `SQLTransientConnectionException: Connection is not available, request timed
   out after 3000ms` (E3). The database slow query log shows one statement, hash 0x8F3A2C1D, 5,023 times, average 9.1 s,
   plan `TableScan(journeys)` (E4).
4. **Traces**: the first failed trace spends 3,000 ms in `HikariPool-1 getConnection`; a slow search spends 1.7 s in
   `SELECT easytravel.journeys`. The first failures ran on app-02 with version 3.5.2 (11 failed traces on 3.5.2, 1,650 on
   3.6.0): the old code failed too, so the cause is in the shared database, not in the new code (E3, E8).
5. **Change**: 10 seconds before the first slow query, the migration of 3.6.0 dropped the index the search uses; its
   replacement failed at 13:43:02, while Flyway and the pipeline reported success (E5).

## 5. Root cause and contributing factors
**Root cause**: migration V36 dropped `IX_journeys_destination` before creating its replacement, and the creation failed
(lock timeout), so the journey search query lost its index.
**Trigger**: deployment CHG-4815 at 13:41:50, during normal daytime traffic.
**Contributing factors**:
- The migration reported success after a failed DDL statement, so the deployment passed.
- The connection pool (10 per instance, 3 s timeout) turned slow queries into failures for every operation.
- No alert on pool saturation or database CPU; the error ratio alert had no runbook, so the incident was opened 11
  minutes after the page.
- The change log was not on the dashboards: the link between release and errors was found by hand.

## 6. What went well, what did not
| Went well | Did not go well |
| --- | --- |
| Tail sampling kept every failed and slow trace | Detection only on the symptom (5xx), 4 min after the start |
| Trace IDs in access and backend logs: one ID opened the request everywhere | 11 minutes from page to incident |
| The DBA fix (online index) worked without downtime | Deployment reported success after a failed migration |

## 7. Evidence
| # | Claim | Tool | Query (workshop file) | Result |
| --- | --- | --- | --- | --- |
| E1 | 5xx ratio per 5 min | Prometheus | prometheus.promql Q1, 13:35 to 14:35 | 0.0605 at 13:45, 0.16 at 13:50, 0 at 14:30 |
| E2 | Failures by page and instance | Splunk | splunk.spl Q2 | /orange.jsf 485 + 434, trip details 282 + 252, booking 110 + 98 |
| E3 | The error | Loki, Tempo | loki.logql Q3; trace 0d6e812bbbf138cc1007f795d9e8fea5 | 1,453 JourneyService + 208 BookingService, SQLTransientConnectionException |
| E4 | The slow statement | Splunk, Loki | splunk.spl Q4 | 0x8F3A2C1D TableScan(journeys), 5,023 times, avg 9,116 ms |
| E5 | The change | Splunk | splunk.spl Q5 | DROP INDEX 13:42:32, CREATE INDEX failed 13:43:02, Flyway success 13:43:03 |
| E6 | Failed requests, sessions | Splunk, ADX | splunk.spl Q6; azure.kql Q6 | 1,661 failed, 1,026 sessions, 13:42:41 to 14:23:23 |
| E7 | Pool and database | Prometheus | prometheus.promql Q4 | pool 10/10 13:45 to 14:20; db CPU 0.99; findJourneys p95 14.8 s at 14:00 |
| E8 | Not only the new version | Tempo | tempo.traceql Q5 | 1,650 failed traces on 3.6.0, 11 on 3.5.2 (the first ones) |
| E9 | Error budget | Prometheus, bin/slo.py | SLO dashboard; bin/slo.py | 24.6 % of availability budget, 36.0 % left |

## 8. Remediation
| # | Action | Type | Owner | Due |
| --- | --- | --- | --- | --- |
| R1 | Migrations create the new index online before dropping the old one; a failed DDL fails the migration | prevent | app team | 2026-12-01 |
| R2 | Deployment gate: roll back automatically when the burn rate (1 h) is above 14.4 within 15 minutes of a release | prevent | platform | 2026-12-15 |
| R3 | Deploy alerts/rules-improved.yml: burn-rate alerts, pool exhausted, database CPU, each with a runbook | detect | SRE | 2026-11-24 |
| R4 | Alert on SQL Server error 1222 and on DDL failures in the database log | detect | DBA team | 2026-12-01 |
| R5 | Golden signals v3: dependency row, change annotations, runbook links | detect | SRE | 2026-11-24 |
| R6 | Runbook for pool exhaustion: check the database first, do not raise the pool size | mitigate | app team | done |

## 9. Observability follow-ups
- Send deployment events to every tool (annotations in Grafana, deployment events in Dynatrace, Datadog, New Relic).
- Keep tail sampling: head sampling at 10 % would have kept about 166 of the 1,661 failed traces.
- Drop the `journey_id` label from `easytravel_journey_views_total` (77 % of all series); keep top journeys in logs.
