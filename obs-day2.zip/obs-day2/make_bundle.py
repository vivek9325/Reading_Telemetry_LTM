#!/usr/bin/env python3
"""Build the Day 2 data bundle: easyTravel in production, 18 Nov 2026, 09:00-11:00 UTC.

At 09:48:10 JourneyService 3.4.1 is deployed. Its new checkDestination check is CPU-heavy, so the
Business Backend hosts app-01 and app-02 saturate, journey search slows from ~0.2 s to ~3 s, and
bookings that call JourneyService slow down too; some time out after 3 s and fail with 504 at the
frontend. JourneyService is rolled back to 3.4.0 at 10:31:40. Output is identical on every run.

Writes bundle/: logs.ndjson, access.log, metrics.csv, hosts.csv, traces.ndjson, events.ndjson
"""
import csv, json, math, os, random
from datetime import datetime, timedelta, timezone

R = random.Random(20261118)
T0 = datetime(2026, 11, 18, 9, 0, tzinfo=timezone.utc)
MIN = 120
DEPLOY = 48 * 60 + 10          # seconds from T0
ROLLBACK = 91 * 60 + 40
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bundle")
os.makedirs(OUT, exist_ok=True)

FE, BS, JS, AS = "easyTravel Customer Frontend", "BookingService", "JourneyService", "AuthenticationService"
WEB, APP = ["web-01", "web-02"], ["app-01", "app-02"]
DESTS = ["Barcelona", "Lisbon", "Vienna", "Sydney", "New York", "Kyoto", "Cape Town", "Reykjavik", "Dubai", "Lima"]
CLIENTS = ["198.51.100.%d" % i for i in range(10, 60)] + ["203.0.113.%d" % i for i in range(20, 70)]
AGENTS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0 Safari/537.36",
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 Version/18.1 Safari/605.1.15",
          "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148"]


def ts(sec):
    return (T0 + timedelta(seconds=sec)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def hexid(n):
    return "".join(R.choice("0123456789abcdef") for _ in range(n))


def load(sec):
    """Traffic multiplier: a morning ramp."""
    return 0.8 + 0.4 * sec / (MIN * 60)


def cpu_factor(sec):
    """How much slower CPU-bound backend work runs (app hosts saturated during the bad release)."""
    if DEPLOY <= sec < ROLLBACK:
        ramp = min(1.0, (sec - DEPLOY) / 240)
        return 1 + ramp * R.uniform(2.0, 3.2)
    if ROLLBACK <= sec < ROLLBACK + 90:
        return 1 + R.uniform(0.2, 0.8)
    return 1.0


bad = lambda sec: DEPLOY <= sec < ROLLBACK
logs, access, spans, reqs = [], [], [], []


def log(sec, level, svc, host, msg, tr=None, sid=None, **kw):
    d = {"@timestamp": ts(sec), "log.level": level, "service.name": svc, "host.name": host, "message": msg}
    if tr:
        d["trace.id"], d["span.id"] = tr, sid
    d.update(kw)
    logs.append((sec, d))


def span(tr, sid, parent, svc, name, kind, start, dur, failed=False, **attrs):
    spans.append(dict(**{"trace.id": tr, "span.id": sid, "span.parent_id": parent, "service.name": svc, "span.name": name,
                         "span.kind": kind, "start_time": ts(start), "duration_ms": round(dur * 1000, 1),
                         "error": failed}, **attrs))


def request(kind, sec, sample):
    tr = hexid(32)
    web, app = R.choice(WEB), R.choice(APP)
    f = cpu_factor(sec)
    root = hexid(16)
    status, fe_own, children = 200, R.lognormvariate(math.log(0.028), 0.3), []
    if kind == "search":
        path, method = "/orange.jsf", "GET"
        own = R.lognormvariate(math.log(0.012), 0.3)
        check = R.lognormvariate(math.log(0.006), 0.3) * (1 if not bad(sec) else 1)
        if bad(sec):
            check = R.lognormvariate(math.log(0.55), 0.25)          # the new destination check
        check *= f
        q = R.uniform(0.004, 0.012)
        jdur = own * f + check + q
        children = [("findJourneys", JS, jdur, False, [("checkDestination", check), ("SELECT Journey", q)])]
        dest = R.choice(DESTS)
    elif kind == "details":
        path, method = "/orange-trip-details.jsf", "GET"
        jdur = R.lognormvariate(math.log(0.011), 0.3) * f
        children = [("getJourneyById", JS, jdur, False, [("SELECT Journey", jdur * 0.4)])]
    elif kind == "login":
        path, method = "/orange.jsf", "POST"
        adur = R.lognormvariate(math.log(0.03), 0.25) * (1 + (f - 1) * 0.3)
        children = [("authenticate", AS, adur, False, [("SELECT User", adur * 0.4)])]
    else:  # booking
        path, method = "/orange-booking-payment.jsf", "POST"
        j = R.lognormvariate(math.log(0.012), 0.3) * f
        if bad(sec):
            j += R.lognormvariate(math.log(0.40), 0.45) * f        # getJourneyById also runs the new check
        j_full = j
        timeout = j > 3.0
        j = min(j, 3.0)                                            # BookingService gives up after 3 s
        cc = R.lognormvariate(math.log(0.045), 0.3)
        ins = R.uniform(0.006, 0.02)
        bdur = 0.006 + j + (0 if timeout else cc + ins) + 0.004
        children = [("storeBooking", BS, bdur, timeout,
                     [("getJourneyById", j, timeout, j_full)] + ([] if timeout else [("checkCreditCard", cc), ("INSERT Booking", ins)]))]
        if timeout:
            status = 504
    total = fe_own + sum(c[2] for c in children) + 0.004
    size = R.randint(4200, 18000) if status == 200 else 612
    access.append((sec, '%s - - [%s] "%s %s HTTP/1.1" %d %d "-" "%s" rt=%.3f host=%s trace=%s' % (
        R.choice(CLIENTS), (T0 + timedelta(seconds=sec)).strftime("%d/%b/%Y:%H:%M:%S +0000"), method,
        path + ("?destination=" + dest.replace(" ", "%20") if kind == "search" else ""), status, size, R.choice(AGENTS),
        total, web, tr)))
    reqs.append((sec, FE, path if not (kind == "login") else "/orange.jsf (login)", total, status >= 500))
    for name, svc, dur, failed, _ in children:
        reqs.append((sec, svc, name, dur, failed))
    # logs
    if kind == "booking":
        bid = R.randint(7100000, 7999999)
        s_b = hexid(16)
        log(sec + fe_own / 2, "INFO", BS, app, f"storeBooking start bookingId={bid}", tr, s_b)
        if status == 504:
            log(sec + 3.0, "ERROR", BS, app, f"storeBooking failed bookingId={bid}: java.net.SocketTimeoutException: Read timed out "
                f"(JourneyService getJourneyById after 3000 ms)", tr, s_b)
            log(sec + total, "ERROR", FE, web, f"Booking failed: HTTP 504 from BookingService bookingId={bid}", tr, root)
        else:
            log(sec + total, "INFO", BS, app, f"Booking stored bookingId={bid} durationMs={int(children[0][2]*1000)}", tr, s_b)
    if kind == "search" and bad(sec) and children[0][4][0][1] > 1.0 and R.random() < 0.35:
        log(sec + total, "WARN", JS, app, f"checkDestination took {int(children[0][4][0][1]*1000)} ms destination={dest} "
            f"(threshold 500 ms)", tr, hexid(16))
    if sample:
        t = sec
        span(tr, root, None, FE, path, "server", t, total, status >= 500, **{"http.method": method, "http.status_code": status, "host.name": web})
        t += fe_own * 0.6
        for name, svc, dur, failed, kids in children:
            c = hexid(16); s = hexid(16)
            span(tr, c, root, FE if svc != BS else FE, f"{('POST' if svc == BS else 'GET')} /services/{svc}/{name}", "client", t, dur + 0.002, failed,
                 **{"http.status_code": 504 if failed else 200, "host.name": web})
            span(tr, s, c, svc, name, "server", t + 0.001, dur, failed, **{"host.name": app})
            for _, d in logs[-4:]:                     # this request's log lines point at the span that wrote them
                if d.get("trace.id") == tr and d["service.name"] == svc:
                    d["span.id"] = s
            tt = t + 0.004
            for k in kids:
                kname, kdur = k[0], k[1]
                kf = len(k) > 2 and k[2]
                if kname == "getJourneyById":
                    c2, s2 = hexid(16), hexid(16)
                    span(tr, c2, s, BS, "GET /services/JourneyService/getJourneyById", "client", tt, kdur, kf, **{"host.name": app})
                    full = k[3]                                # JourneyService itself finishes, late
                    span(tr, s2, c2, JS, "getJourneyById", "server", tt + 0.001, full - 0.002, False, **{"host.name": app})
                    reqs.append((sec, JS, "getJourneyById", full, False))
                elif kname.startswith(("SELECT", "INSERT")):
                    span(tr, hexid(16), s, svc, kname, "client", tt, kdur, **{"db.system": "derby", "host.name": "db-01"})
                else:
                    span(tr, hexid(16), s, svc, kname, "internal", tt, kdur, **{"host.name": app})
                tt += kdur
    elif kind == "booking":
        reqs.append((sec, JS, "getJourneyById", children[0][4][0][3], False))


MIX = [("search", 160), ("details", 70), ("login", 25), ("booking", 28)]   # per minute
for s in range(MIN * 60):
    for kind, rpm in MIX:
        n = rpm / 60 * load(s)
        k = int(n) + (1 if R.random() < n - int(n) else 0)
        for _ in range(k):
            request(kind, s + R.random(), R.random() < 1 / 25)

# lifecycle logs
log(DEPLOY, "INFO", JS, "app-01", "Deploying JourneyService 3.4.1 (was 3.4.0) build=8812")
log(DEPLOY + 6.2, "INFO", JS, "app-01", "JourneyService 3.4.1 started: destination validation enabled (mode=full-scan)")
log(DEPLOY + 41.0, "INFO", JS, "app-02", "JourneyService 3.4.1 started: destination validation enabled (mode=full-scan)")
log(ROLLBACK, "INFO", JS, "app-01", "Deploying JourneyService 3.4.0 (rollback)")
log(ROLLBACK + 5.8, "INFO", JS, "app-01", "JourneyService 3.4.0 started")
log(ROLLBACK + 33.1, "INFO", JS, "app-02", "JourneyService 3.4.0 started")
for k in range(0, MIN * 60, 300):
    log(k + 12.4, "INFO", AS, "app-01", "Session cache cleanup removed %d expired sessions" % R.randint(40, 160))

logs.sort(key=lambda x: x[0]); access.sort(key=lambda x: x[0])
with open(os.path.join(OUT, "logs.ndjson"), "w") as f:
    for _, d in logs:
        f.write(json.dumps(d) + "\n")
with open(os.path.join(OUT, "access.log"), "w") as f:
    for _, a in access:
        f.write(a + "\n")
spans.sort(key=lambda s: (s["trace.id"], s["start_time"]))
with open(os.path.join(OUT, "traces.ndjson"), "w") as f:
    for s in spans:
        f.write(json.dumps(s) + "\n")


def pct(v, p):
    v = sorted(v)
    return v[max(0, min(len(v) - 1, int(math.ceil(p / 100 * len(v))) - 1))] if v else 0


groups = {}
for sec, svc, ep, dur, failed in reqs:
    groups.setdefault((int(sec // 60), svc, ep), []).append((dur, failed))
with open(os.path.join(OUT, "metrics.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["timestamp", "service", "endpoint", "requests", "errors", "p50_ms", "p95_ms"])
    for (m, svc, ep), v in sorted(groups.items()):
        d = [x[0] * 1000 for x in v]
        w.writerow([ts(m * 60)[:16] + ":00Z", svc, ep, len(v), sum(1 for x in v if x[1]), round(pct(d, 50), 1), round(pct(d, 95), 1)])
with open(os.path.join(OUT, "hosts.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["timestamp", "host", "cpu_pct", "load_per_core", "memory_pct"])
    for m in range(MIN):
        sec = m * 60 + 30
        for h in WEB + APP + ["db-01"]:
            cpu = {"web-01": 31, "web-02": 29, "app-01": 34, "app-02": 33, "db-01": 22}[h] * load(sec) + R.gauss(0, 2)
            if h in APP and bad(sec):
                cpu = min(99.0, 70 + 25 * min(1, (sec - DEPLOY) / 240) + R.gauss(0, 2))
            lpc = cpu / 100 * 0.9 + (max(0, (cpu - 85)) / 15 * 1.6 if h in APP else 0) + R.gauss(0, 0.03)
            mem = {"web-01": 48, "web-02": 47, "app-01": 61, "app-02": 60, "db-01": 70}[h] + R.gauss(0, 0.5)
            w.writerow([ts(m * 60)[:16] + ":00Z", h, round(cpu, 1), round(max(0.01, lpc), 2), round(mem, 1)])
EVENTS = [
    {"timestamp": ts(DEPLOY), "type": "deployment", "service": JS, "title": "Deployment: JourneyService 3.4.1 (was 3.4.0)", "ci_link": "https://ci.example.com/journey-service/builds/8812"},
    {"timestamp": ts(DEPLOY + 312), "type": "alert", "service": JS, "title": "JourneyService findJourneys p95 above 1 s for 5 minutes"},
    {"timestamp": ts(DEPLOY + 345), "type": "alert", "service": "app-01", "title": "CPU above 90 % on app-01 for 5 minutes"},
    {"timestamp": ts(DEPLOY + 512), "type": "alert", "service": FE, "title": "Booking failure rate above 2 % (504 Gateway Timeout)"},
    {"timestamp": ts(ROLLBACK), "type": "deployment", "service": JS, "title": "Deployment: JourneyService 3.4.0 (rollback)"},
]
with open(os.path.join(OUT, "events.ndjson"), "w") as f:
    for e in EVENTS:
        f.write(json.dumps(e) + "\n")
print(f"logs {len(logs)}  access {len(access)}  spans {len(spans)}  traces {len({s['trace.id'] for s in spans})}  requests {len(reqs)}")
