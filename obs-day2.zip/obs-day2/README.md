# obs-day2: Enterprise Observability Platforms and Tool Navigation (lab pack)

Lab files for Day 2 of the observability course. Dynatrace and Datadog run on the easyTravel demo application
(one VM each). Splunk, New Relic, Grafana, Kibana, Azure and AWS use free trials or sandboxes loaded with the
same easyTravel incident, delivered here as an offline bundle. Every lab also has an offline variant that needs
only this folder, Python 3, `jq` and `awk`.

## The incident in the bundle

On 18 November 2026, 09:00 to 11:00 UTC, easyTravel runs on five hosts (web-01, web-02, app-01, app-02, db-01).
At 09:48:10 JourneyService 3.4.1 is deployed with a CPU-heavy destination check. The Business Backend hosts saturate,
searches slow from about 35 ms to 3 s at p95, and about 6 % of bookings time out (HTTP 504). JourneyService is rolled
back at 10:31:40. The data is invented: example.com addresses and documentation IP ranges only.

## Contents

| Path | What it is |
| --- | --- |
| `bundle/logs.ndjson` | 9,369 application log records (ECS-style fields: `@timestamp`, `log.level`, `service.name`, `host.name`, `trace.id`, `span.id`) |
| `bundle/access.log` | 34,034 frontend access log lines, combined format plus `rt=<seconds> host= trace=` |
| `bundle/traces.ndjson` | 6,742 spans of 1,384 sampled traces (1 in 25) |
| `bundle/metrics.csv` | Per-minute requests, errors, p50 and p95 per service and endpoint |
| `bundle/hosts.csv` | Per-minute CPU, load per core and memory per host |
| `bundle/events.ndjson` | Deployments, alerts and the rollback |
| `make_bundle.py` | Rebuilds the bundle (fixed seed, same output every time) |
| `bin/check.py` | Checks easyTravel and the agent on a lab VM |
| `bin/scenario.py` | Timed problem patterns: `lab21` (Dynatrace), `lab22` (Datadog) |
| `bin/pattern.py` | Turns one easyTravel problem pattern on or off |
| `bin/dd_javaopts.py` | Datadog VM: names the easyTravel Java services for APM |
| `bin/dd_logs.py` | Datadog VM: configures log collection for easyTravel's log files |
| `bin/to_newrelic.py` | Sends the bundle's traces and logs to New Relic (Trace API, Log API) |
| `bin/to_aws.py` | Loads the bundle into CloudWatch Logs, metrics, X-Ray and a dashboard (run in CloudShell) |
| `bin/window.py`, `bin/waterfall.py`, `bin/p95.py` | Offline analysis helpers |
| `grafana/easytravel-day2.json` | Grafana dashboard on the built-in TestData data source |
| `grafana/build_dashboard.py` | Rebuilds that dashboard from the bundle |
| `escalation/escalation-note-template.md` | Template for Lab 2.5 |

## Quick start

```bash
unzip obs-day2.zip && cd obs-day2
python3 bin/check.py                       # on a lab VM: is easyTravel up, is the agent active?
python3 bin/scenario.py lab21              # Dynatrace VM, Lab 2.1 (25 minutes)
python3 bin/scenario.py lab22              # Datadog VM, Lab 2.2 (20 minutes)
python3 bin/to_newrelic.py --dry-run       # what would be sent to New Relic
python3 bin/to_aws.py --dry-run            # what would be created in AWS (writes aws-dry-run/)
bin/waterfall.py 1c759c832ea1d039e0e63a30709d11de   # one failed booking, offline
```

The New Relic and AWS loaders move the timestamps so that the incident happened in the last two hours, because
SaaS tools reject or hide old data. They print the mapping from bundle time to your time.

## Secrets

Lab-only secrets, never committed. The New Relic license key, the Datadog API key, the Dynatrace installer token
and AWS credentials go in your shell or the vendor's own console only, never in a file in this folder, a chat or
a screenshot. `.gitignore` excludes `*.env` and `aws-dry-run/`.

## Clean up

- AWS: `python3 bin/to_aws.py --delete` (log groups and dashboard; custom metrics and traces expire on their own).
- Datadog VM: `sudo dd-host-install --uninstall` removes single-step instrumentation; remove the Agent with your package manager.
- Trials: delete the uploaded data or let the trial lapse.
