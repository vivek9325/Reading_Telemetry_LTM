# Escalation note

**To:** <team or on-call you hand over to>     **From:** <your name, your team>     **Time (UTC):** <when you send it>
**Severity / priority:** <for example P2, Sev 2>      **Incident or problem ID:** <ID in your tool>

## 1. What users see
<one or two sentences: which journey, how bad, since when; numbers with units>

## 2. Impact
- Users or requests affected: <count or rate, from which tool>
- Business process: <search, booking, login, ...>
- Trend: <getting worse / stable / recovering>

## 3. Timeline (UTC)
| Time | What happened | Source |
| --- | --- | --- |
| <hh:mm> | <first symptom, change, alert, action> | <tool> |

## 4. Evidence (links, each with its time range)
- Dashboard: <link>  (<from> to <to>)
- Logs: <link to the saved search or query>  query: `<the query>`
- Traces: <link to one example trace>  trace ID: `<id>`
- Problem / alert: <link>

## 5. What we know and what we don't
- Suspected cause: <component, change, mechanism> (confidence: <high/medium/low>, why)
- Ruled out: <what you checked and found normal>
- Unknown: <the open question you need help with>

## 6. Actions taken so far
- <time> <action> -> <result>

## 7. What we need from you
<one clear ask: decision, rollback, access, a specialist>

**Next update:** <time>, or sooner if something changes. **Contact:** <channel, phone bridge>
