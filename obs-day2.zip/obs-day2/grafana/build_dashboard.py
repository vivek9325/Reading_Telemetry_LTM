#!/usr/bin/env python3
"""Write grafana/easytravel-day2.json: a Grafana dashboard whose panels read the Day 2 bundle through the
built-in TestData data source (scenario "CSV content"), so it works on any Grafana without a database.

Import it in Grafana: Dashboards > New > Import > Upload dashboard JSON file, then pick your TestData data source.
"""
import csv, json, os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
B = os.path.join(HERE, "..", "bundle")
M = list(csv.DictReader(open(os.path.join(B, "metrics.csv"))))
H = list(csv.DictReader(open(os.path.join(B, "hosts.csv"))))
DS = {"type": "grafana-testdata-datasource", "uid": "${DS_TESTDATA}"}
t = lambda s: s[:10] + " " + s[11:19]           # 2026-11-18 09:00:00


def wide(rows, key, val, cols):
    d = defaultdict(dict)
    for r in rows:
        if key(r) in cols:
            d[r["timestamp"]][key(r)] = val(r)
    lines = ["time," + ",".join(cols.values())]
    for ts in sorted(d):
        lines.append(t(ts) + "," + ",".join(str(d[ts].get(c, "")) for c in cols))
    return "\n".join(lines)


ep = lambda r: (r["service"], r["endpoint"])
p95 = wide(M, ep, lambda r: r["p95_ms"], {("easyTravel Customer Frontend", "/orange.jsf"): "search_page",
                                          ("easyTravel Customer Frontend", "/orange-booking-payment.jsf"): "booking_page",
                                          ("JourneyService", "findJourneys"): "findJourneys",
                                          ("BookingService", "storeBooking"): "storeBooking"})
fails = wide(M, ep, lambda r: round(100 * int(r["errors"]) / max(1, int(r["requests"])), 2),
             {("easyTravel Customer Frontend", "/orange-booking-payment.jsf"): "booking_failure_pct"})
reqs = wide(M, ep, lambda r: r["requests"], {("easyTravel Customer Frontend", "/orange.jsf"): "search",
                                             ("easyTravel Customer Frontend", "/orange-trip-details.jsf"): "trip_details",
                                             ("easyTravel Customer Frontend", "/orange-booking-payment.jsf"): "booking",
                                             ("easyTravel Customer Frontend", "/orange.jsf (login)"): "login"})
cpu = wide(H, lambda r: r["host"], lambda r: r["cpu_pct"], {h: h for h in ("web-01", "web-02", "app-01", "app-02", "db-01")})


def panel(pid, title, typ, csv_text, grid, unit=None, desc="", **extra):
    p = {"id": pid, "type": typ, "title": title, "description": desc, "datasource": DS, "gridPos": grid,
         "targets": [{"refId": "A", "datasource": DS, "scenarioId": "csv_content", "csvContent": csv_text}],
         "fieldConfig": {"defaults": {"unit": unit} if unit else {}, "overrides": []}, "options": {}}
    p.update(extra)
    return p


dash = {
    "__inputs": [{"name": "DS_TESTDATA", "label": "TestData", "type": "datasource", "pluginId": "grafana-testdata-datasource", "pluginName": "TestData"}],
    "title": "easyTravel - Day 2 incident (lab)", "uid": "easytravel-day2", "tags": ["obs-day2", "easytravel"],
    "timezone": "utc", "schemaVersion": 39, "version": 1, "editable": True,
    "time": {"from": "2026-11-18T09:00:00.000Z", "to": "2026-11-18T11:00:00.000Z"},
    "panels": [
        panel(1, "p95 response time (ms)", "timeseries", p95, {"x": 0, "y": 0, "w": 12, "h": 8}, "ms",
              "Per minute, from bundle/metrics.csv"),
        panel(2, "Booking failure rate (%)", "timeseries", fails, {"x": 12, "y": 0, "w": 12, "h": 8}, "percent"),
        panel(3, "Frontend requests per minute", "timeseries", reqs, {"x": 0, "y": 8, "w": 12, "h": 8}, "short",
              "Stacked by page"),
        panel(4, "Host CPU (%)", "timeseries", cpu, {"x": 12, "y": 8, "w": 12, "h": 8}, "percent"),
    ],
}
json.dump(dash, open(os.path.join(HERE, "easytravel-day2.json"), "w"), indent=2)
print("wrote grafana/easytravel-day2.json with", len(dash["panels"]), "panels")
